const https = require('https');

https.get('https://raw.githubusercontent.com/jaber69y9-cmd/wsphysics1.0/main/src/pages/RecordedClasses.tsx', {
  headers: { 'User-Agent': 'Node.js' }
}, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    console.log(data);
  });
}).on('error', console.error);
