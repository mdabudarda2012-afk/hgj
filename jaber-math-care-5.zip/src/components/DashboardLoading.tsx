import React from 'react';
import { motion } from 'motion/react';
import { useSettings } from '../context/SettingsContext';
import { Plus, Minus, X, Divide, Hash, Percent } from 'lucide-react';

const FloatingSymbol = ({ icon: Icon, delay, x, y }: { icon: any, delay: number, x: string, y: string }) => (
  <motion.div
    className="absolute text-orange-500/10 pointer-events-none"
    style={{ left: x, top: y }}
    animate={{
      y: [0, -15, 0],
      rotate: [0, 360],
      opacity: [0.05, 0.2, 0.05],
    }}
    transition={{
      duration: 4 + Math.random() * 4,
      repeat: Infinity,
      delay: delay,
      ease: "easeInOut"
    }}
  >
    <Icon size={16 + Math.random() * 16} />
  </motion.div>
);

const DashboardLoading = () => {
  const { settings } = useSettings();
  const siteName = settings.site_name || "Jaber Math Care";

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').substring(0, 3).toUpperCase();
  };
  const siteInitials = getInitials(siteName);

  return (
    <div className="w-full min-h-[70vh] flex flex-col items-center justify-center gap-8 relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <FloatingSymbol icon={Plus} delay={0} x="20%" y="30%" />
        <FloatingSymbol icon={Minus} delay={1} x="75%" y="25%" />
        <FloatingSymbol icon={X} delay={2} x="25%" y="70%" />
        <FloatingSymbol icon={Divide} delay={3} x="70%" y="75%" />
      </div>

      <div className="relative">
        {/* Pulsing Rings */}
        {[1, 2].map((i) => (
          <motion.div
            key={i}
            className="absolute inset-0 border-2 border-orange-500/20 rounded-3xl"
            animate={{
              scale: [1, 1.4, 1],
              opacity: [0.3, 0, 0.3],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.5,
              ease: "easeInOut",
            }}
          />
        ))}
        
        {/* Logo Container */}
        <motion.div
          className="relative w-20 h-20 bg-white rounded-2xl shadow-xl flex items-center justify-center border border-orange-100 overflow-hidden"
          animate={{
            y: [0, -5, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          {settings.logo_url ? (
            <img 
              src={settings.logo_url} 
              alt="Logo" 
              className="w-12 h-12 object-contain" 
              referrerPolicy="no-referrer" 
            />
          ) : (
            <div className="h-12 px-4 bg-orange-50 rounded-xl flex items-center justify-center border border-orange-100">
              <span className="text-sm font-black text-orange-600 truncate max-w-[150px]">{siteName}</span>
            </div>
          )}
          
          {/* Scanning Line */}
          <motion.div
            className="absolute inset-x-0 h-0.5 bg-orange-500/50 z-20"
            animate={{
              top: ["-10%", "110%", "-10%"],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "linear",
            }}
          />
        </motion.div>
      </div>

      <div className="flex flex-col items-center gap-4 relative z-10">
        <div className="text-center space-y-1">
          <motion.h2 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-xl font-black text-orange-600 tracking-tight"
          >
            {siteName}
          </motion.h2>
          <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.3em] animate-pulse">
            Loading Dashboard
          </p>
        </div>

        {/* Progress Bar */}
        <div className="w-32 h-1 bg-slate-100 rounded-full overflow-hidden relative">
          <motion.div
            className="absolute inset-y-0 left-0 bg-orange-600 rounded-full"
            animate={{
              left: ["-100%", "100%"],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            style={{ width: "40%" }}
          />
        </div>
      </div>
    </div>
  );
};

export default DashboardLoading;
