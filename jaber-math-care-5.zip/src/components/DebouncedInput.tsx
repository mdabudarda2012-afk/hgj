import React, { useState, useEffect } from 'react';

export const DebouncedInput = ({ value, onChange, debounce = 300, onEnter, onKeyDown, ...props }: any) => {
  const [internalVal, setInternalVal] = useState(value || "");

  useEffect(() => {
    setInternalVal(value || "");
  }, [value]);

  useEffect(() => {
    const handler = setTimeout(() => {
      if (internalVal !== (value || "")) {
        onChange(internalVal);
      }
    }, debounce);
    return () => clearTimeout(handler);
  }, [internalVal, debounce, onChange, value]);

  return (
    <input
      value={internalVal}
      onChange={(e) => setInternalVal(e.target.value)}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          onChange(internalVal);
          if (onEnter) onEnter(internalVal);
        }
        if (onKeyDown) onKeyDown(e);
      }}
      {...props}
    />
  );
};
