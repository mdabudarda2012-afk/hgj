import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, RefreshCw, Trash2 } from 'lucide-react';

const FirebaseErrorBanner: React.FC = () => {
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleOffline = (e: any) => {
      setError(e.detail || "Firebase is offline. Check your configuration.");
    };
    window.addEventListener('firebase-offline', handleOffline);
    return () => window.removeEventListener('firebase-offline', handleOffline);
  }, []);

  const handleReset = () => {
    localStorage.removeItem("app_firebase_settings");
    window.location.reload();
  };

  if (!error) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        exit={{ y: -100 }}
        className="fixed top-0 left-0 right-0 z-[9999] bg-red-600 text-white p-4 shadow-2xl flex items-center justify-center gap-6"
      >
        <div className="flex items-center gap-3">
          <ShieldAlert className="h-6 w-6 text-white" />
          <div className="text-sm">
            <span className="font-bold block uppercase tracking-widest text-[10px] opacity-80">Connection Error</span>
            <span className="font-medium">{error}</span>
          </div>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={handleReset}
            className="bg-white/20 hover:bg-white text-white hover:text-red-600 px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 border border-white/40"
          >
            <Trash2 className="h-3 w-3" /> Reset Overrides
          </button>
          <button 
            onClick={() => window.location.reload()}
            className="bg-white text-red-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-red-50 transition flex items-center gap-2 shadow-lg"
          >
            <RefreshCw className="h-3 w-3" /> Retry
          </button>
          <button 
            onClick={() => setError(null)}
            className="text-white/60 hover:text-white px-2 py-2 text-xs font-bold transition"
          >
            Dismiss
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default FirebaseErrorBanner;
