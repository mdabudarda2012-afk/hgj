import React from 'react';

const BackgroundAnimation = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-[-1] bg-slate-50/50">
      <div className="absolute top-[-10%] left-[-5%] w-[40%] h-[40%] bg-orange-400/5 rounded-full blur-[100px]" />
      <div className="absolute bottom-[-10%] right-[-5%] w-[40%] h-[40%] bg-blue-400/5 rounded-full blur-[100px]" />
    </div>
  );
};

export default BackgroundAnimation;
