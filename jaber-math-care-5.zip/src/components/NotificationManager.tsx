import React, { useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, orderBy, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

const NotificationManager: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();

  useEffect(() => {
    if (!user?.id) return;

    // Listen for new unread notifications
    const q = query(
      collection(db, 'notifications'),
      where('user_id', '==', user.id),
      where('is_read', '==', false),
      orderBy('created_at', 'desc'),
      limit(5)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const notification = change.doc.data();
          
          // Show toast
          showToast(notification.message, 'success');

          // Mark as read after showing
          // We wait a bit to avoid race conditions or double triggers
          setTimeout(async () => {
            try {
              await updateDoc(doc(db, 'notifications', change.doc.id), {
                is_read: true
              });
            } catch (error) {
              console.error('Error marking notification as read:', error);
            }
          }, 2000);
        }
      });
    });

    return () => unsubscribe();
  }, [user?.id, showToast]);

  return null; // This component doesn't render anything itself
};

export default NotificationManager;
