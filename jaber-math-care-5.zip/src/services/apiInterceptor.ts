import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  where,
  getDoc,
  setDoc,
  orderBy,
  writeBatch,
} from "firebase/firestore";
import {
  createUserWithEmailAndPassword,
  updatePassword,
  updateEmail,
  EmailAuthProvider,
  reauthenticateWithCredential,
} from "firebase/auth";
import { db, auth, secondaryAuth } from "../firebase";

enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  };
}

function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData.map((provider) => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL,
        })) || [],
    },
    operationType,
    path,
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Store original fetch
const originalFetch = window.fetch;

// Simple cache for GET requests - DISABLED per user request
const apiCache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 0; // Disabled cache

// Helper to create a Response object
const baseCreateResponse = (data: any, status = 200) => {
  if (status >= 400) {
    console.warn(`[Interceptor] Returning error response: ${status}`, data);
  }
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
};

// Helper to get current user ID from token/auth
const getCurrentUserId = () => {
  return auth.currentUser?.uid;
};

// Interceptor
Object.defineProperty(window, "fetch", {
  value: async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === "string" ? input : input.toString();

    // Only intercept /api/ calls
    const isApiCall = url.startsWith("/api/") || url.includes("/api/");
    if (!isApiCall || url.includes("/api/cancel-enrollment/")) {
      return originalFetch(input, init);
    }

    const method = init?.method || "GET";

    // Clear cache for non-GET requests
    if (method !== "GET") {
      console.log(`[Firebase Adapter] Clearing cache due to ${method} request`);
      apiCache.clear();
    }

    const body = init?.body ? JSON.parse(init.body as string) : null;

    // Extract the path after /api/
    const apiPart = url.split("/api/")[1];
    const path = apiPart.split("?")[0];

    // BYPASS INTERCEPTOR for certain specialized non-DB routes if needed
    // (Currently none identified that must hit the server)

    // console.log(`[Firebase Adapter] Intercepting fetch: ${method} /api/${path}`);

    /* 
  // Disable caching for "real-time fresh data" as requested
  if (method === 'GET') {
    const cached = apiCache.get(url);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      console.log(`[Firebase Adapter] Serving from cache: ${url}`);
      return baseCreateResponse(cached.data);
    }
  }
  */

    const createResponse = (data: any, status = 200) => {
      if (method === "GET" && status === 200) {
        apiCache.set(url, { data, timestamp: Date.now() });
      }
      if (method !== "GET" && status >= 200 && status < 300) {
        apiCache.clear(); // Invalidate cache on mutations
      }
      return baseCreateResponse(data, status);
    };

    console.log(`[Firebase Adapter] Intercepted ${method} /api/${path}`, body);

    try {
      // ----------------------------------------------------------------------
      // PUBLIC ENDPOINTS
      // ----------------------------------------------------------------------
      if (path === "public/notices") {
        try {
          const snapshot = await getDocs(collection(db, "notices"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "notices");
        }
      }

      if (path === "public/settings") {
        try {
          const snapshot = await getDocs(collection(db, "settings"));
          const settings: Record<string, string> = {};
          snapshot.docs.forEach((d) => {
            settings[d.id] = d.data().value;
          });
          return createResponse(settings);
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "settings");
        }
      }

      if (path === "public/exams") {
        try {
          const snapshot = await getDocs(collection(db, "exams"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "exams");
        }
      }

      if (path === "public/programs") {
        try {
          const snapshot = await getDocs(collection(db, "programs"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "programs");
        }
      }

      if (path === "public/batches") {
        try {
          const snapshot = await getDocs(collection(db, "batches"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "batches");
        }
      }

      if (path.startsWith("public/results")) {
        try {
          const urlObj = new URL(url, window.location.origin);
          const exam_name = urlObj.searchParams.get("exam_name");
          const roll_number = urlObj.searchParams.get("roll_number");

          console.log(
            `[Firebase Adapter] Fetching results for exam: ${exam_name}, roll: ${roll_number}`,
          );

          let q = collection(db, "results");
          const constraints = [];
          if (exam_name) constraints.push(where("exam_name", "==", exam_name));

          const snapshot = await getDocs(query(q, ...constraints));
          console.log(
            `[Firebase Adapter] Found ${snapshot.size} results documents`,
          );
          let results = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }));

          if (roll_number) {
            // Fetch student to match roll number
            const studentsSnap = await getDocs(
              query(collection(db, "users"), where("role", "==", "student")),
            );
            const student = studentsSnap.docs.find(
              (d) => d.data().roll_number === roll_number,
            );
            if (student) {
              results = results.filter((r: any) => r.student_id === student.id);
            } else {
              results = []; // Student not found
            }
          }

          console.log(
            `[Firebase Adapter] Filtered results count: ${results.length}`,
          );

          // Enrich results with student and exam info
          const enrichedResults = await Promise.all(
            results.map(async (res: any) => {
              let studentName = "Unknown";
              let studentRoll = "Unknown";
              let studentClass = "Unknown";
              let examCategory = "Unknown";
              let programId = "";

              if (res.student_id) {
                try {
                  const studentSnap = await getDoc(
                    doc(db, "users", res.student_id),
                  );
                  if (studentSnap.exists()) {
                    studentName = studentSnap.data().name || "Unknown";
                    studentRoll = studentSnap.data().roll_number || "Unknown";
                    studentClass =
                      studentSnap.data().class ||
                      studentSnap.data().current_class ||
                      "Unknown";
                    if (!res.batch_id) {
                      res.batch_id = studentSnap.data().batch_id;
                    }
                  }
                } catch (e) {
                  console.warn(
                    `[Firebase Adapter] Could not fetch student ${res.student_id} (likely permissions):`,
                    e,
                  );
                }
              }

              if (studentClass === "Unknown" && res.batch_id) {
                try {
                  const batchSnap = await getDoc(
                    doc(db, "batches", res.batch_id),
                  );
                  if (batchSnap.exists()) {
                    studentClass =
                      batchSnap.data().class ||
                      batchSnap.data().class_name ||
                      batchSnap.data().batch_class ||
                      "Unknown";
                  }
                } catch (e) {
                  console.warn(
                    `[Firebase Adapter] Could not fetch batch ${res.batch_id}:`,
                    e,
                  );
                }
              }

              if (!res.exam_id && res.exam_name) {
                try {
                  const examsSnap = await getDocs(
                    query(
                      collection(db, "exams"),
                      where("exam_name", "==", res.exam_name),
                    ),
                  );
                  if (!examsSnap.empty) {
                    res.exam_id = examsSnap.docs[0].id;
                  }
                } catch (e) {
                  console.warn(
                    `[Firebase Adapter] Could not fetch exam by name ${res.exam_name}:`,
                    e,
                  );
                }
              }

              if (res.exam_id) {
                try {
                  const examSnap = await getDoc(doc(db, "exams", res.exam_id));
                  if (examSnap.exists()) {
                    examCategory = examSnap.data().category || "Unknown";
                    programId = examSnap.data().program_id || "";
                    res.total_marks = examSnap.data().total_marks || 0;
                  }
                } catch (e) {
                  console.warn(
                    `[Firebase Adapter] Could not fetch exam ${res.exam_id}:`,
                    e,
                  );
                }
              }

              return {
                ...res,
                student_name: studentName,
                roll_number: studentRoll,
                student_class: studentClass,
                exam_category: examCategory,
                program_id: programId,
                monthly_fee: res.monthly_fee || 0,
              };
            }),
          );

          console.log(
            `[Firebase Adapter] Enriched results count: ${enrichedResults.length}`,
          );

          return createResponse(enrichedResults);
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "results");
        }
      }

      if (path === "degrees") {
        if (method === "GET") {
          const snapshot = await getDocs(collection(db, "degrees"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        }
        if (method === "POST") {
          const docRef = await addDoc(collection(db, "degrees"), {
            ...body,
            created_at: new Date().toISOString(),
          });
          return createResponse({ id: docRef.id, ...body });
        }
      }
      if (path.startsWith("degrees/")) {
        const id = path.split("/")[1];
        if (method === "DELETE") {
          await deleteDoc(doc(db, "degrees", id));
          return createResponse({ success: true });
        }
      }

      // ----------------------------------------------------------------------
      // SETTINGS
      // ----------------------------------------------------------------------
      if (path === "settings") {
        if (method === "GET") {
          const snapshot = await getDocs(collection(db, "settings"));
          const settings: Record<string, string> = {};
          snapshot.docs.forEach((d) => {
            settings[d.id] = d.data().value;
          });
          return createResponse(settings);
        }
        if (method === "POST") {
          const { key, value } = body;
          if (key) {
            await setDoc(doc(db, "settings", key), { value });
          }
          return createResponse({ success: true });
        }
        if (method === "PUT") {
          for (const [key, value] of Object.entries(body)) {
            await setDoc(doc(db, "settings", key), { value });
          }
          return createResponse({ success: true });
        }
      }

      // ----------------------------------------------------------------------
      // CLEAR ALL DATA
      // ----------------------------------------------------------------------
      if (path === "admin/clear-all-data") {
        if (method === "POST") {
          try {
            const collectionsToClear = [
              "users",
              "batches",
              "programs",
              "chapters",
              "attendance",
              "payments",
              "notices",
              "routines",
              "gallery",
              "exams",
              "results",
              "reviews",
              "video_classes",
              "study_materials",
              "enrollments",
              "live_classes",
            ];

            for (const coll of collectionsToClear) {
              const snap = await getDocs(collection(db, coll));
              const batchRef = writeBatch(db);
              snap.docs.forEach((d) => {
                // Don't delete the current admin user
                if (coll === "users" && d.id === auth.currentUser?.uid) return;
                batchRef.delete(d.ref);
              });
              await batchRef.commit();
            }

            return createResponse({ success: true });
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, "all");
          }
        }
      }

      // ----------------------------------------------------------------------
      // CLEAR PAST ATTENDANCE
      // ----------------------------------------------------------------------
      if (path === "admin/clear-past-attendance") {
        if (method === "POST") {
          try {
            const today = new Date().toISOString().split("T")[0];
            const snapshot = await getDocs(
              query(collection(db, "attendance"), where("date", "<", today)),
            );
            const batchRef = writeBatch(db);
            snapshot.docs.forEach((d) => batchRef.delete(d.ref));
            await batchRef.commit();
            return createResponse({ success: true, count: snapshot.size });
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, "attendance");
          }
        }
      }

      // ----------------------------------------------------------------------
      // STUDENTS / USERS
      // ----------------------------------------------------------------------
      if (path === "students") {
        if (method === "GET") {
          try {
            const q = query(
              collection(db, "users"),
              where("role", "==", "student"),
            );
            const snapshot = await getDocs(q);
            const data = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }));
            return createResponse(data);
          } catch (error) {
            handleFirestoreError(error, OperationType.LIST, "users");
          }
        }
        if (method === "POST") {
          console.log("Creating student:", body);
          const { email, password, ...restBody } = body;
          if (!email || !password) {
            return createResponse(
              { error: "Email and password are required" },
              400,
            );
          }

          const cleanEmail = email.trim();

          // Simple email validation
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(cleanEmail)) {
            return createResponse({ error: "Invalid email format" }, 400);
          }

          try {
            // Create user in Firebase Auth using secondary app to avoid logging out current user
            const userCredential = await createUserWithEmailAndPassword(
              secondaryAuth,
              cleanEmail,
              password,
            );
            const uid = userCredential.user.uid;

            const docData = {
              ...restBody,
              email: cleanEmail,
              role: "student",
              status: "approved",
              created_at: new Date().toISOString(),
              initial_password: password,
            };
            await setDoc(doc(db, "users", uid), docData);

            return createResponse({ id: uid, ...docData });
          } catch (error: any) {
            console.error("Error creating student:", error);
            if (error.code === "auth/email-already-in-use") {
              // Find existing user and update
              const q = query(
                collection(db, "users"),
                where("email", "==", cleanEmail),
              );
              const querySnapshot = await getDocs(q);
              if (!querySnapshot.empty) {
                const existingUid = querySnapshot.docs[0].id;
                const docData = {
                  ...restBody,
                  email: cleanEmail,
                  role: "student",
                  status: "approved",
                  updated_at: new Date().toISOString(),
                };
                await updateDoc(doc(db, "users", existingUid), docData);
                return createResponse({ id: existingUid, ...docData });
              }
              return createResponse({ error: "Email is already in use" }, 409);
            }
            if (
              error.message &&
              error.message.includes("insufficient permissions")
            ) {
              handleFirestoreError(error, OperationType.WRITE, "users");
            }
            throw error;
          }
        }
      }

      if (path.startsWith("students/")) {
        const id = path.split("/")[1];
        if (method === "GET") {
          const docSnap = await getDoc(doc(db, "users", id));
          if (docSnap.exists()) {
            // Fetch related data
            const [attendanceSnap, paymentsSnap, resultsSnap] =
              await Promise.all([
                getDocs(
                  query(
                    collection(db, "attendance"),
                    where("student_id", "==", id),
                  ),
                ),
                getDocs(
                  query(
                    collection(db, "payments"),
                    where("student_id", "==", id),
                  ),
                ),
                getDocs(
                  query(
                    collection(db, "results"),
                    where("student_id", "==", id),
                  ),
                ),
              ]);

            // Also check by roll number if student_id was stored as roll
            let attendanceRecords = attendanceSnap.docs.map((d) => ({
              ...d.data(),
              id: d.id,
            }));
            if (attendanceRecords.length === 0 && docSnap.data().roll_number) {
              const rollSnap = await getDocs(
                query(
                  collection(db, "attendance"),
                  where("student_id", "==", String(docSnap.data().roll_number)),
                ),
              );
              attendanceRecords = rollSnap.docs.map((d) => ({
                ...d.data(),
                id: d.id,
              }));
            }

            return createResponse({
              id: docSnap.id,
              ...docSnap.data(),
              attendance: attendanceRecords,
              payments: paymentsSnap.docs.map((d) => ({
                ...d.data(),
                id: d.id,
              })),
              results: resultsSnap.docs.map((d) => ({ ...d.data(), id: d.id })),
            });
          }
          return createResponse({ error: "Not found" }, 404);
        }
        if (method === "PUT") {
          try {
            // Remove undefined values and relation arrays so we don't save nested giant arrays in Firestore users doc
            const {
              id: _id,
              attendance,
              payments,
              results,
              ...restBody
            } = body;
            const sanitizedBody = Object.fromEntries(
              Object.entries(restBody).filter(([_, v]) => v !== undefined),
            );
            await updateDoc(doc(db, "users", id), sanitizedBody);
            return createResponse({ success: true });
          } catch (error: any) {
            console.error("Error updating student:", error);
            if (
              error.message &&
              error.message.includes("insufficient permissions")
            ) {
              handleFirestoreError(error, OperationType.WRITE, "users");
            }
            return createResponse(
              { error: error.message || "Failed to update student" },
              500,
            );
          }
        }
        if (method === "PATCH" && path.endsWith("/status")) {
          await updateDoc(doc(db, "users", id), { status: body.status });
          return createResponse({ success: true });
        }
        if (method === "DELETE") {
          try {
            const batchRef = writeBatch(db);

            // Delete the user document
            batchRef.delete(doc(db, "users", id));

            // Delete related data
            const attendanceSnap = await getDocs(
              query(
                collection(db, "attendance"),
                where("student_id", "==", id),
              ),
            );
            attendanceSnap.docs.forEach((d) => batchRef.delete(d.ref));

            const paymentsSnap = await getDocs(
              query(collection(db, "payments"), where("student_id", "==", id)),
            );
            paymentsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            const resultsSnap = await getDocs(
              query(collection(db, "results"), where("student_id", "==", id)),
            );
            resultsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            const materialsSnap = await getDocs(
              query(
                collection(db, "study_materials"),
                where("student_id", "==", id),
              ),
            );
            materialsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            const enrollmentsSnap = await getDocs(
              query(
                collection(db, "enrollments"),
                where("student_id", "==", id),
              ),
            );
            enrollmentsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            await batchRef.commit();
            return createResponse({ success: true });
          } catch (error: any) {
            console.error("Error deleting student:", error);
            if (
              error.message &&
              error.message.includes("insufficient permissions")
            ) {
              handleFirestoreError(error, OperationType.DELETE, "users");
            }
            return createResponse(
              { error: error.message || "Failed to delete student" },
              500,
            );
          }
        }
      }

      // ----------------------------------------------------------------------
      // ATTENDANCE
      // ----------------------------------------------------------------------
      if (path === "attendance/mark-present" && method === "POST") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        const { batch_id, date, type, exam_id } = body;

        // Check if already marked for this day
        const q = query(
          collection(db, "attendance"),
          where("student_id", "==", uid),
          where("date", "==", date),
        );
        const snapshot = await getDocs(q);

        // Filter by type if needed
        const existing = snapshot.docs.find((d) => {
          const data = d.data();
          if (type === "exam") {
            return data.type === "exam" && data.exam_id === exam_id;
          }
          return data.type !== "exam";
        });

        if (existing) {
          // If it was 'absent', update to 'present'
          if (existing.data().status === "absent") {
            await updateDoc(doc(db, "attendance", existing.id), {
              status: "present",
              updated_at: new Date().toISOString(),
              time: new Date().toLocaleTimeString(),
            });
          }
          return createResponse({
            success: true,
            message: "Already marked or updated",
          });
        }

        // Create new present record
        const docData: any = {
          student_id: uid,
          batch_id: batch_id || null,
          date,
          status: "present",
          type: type || "class",
          time: new Date().toLocaleTimeString(),
          created_at: new Date().toISOString(),
          method: "automatic",
        };
        if (exam_id) docData.exam_id = exam_id;

        await addDoc(collection(db, "attendance"), docData);
        return createResponse({ success: true, record: docData });
      }

      if (path.startsWith("attendance/") && method === "PUT") {
        const id = path.split("/")[1];
        if (id && id !== "mark-present" && id !== "auto-absent" && id !== "batch" && id !== "report") {
          await updateDoc(doc(db, "attendance", id), {
            ...body,
            updated_at: new Date().toISOString(),
          });
          return createResponse({ success: true });
        }
      }

      if (path === "attendance") {
        if (method === "POST") {
          if (!body.records) {
            // single post
            const docRef = await addDoc(collection(db, "attendance"), {
              ...body,
              created_at: new Date().toISOString(),
            });
            return createResponse({ success: true, id: docRef.id });
          }
          
          const { batch_id, date, time, records } = body;
          const results = [];

          // Fetch existing records for this batch and date ONCE to avoid multiple queries
          const existingSnap = await getDocs(
            query(
              collection(db, "attendance"),
              where("batch_id", "==", batch_id),
            ),
          );
          const existingRecords = existingSnap.docs.filter(
            (d) => d.data().date === date,
          );
          const existingMap = new Map(
            existingRecords.map((d) => [d.data().student_id, d.id]),
          );

          // Use Promise.all to handle multiple records
          await Promise.all(
            records.map(async (record: any) => {
              const docData: any = {
                batch_id,
                date,
                time,
                student_id: record.student_id,
                status: record.status,
                created_at: new Date().toISOString(),
              };
              if (body.type) docData.type = body.type;
              if (body.exam_id) docData.exam_id = body.exam_id;

              let existingDocId;
              if (body.type === "exam") {
                const existingExamRecords = existingSnap.docs.filter((d) => {
                  const data = d.data();
                  return (
                    data.date === date &&
                    data.type === "exam" &&
                    String(data.exam_id) === String(body.exam_id)
                  );
                });
                const existingExamMap = new Map(
                  existingExamRecords.map((d) => [d.data().student_id, d.id]),
                );
                existingDocId = existingExamMap.get(record.student_id);
              } else {
                const existingClassRecords = existingSnap.docs.filter(
                  (d) => d.data().date === date && d.data().type !== "exam",
                );
                const existingClassMap = new Map(
                  existingClassRecords.map((d) => [d.data().student_id, d.id]),
                );
                existingDocId = existingClassMap.get(record.student_id);
              }

              if (existingDocId) {
                // Update existing
                await updateDoc(doc(db, "attendance", existingDocId), docData);
                results.push({ id: existingDocId, ...docData });
              } else {
                // Create new
                const docRef = await addDoc(
                  collection(db, "attendance"),
                  docData,
                );
                results.push({ id: docRef.id, ...docData });
              }
            }),
          );

          return createResponse({ success: true, records: results });
        }
      }

      if (path.startsWith("attendance/batch/")) {
        const parts = path.split("/");
        const batchId = parts[2];
        const date = parts[3];

        if (method === "GET") {
          const studentsSnap = await getDocs(
            query(collection(db, "users"), where("role", "==", "student")),
          );
          const students = studentsSnap.docs
            .filter(
              (d) =>
                String(d.data().batch_id) === String(batchId) ||
                String(d.data().batch_id_2) === String(batchId),
            )
            .map((d) => ({ ...d.data(), id: d.id }));

          const attendanceSnap = await getDocs(
            query(
              collection(db, "attendance"),
              where("batch_id", "==", batchId),
            ),
          );
          const markedIds = attendanceSnap.docs
            .filter((d) => d.data().date === date)
            .map((d) => d.data().student_id);

          return createResponse({ students, markedStudents: markedIds });
        }
      }

      if (path.startsWith("attendance/report")) {
        try {
          const urlObj = new URL(url, window.location.origin);
          const batch_id = urlObj.searchParams.get("batch_id");
          const program_id = urlObj.searchParams.get("program_id");
          const startDate = urlObj.searchParams.get("startDate");
          const endDate = urlObj.searchParams.get("endDate");
          const type = urlObj.searchParams.get("type");
          const status = urlObj.searchParams.get("status");

          let snapshot;
          // Fetch base records: use batch_id if provided to limit data size
          if (batch_id && batch_id !== "all" && batch_id !== "") {
            snapshot = await getDocs(
              query(
                collection(db, "attendance"),
                where("batch_id", "==", batch_id),
              ),
            );
          } else {
            snapshot = await getDocs(collection(db, "attendance"));
          }

          let records = snapshot.docs.map((d) => ({
            id: d.id,
            ...(d.data() as any),
          }));

          // In-memory filtering to avoid requiring Firestore composite indexes
          if (type) records = records.filter((r) => r.type === type);
          if (status) records = records.filter((r) => r.status === status);
          if (startDate) records = records.filter((r) => r.date >= startDate);
          if (endDate) records = records.filter((r) => r.date <= endDate);

          // Optimize enrichment by gathering unique IDs first
          const uniqueStudentIds = [
            ...new Set(records.map((r) => r.student_id).filter(Boolean)),
          ];
          const uniqueBatchIds = [
            ...new Set(records.map((r) => r.batch_id).filter(Boolean)),
          ];

          const studentCache = new Map();
          const batchCache = new Map();

          // Fetch all needed students in batches
          const chunkSize = 10;
          for (let i = 0; i < uniqueStudentIds.length; i += chunkSize) {
            const chunk = uniqueStudentIds.slice(i, i + chunkSize);
            await Promise.all(
              chunk.map(async (id) => {
                try {
                  const snap = await getDoc(doc(db, "users", String(id)));
                  if (snap.exists()) studentCache.set(id, snap.data());
                } catch (e) {
                  console.warn(`Could not fetch student ${id}:`, e);
                }
              }),
            );
          }

          // Fetch batches
          for (let i = 0; i < uniqueBatchIds.length; i += chunkSize) {
            const chunk = uniqueBatchIds.slice(i, i + chunkSize);
            await Promise.all(
              chunk.map(async (id) => {
                try {
                  const snap = await getDoc(doc(db, "batches", String(id)));
                  if (snap.exists()) batchCache.set(id, snap.data());
                } catch (e) {
                  console.warn(`Could not fetch batch ${id}:`, e);
                }
              }),
            );
          }

          // Fetch students and batches to enrich the data (and filter by program_id if needed)
          let enrichedRecords = records.map((record: any) => {
            let studentName = "Unknown";
            let rollNumber = "Unknown";
            let batchName = "Unknown";
            let studentProgramId = "";

            if (record.student_id) {
              const studentData = studentCache.get(record.student_id);
              if (studentData) {
                studentName = studentData.name || "Unknown";
                rollNumber = studentData.roll_number || "Unknown";
                studentProgramId = studentData.program_id || "";
              }
            }

            if (record.batch_id) {
              const batchData = batchCache.get(record.batch_id);
              if (batchData) {
                batchName = batchData.name || "Unknown";
                if (!studentProgramId) {
                  studentProgramId = batchData.program_id || "";
                }
              }
            }

            return {
              ...record,
              student_name: studentName,
              roll_number: rollNumber,
              batch_name: batchName,
              program_id: studentProgramId,
            };
          });

          if (program_id) {
            enrichedRecords = enrichedRecords.filter(
              (r) => r.program_id === program_id,
            );
          }

          return createResponse(enrichedRecords);
        } catch (error) {
          console.error("Error generating attendance report:", error);
          return createResponse(
            { error: "Failed to generate attendance report" },
            500,
          );
        }
      }

      // ----------------------------------------------------------------------
      // MY PROFILE (STUDENT DASHBOARD)
      // ----------------------------------------------------------------------
      if (path === "my-profile/image") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        if (method === "POST") {
          await updateDoc(doc(db, "users", uid), {
            profile_pic: body.image_url,
          });
          return createResponse({ success: true });
        }
      }

      if (path === "my-profile") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        if (method === "PUT") {
          await updateDoc(doc(db, "users", uid), body);
          return createResponse({ success: true });
        }

        const userSnap = await getDoc(doc(db, "users", uid));
        if (!userSnap.exists())
          return createResponse({ error: "User not found" }, 404);

        const userData = userSnap.data();

        // Parallelize main data fetches
        const [attendanceSnap, paymentsSnap, resultsSnap] = await Promise.all([
          getDocs(
            query(collection(db, "attendance"), where("student_id", "==", uid)),
          ),
          getDocs(
            query(collection(db, "payments"), where("student_id", "==", uid)),
          ),
          getDocs(
            query(collection(db, "results"), where("student_id", "==", uid)),
          ),
        ]);

        let batchData = null;
        let batch_name = "Regular Batch";
        let programData = null;

        if (userData.batch_id) {
          const batchSnap = await getDoc(doc(db, "batches", userData.batch_id));
          if (batchSnap.exists()) {
            batchData = { id: batchSnap.id, ...batchSnap.data() };
            batch_name =
              batchData.name || batchData.batch_name || "Regular Batch";

            if (batchData.program_id) {
              const programSnap = await getDoc(
                doc(db, "programs", batchData.program_id),
              );
              if (programSnap.exists()) {
                programData = { id: programSnap.id, ...programSnap.data() };
              }
            }
          }
        }

        // Cache for batch/program info to avoid redundant fetches in results loop
        const batchCache = new Map();
        if (batchData) batchCache.set(userData.batch_id, batchData);

        const results = await Promise.all(
          resultsSnap.docs.map(async (d) => {
            const data = d.data();
            let b_name = "N/A";
            let b_class = "N/A";

            if (data.batch_id) {
              let bData = batchCache.get(data.batch_id);
              if (!bData) {
                const bSnap = await getDoc(doc(db, "batches", data.batch_id));
                if (bSnap.exists()) {
                  bData = bSnap.data();
                  batchCache.set(data.batch_id, bData);
                }
              }
              if (bData) {
                b_name = bData.name || bData.batch_name || "N/A";
                b_class = bData.class_name || bData.batch_class || "N/A";
              }
            }

            // Merit position calculation is expensive, only do it if needed
            let merit_position = data.merit_position || "";
            // For performance, we'll skip the live merit calculation here if it's not already stored
            // or we could implement a more efficient way to get it.

            return {
              id: d.id,
              ...data,
              batch_name: b_name,
              batch_class: b_class,
              merit_position,
            };
          }),
        );

        return createResponse({
          user: { id: uid, ...userData, batch_name },
          batch: batchData,
          program: programData,
          attendance: attendanceSnap.docs.map((d) => ({
            ...d.data(),
            id: d.id,
          })),
          payments: paymentsSnap.docs.map((d) => ({ ...d.data(), id: d.id })),
          results,
        });
      }

      // ----------------------------------------------------------------------
      // MODERATORS
      // ----------------------------------------------------------------------
      if (path === "moderators") {
        if (method === "GET") {
          const q = query(
            collection(db, "users"),
            where("role", "==", "moderator"),
          );
          const snapshot = await getDocs(q);
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        }
        if (method === "POST") {
          const { email, password, ...restBody } = body;
          if (!email || !password) {
            return createResponse(
              { error: "Email and password are required" },
              400,
            );
          }

          const cleanEmail = email.trim();

          // Simple email validation
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(cleanEmail)) {
            return createResponse({ error: "Invalid email format" }, 400);
          }

          try {
            const userCredential = await createUserWithEmailAndPassword(
              secondaryAuth,
              cleanEmail,
              password,
            );
            const uid = userCredential.user.uid;

            const docData = {
              ...restBody,
              email: cleanEmail,
              role: "moderator",
              created_at: new Date().toISOString(),
            };
            await setDoc(doc(db, "users", uid), docData);

            return createResponse({ id: uid, ...docData });
          } catch (error: any) {
            console.error("Error creating moderator:", error);
            if (error.code === "auth/email-already-in-use") {
              // Find existing user and update
              const q = query(
                collection(db, "users"),
                where("email", "==", cleanEmail),
              );
              const querySnapshot = await getDocs(q);
              if (!querySnapshot.empty) {
                const existingUid = querySnapshot.docs[0].id;
                const docData = {
                  ...restBody,
                  email: cleanEmail,
                  role: "moderator",
                  updated_at: new Date().toISOString(),
                };
                await updateDoc(doc(db, "users", existingUid), docData);
                return createResponse({ id: existingUid, ...docData });
              }
              return createResponse({ error: "Email is already in use" }, 409);
            }
            throw error;
          }
        }
      }
      if (path.startsWith("moderators/")) {
        const id = path.split("/")[1];
        if (method === "DELETE") {
          await deleteDoc(doc(db, "users", id));
          return createResponse({ success: true });
        }
      }

      // ----------------------------------------------------------------------
      // STUDENT SEARCH
      // ----------------------------------------------------------------------
      if (path.startsWith("student-search")) {
        const urlObj = new URL(url, window.location.origin);
        const batch_id = urlObj.searchParams.get("batch_id");
        const roll_number = urlObj.searchParams.get("roll_number");

        if (!roll_number)
          return createResponse({ error: "Missing search term" }, 400);

        const target = String(roll_number).trim();

        // Much faster localized queries instead of fetching all 1000s of users.
        // 1. Check if ID matches directly
        let studentDoc: any = null;
        try {
          const idSnap = await getDoc(doc(db, "users", target));
          if (idSnap.exists() && idSnap.data().role === "student") {
            studentDoc = idSnap;
          }
        } catch (e) {}

        // 2. Query by roll_number or phone
        if (!studentDoc) {
          const snaps = await Promise.all([
            getDocs(
              query(
                collection(db, "users"),
                where("roll_number", "==", target),
                where("role", "==", "student"),
              ),
            ),
            getDocs(
              query(
                collection(db, "users"),
                where("roll_number", "==", Number(target)),
                where("role", "==", "student"),
              ),
            ),
            getDocs(
              query(
                collection(db, "users"),
                where("phone", "==", target),
                where("role", "==", "student"),
              ),
            ),
          ]);

          for (const snap of snaps) {
            if (!snap.empty) {
              studentDoc = snap.docs[0];
              break;
            }
          }
        }

        if (!studentDoc)
          return createResponse({ error: "Student not found" }, 404);

        const studentId = studentDoc.id;

        const [attendanceSnap, paymentsSnap, resultsSnap] = await Promise.all([
          getDocs(
            query(
              collection(db, "attendance"),
              where("student_id", "==", studentId),
            ),
          ),
          getDocs(
            query(
              collection(db, "payments"),
              where("student_id", "==", studentId),
            ),
          ),
          getDocs(
            query(
              collection(db, "results"),
              where("student_id", "==", studentId),
            ),
          ),
        ]);

        return createResponse({
          id: studentId,
          ...studentDoc.data(),
          attendance: attendanceSnap.docs.map((d) => ({
            ...d.data(),
            id: d.id,
          })),
          payments: paymentsSnap.docs.map((d) => ({ ...d.data(), id: d.id })),
          results: resultsSnap.docs.map((d) => ({ ...d.data(), id: d.id })),
        });
      }

      // ----------------------------------------------------------------------
      // MY ENROLLMENTS
      // ----------------------------------------------------------------------
      if (path === "my-enrollments") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        const userSnap = await getDoc(doc(db, "users", uid));
        if (!userSnap.exists())
          return createResponse({ error: "User not found" }, 404);

        const userData = userSnap.data();
        const queries = [
          query(collection(db, "enrollments"), where("user_id", "==", uid)),
        ];

        if (userData.phone) {
          const cleanPhone = userData.phone.replace(/\D/g, "");
          if (cleanPhone.length >= 10) {
            const last10 = cleanPhone.slice(-10);
            const variations = [
              last10,
              "0" + last10,
              "880" + last10,
              "+880" + last10,
            ];
            variations.forEach((v) => {
              queries.push(
                query(collection(db, "enrollments"), where("phone", "==", v)),
              );
            });
          } else {
            queries.push(
              query(
                collection(db, "enrollments"),
                where("phone", "==", userData.phone),
              ),
            );
          }
        }

        if (userData.email) {
          queries.push(
            query(
              collection(db, "enrollments"),
              where("email", "==", userData.email),
            ),
          );
        }

        const snapshots = await Promise.all(queries.map((q) => getDocs(q)));
        const allEnrollments = snapshots.flatMap((s) =>
          s.docs.map((d) => ({ ...d.data(), id: d.id })),
        );
        const enrollments: any[] = Array.from(
          new Map(allEnrollments.map((item) => [item.id, item])).values(),
        );

        // If the user has an academic program or course directly assigned (e.g. added via admin), add it as an enrollment
        const addAcademicEnrollment = async (
          progId: string,
          batchId: string,
          courseId: string,
          title?: string,
        ) => {
          let batchName = "";
          if (batchId) {
            const batchSnap = await getDoc(doc(db, "batches", String(batchId)));
            if (batchSnap.exists()) {
              batchName = batchSnap.data().name;
            }
          }

          let programTitle = userData.program_title;
          if (!programTitle && progId) {
            const programSnap = await getDoc(
              doc(db, "programs", String(progId)),
            );
            if (programSnap.exists()) {
              programTitle = programSnap.data().title;
            }
          }

          let courseTitle = title || userData.course_title;
          if (!courseTitle && courseId) {
            const courseSnap = await getDoc(
              doc(db, "courses", String(courseId)),
            );
            if (courseSnap.exists()) {
              courseTitle = courseSnap.data().title;
            }
          }

          const academicId = `academic-${progId || ""}-${batchId || ""}-${courseId || ""}-${uid}`;
          const isDuplicate = enrollments.some(
            (e) =>
              e.id === academicId ||
              (courseId && String(e.course_id) === String(courseId)) ||
              (progId &&
                batchId &&
                String(e.program_id) === String(progId) &&
                String(e.batch_id) === String(batchId)),
          );

          if (!isDuplicate) {
            const isOnline = userData.student_type === "online" || !!courseId;
            enrollments.push({
              id: academicId,
              program_title:
                programTitle ||
                (isOnline ? "Online Course" : "Academic Program"),
              course_title: courseTitle,
              batch_name: batchName,
              status: userData.status || "approved",
              created_at: userData.created_at || new Date().toISOString(),
              admission_fee: userData.admission_fee,
              monthly_fee: userData.monthly_fee,
              payment_method: "N/A",
              payment_number: "N/A",
              transaction_id: "Direct Admission",
              fee: userData.admission_fee || userData.price || 0,
              current_class: userData.current_class || userData.class,
              student_type: isOnline ? "online" : "offline",
              program_id: progId,
              batch_id: batchId,
              course_id: courseId,
            });
          }
        };

        if (userData.program_id || userData.batch_id || userData.course_id) {
          await addAcademicEnrollment(
            userData.program_id,
            userData.batch_id,
            userData.course_id,
          );
        }

        // Handle enrolled_courses array
        if (Array.isArray(userData.enrolled_courses)) {
          for (const course of userData.enrolled_courses) {
            if (typeof course === "string") {
              await addAcademicEnrollment("", "", course, "");
            } else {
              await addAcademicEnrollment(
                course.program_id || "",
                course.batch_id || "",
                course.id || "",
                course.title || "",
              );
            }
          }
        }

        return createResponse(enrollments);
      }

      // ----------------------------------------------------------------------
      // STUDY MATERIALS FOR STUDENT
      // ----------------------------------------------------------------------
      if (path === "study-materials/my") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        try {
          const userSnap = await getDoc(doc(db, "users", uid));
          if (!userSnap.exists())
            return createResponse({ error: "User not found" }, 404);

          const userData = userSnap.data();
          const batch_id = userData.batch_id;
          const batch_id_2 = userData.batch_id_2;
          const program_id = userData.program_id;
          const course_id = userData.course_id;

          // Fetch materials in parallel
          const fetchPromises = [
            getDocs(
              query(
                collection(db, "study_materials"),
                where("batch_id", "==", "all"),
              ),
            ),
          ];

          if (batch_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("batch_id", "==", batch_id),
                ),
              ),
            );
          if (batch_id_2)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("batch_id", "==", batch_id_2),
                ),
              ),
            );
          if (program_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("program_id", "==", program_id),
                ),
              ),
            );
          if (course_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("course_id", "==", course_id),
                ),
              ),
            );

          const snapshots = await Promise.all(fetchPromises);

          const materials = snapshots.flatMap((snap) =>
            snap.docs.map((d) => ({ ...d.data(), id: d.id })),
          );

          // Deduplicate materials by ID
          const uniqueMaterials = Array.from(
            new Map(materials.map((m) => [m.id, m])).values(),
          );

          return createResponse(uniqueMaterials);
        } catch (error) {
          console.error("Error in study-materials/my:", error);
          return createResponse({ error: "Internal Server Error" }, 500);
        }
      }

      if (path.startsWith("study-materials/student/")) {
        const id = path.split("/")[2];
        try {
          const userSnap = await getDoc(doc(db, "users", id));
          if (!userSnap.exists())
            return createResponse({ error: "User not found" }, 404);

          const userData = userSnap.data();
          const batch_id = userData.batch_id;
          const batch_id_2 = userData.batch_id_2;
          const program_id = userData.program_id;
          const course_id = userData.course_id;

          // Fetch materials in parallel
          const fetchPromises = [
            getDocs(
              query(
                collection(db, "study_materials"),
                where("batch_id", "==", "all"),
              ),
            ),
          ];

          if (batch_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("batch_id", "==", batch_id),
                ),
              ),
            );
          if (batch_id_2)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("batch_id", "==", batch_id_2),
                ),
              ),
            );
          if (program_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("program_id", "==", program_id),
                ),
              ),
            );
          if (course_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("course_id", "==", course_id),
                ),
              ),
            );

          const snapshots = await Promise.all(fetchPromises);

          const materials = snapshots.flatMap((snap) =>
            snap.docs.map((d) => ({ ...d.data(), id: d.id })),
          );

          // Deduplicate materials by ID
          const uniqueMaterials = Array.from(
            new Map(materials.map((m) => [m.id, m])).values(),
          );

          return createResponse(uniqueMaterials);
        } catch (error) {
          console.error("Error in study-materials/student:", error);
          return createResponse({ error: "Internal Server Error" }, 500);
        }
      }

      // ----------------------------------------------------------------------
      // AUTO ABSENT
      // ----------------------------------------------------------------------
      if (path === "attendance/auto-absent") {
        try {
          const { batch_id, date } = body;
          const studentsSnap = await getDocs(
            query(collection(db, "users"), where("role", "==", "student")),
          );
          const students = studentsSnap.docs.filter(
            (d) =>
              (String(d.data().batch_id) === String(batch_id) ||
                String(d.data().batch_id_2) === String(batch_id)) &&
              (d.data().status === "active" ||
                d.data().status === "approved" ||
                !d.data().status),
          );

          const attendanceSnap = await getDocs(
            query(
              collection(db, "attendance"),
              where("batch_id", "==", batch_id),
            ),
          );
          const markedIds = attendanceSnap.docs
            .filter((d) => d.data().date === date && d.data().type !== "exam")
            .map((d) => d.data().student_id);

          // Check for exams today
          const examsSnap = await getDocs(
            query(
              collection(db, "exams"),
              where("batch_id", "==", batch_id),
              where("exam_date", "==", date),
            ),
          );
          const todayExams = examsSnap.docs.map((d) => ({
            ...d.data(),
            id: d.id,
          }));

          let count = 0;

          for (const docSnap of students) {
            // Mark class attendance as absent if not marked
            if (!markedIds.includes(docSnap.id)) {
              await addDoc(collection(db, "attendance"), {
                student_id: docSnap.id,
                batch_id,
                date,
                status: "absent",
                type: "class",
                reason: "Auto",
                created_at: new Date().toISOString(),
              });
              count++;
            }

            // Mark exam attendance as absent if not marked
            for (const exam of todayExams) {
              const examMarked = attendanceSnap.docs.some(
                (d) =>
                  d.data().date === date &&
                  d.data().type === "exam" &&
                  String(d.data().exam_id) === String(exam.id) &&
                  String(d.data().student_id) === String(docSnap.id),
              );

              if (!examMarked) {
                await addDoc(collection(db, "attendance"), {
                  student_id: docSnap.id,
                  batch_id,
                  date,
                  status: "absent",
                  type: "exam",
                  exam_id: exam.id,
                  reason: "Auto",
                });
                // We don't increment count here as it's usually for class attendance,
                // but we could if we want to show total actions.
              }
            }
          }
          return createResponse({
            message: `Marked ${count} students as absent`,
            count,
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, path);
        }
      }

      // ----------------------------------------------------------------------
      // ENROLLMENTS
      // ----------------------------------------------------------------------
      if (path === "enrollments") {
        try {
          if (method === "GET") {
            const snapshot = await getDocs(collection(db, "enrollments"));
            return createResponse(
              snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
            );
          }
          if (method === "POST") {
            console.log("[Firebase Adapter] Processing Enrollment:", body);
            const {
              email,
              gmail,
              password,
              phone,
              name,
              profile_pic,
              ...rest
            } = body;
            const userEmail = email || gmail;

            let uid = null;

            // If email and password are provided, create a user account
            if (userEmail && password) {
              try {
                const userCredential = await createUserWithEmailAndPassword(
                  secondaryAuth,
                  userEmail.trim(),
                  password,
                );
                uid = userCredential.user.uid;

                const userData = {
                  ...rest,
                  name,
                  email: userEmail.trim(),
                  phone,
                  role: "student",
                  status: "pending", // Initial status is pending
                  student_type: body.course_title ? "online" : "offline",
                  profile_pic: profile_pic || "",
                  created_at: new Date().toISOString(),
                  initial_password: password,
                };

                await setDoc(doc(db, "users", uid), userData);
                console.log(
                  "[Firebase Adapter] Created user for enrollment:",
                  uid,
                );
              } catch (error: any) {
                console.error(
                  "[Firebase Adapter] Error creating user during enrollment:",
                  error,
                );
                if (error.code === "auth/email-already-in-use") {
                  // Try to find existing user UID to link the enrollment
                  try {
                    const q = query(
                      collection(db, "users"),
                      where("email", "==", userEmail.trim()),
                    );
                    const querySnapshot = await getDocs(q);
                    if (!querySnapshot.empty) {
                      uid = querySnapshot.docs[0].id;
                      console.log(
                        "[Firebase Adapter] Linked existing user to enrollment:",
                        uid,
                      );
                    }
                  } catch (qError) {
                    console.log(
                      "[Firebase Adapter] Could not query user, proceeding with null uid for enrollment",
                    );
                    // We can proceed with uid = null, the enrollment will be linked by email later
                  }
                } else {
                  return createResponse({ error: error.message }, 400);
                }
              }
            }

            const enrollmentData = {
              ...body,
              user_id: uid,
              status: "pending",
              created_at: new Date().toISOString(),
            };

            const docRef = await addDoc(
              collection(db, "enrollments"),
              enrollmentData,
            );
            return createResponse({ id: docRef.id, ...enrollmentData });
          }
        } catch (error) {
          handleFirestoreError(
            error,
            method === "GET" ? OperationType.LIST : OperationType.WRITE,
            path,
          );
        }
      }

      if (path.startsWith("enrollments/")) {
        const id = path.split("/")[1];
        if (path.endsWith("/status")) {
          if (method === "PUT" || method === "PATCH") {
            await updateDoc(doc(db, "enrollments", id), {
              status: body.status,
            });
            return createResponse({ success: true });
          }
        } else if (method === "DELETE") {
          await deleteDoc(doc(db, "enrollments", id));
          return createResponse({ success: true });
        }
      }

      if (path.startsWith("cancel-enrollment/")) {
        if (method === "DELETE") {
          const id = path.split("/")[1];
          try {
            const enrollmentRef = doc(db, "enrollments", id);
            const enrollmentDoc = await getDoc(enrollmentRef);
            if (!enrollmentDoc.exists()) {
              return createResponse({ error: "Enrollment not found" }, 404);
            }
            const data = enrollmentDoc.data();
            if (data.status !== 'pending') {
               return createResponse({ error: "Only pending enrollments can be cancelled" }, 400);
            }
            await deleteDoc(enrollmentRef);
            return createResponse({ success: true });
          } catch (e: any) {
             return createResponse({ error: e.message }, 500);
          }
        }
      }

      // ----------------------------------------------------------------------
      // MESSAGES
      // ----------------------------------------------------------------------
      if (path.startsWith("messages/") && path.endsWith("/read")) {
        const id = path.split("/")[1];
        if (method === "PUT") {
          await updateDoc(doc(db, "messages", id), { is_read: true });
          return createResponse({ success: true });
        }
      }

      // ----------------------------------------------------------------------
      // AUTH PROFILE & PASSWORD
      // ----------------------------------------------------------------------
      if (path === "auth/profile") {
        const user = auth.currentUser;
        const uid = user?.uid;
        if (!uid || !user)
          return createResponse({ error: "Unauthorized" }, 401);

        try {
          const cleanEmail = body.email ? body.email.trim() : user.email;
          if (cleanEmail && cleanEmail !== user.email) {
            await updateEmail(user, cleanEmail);
          }
          await updateDoc(doc(db, "users", uid), {
            name: body.name,
            email: cleanEmail,
          });
          return createResponse({ success: true });
        } catch (error: any) {
          console.error("Profile update error:", error);
          return createResponse(
            { error: error.message || "Failed to update profile" },
            400,
          );
        }
      }
      if (path === "auth/password") {
        const user = auth.currentUser;
        if (!user) return createResponse({ error: "Unauthorized" }, 401);

        const { oldPassword, newPassword } = body;
        if (!oldPassword || !newPassword)
          return createResponse({ error: "Missing passwords" }, 400);

        try {
          if (user.email) {
            const credential = EmailAuthProvider.credential(
              user.email,
              oldPassword,
            );
            await reauthenticateWithCredential(user, credential);
            await updatePassword(user, newPassword);
            return createResponse({
              success: true,
              message: "Password updated successfully",
            });
          } else {
            return createResponse({ error: "User email not found" }, 400);
          }
        } catch (error: any) {
          console.error("Password update error:", error);
          return createResponse(
            { error: error.message || "Failed to update password" },
            400,
          );
        }
      }

      // ----------------------------------------------------------------------
      // PAYMENTS
      // ----------------------------------------------------------------------
      if (path === "payments" && method === "GET") {
        const snapshot = await getDocs(collection(db, "payments"));
        const payments = snapshot.docs
          .map((d) => ({ ...d.data(), id: d.id }))
          .filter((p: any) => !p.hidden_from_admin);

        const enrichedPayments = await Promise.all(
          payments.map(async (p: any) => {
            if (!p.student_name && p.student_id) {
              const studentSnap = await getDoc(doc(db, "users", p.student_id));
              if (studentSnap.exists()) {
                p.student_name = studentSnap.data().name || "Unknown";
                p.roll_number = studentSnap.data().roll_number || "Unknown";
                if (!p.batch_name && studentSnap.data().batch_id) {
                  const batchSnap = await getDoc(
                    doc(db, "batches", studentSnap.data().batch_id),
                  );
                  if (batchSnap.exists()) {
                    p.batch_name = batchSnap.data().name || "Unknown";
                  }
                }
              }
            }
            return p;
          }),
        );

        return createResponse(enrichedPayments);
      }

      // ----------------------------------------------------------------------
      // LIVE CHAT MESSAGES
      // ----------------------------------------------------------------------
      if (path === "live-chat-messages") {
        if (method === "GET") {
          const urlObj = new URL(url, window.location.origin);
          const class_id = urlObj.searchParams.get("class_id");
          if (!class_id)
            return createResponse({ error: "Missing class_id" }, 400);

          const q = query(
            collection(db, "live_chat_messages"),
            where("class_id", "==", class_id),
            orderBy("created_at", "asc"),
          );
          const snapshot = await getDocs(q);
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        }
        if (method === "POST") {
          const docRef = await addDoc(collection(db, "live_chat_messages"), {
            ...body,
            created_at: new Date().toISOString(),
          });
          return createResponse({ id: docRef.id, ...body });
        }
      }

      // ----------------------------------------------------------------------
      // RESET DATA
      // ----------------------------------------------------------------------
      if (path === "reset-data" && method === "POST") {
        const { type } = body;
        let collectionName = "";
        let studentTypeFilter = "";

        if (type === "students" || type === "offline_students") {
          collectionName = "users";
          studentTypeFilter = "offline";
        } else if (type === "online_students") {
          collectionName = "users";
          studentTypeFilter = "online";
        } else if (type === "batches") collectionName = "batches";
        else if (type === "payments") collectionName = "payments";
        else if (type === "enrollments") collectionName = "enrollments";
        else if (type === "attendance") collectionName = "attendance";

        if (collectionName) {
          let q: any = collection(db, collectionName);
          if (collectionName === "users") {
            if (studentTypeFilter === "online") {
              q = query(
                collection(db, "users"),
                where("role", "==", "student"),
                where("student_type", "==", "online"),
              );
            } else if (studentTypeFilter === "offline") {
              // For offline, we check role == student and student_type != online (or == offline)
              q = query(
                collection(db, "users"),
                where("role", "==", "student"),
                where("student_type", "!=", "online"),
              );
            } else {
              q = query(
                collection(db, "users"),
                where("role", "==", "student"),
              );
            }
          }

          const snapshot = await getDocs(q);
          const updatePromises = snapshot.docs.map((d) => {
            return deleteDoc(doc(db, collectionName, d.id));
          });
          await Promise.all(updatePromises);
          return createResponse({
            success: true,
            message: `All ${type} deleted successfully.`,
          });
        }
        return createResponse({ error: "Invalid type" }, 400);
      }

      // ----------------------------------------------------------------------
      // GENERIC COLLECTIONS (GET, POST, DELETE)
      // ----------------------------------------------------------------------
      const genericCollections = [
        "batches",
        "programs",
        "web-recorded-classes",
        "web-class-schedules",
        "courses",
        "gallery",
        "messages",
        "enrollments",
        "chapters",
        "exams",
        "routines",
        "resources",
        "notices",
        "study-materials",
        "payments",
        "results",
        "result-histories",
        "live-classes",
        "reviews",
        "video-classes",
        "class-slides",
        "degrees",
      ];

      // Check if path matches a generic collection or an ID within it
      const collectionMatch = genericCollections.find(
        (c) => path === c || path.startsWith(`${c}/`),
      );

      if (collectionMatch) {
        const collectionName = collectionMatch.replace(/-/g, "_"); // e.g. web-recorded-classes -> web_recorded_classes
        const id = path.split("/")[1];

        if (method === "GET") {
          const urlObj = new URL(url, window.location.origin);
          let q: any = collection(db, collectionName);

          // Support common filters
          const examId = urlObj.searchParams.get("exam_id");
          const studentId = urlObj.searchParams.get("student_id");
          const batchId = urlObj.searchParams.get("batch_id");

          const constraints = [];
          if (examId) constraints.push(where("exam_id", "==", examId));
          if (studentId) constraints.push(where("student_id", "==", studentId));
          if (batchId) constraints.push(where("batch_id", "==", batchId));

          if (constraints.length > 0) {
            q = query(q, ...constraints);
          }

          const snapshot = await getDocs(q);
          let data = snapshot.docs.map((d) => ({
            ...(d.data() as any),
            id: d.id,
          }));

          // Sort in memory if created_at exists to be safer
          if (data.some((d) => d.created_at)) {
            data.sort((a, b) => {
              const dateA = a.created_at ? new Date(a.created_at).getTime() : 0;
              const dateB = b.created_at ? new Date(b.created_at).getTime() : 0;
              return dateB - dateA;
            });
          }

          return createResponse(data);
        }

        if (method === "POST") {
          console.log(`[Firebase Adapter] POST /api/${path}`, body);
          const docData = { ...body, created_at: new Date().toISOString() };
          const docRef = await addDoc(collection(db, collectionName), docData);
          return createResponse({ id: docRef.id, ...(docData as any) });
        }

        if (method === "PUT" && id) {
          await updateDoc(doc(db, collectionName, id), body);
          return createResponse({ success: true });
        }

        if (method === "DELETE" && id) {
          console.log(
            `[Firebase Adapter] DELETE Request - Collection: ${collectionName}, ID: ${id}`,
          );
          const docId = id.trim();
          if (collectionName === "payments") {
            await updateDoc(doc(db, collectionName, docId), {
              hidden_from_admin: true,
            });
          } else if (collectionName === "batches") {
            // Cascading delete for batches
            const batchId = docId;
            const batchRef = writeBatch(db);

            // Delete the batch itself
            batchRef.delete(doc(db, "batches", batchId));

            // Delete students in this batch
            const studentsSnap = await getDocs(
              query(collection(db, "users"), where("batch_id", "==", batchId)),
            );
            studentsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete exams for this batch
            const examsSnap = await getDocs(
              query(collection(db, "exams"), where("batch_id", "==", batchId)),
            );
            examsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete results for this batch
            const resultsSnap = await getDocs(
              query(
                collection(db, "results"),
                where("batch_id", "==", batchId),
              ),
            );
            resultsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete attendance for this batch
            const attendanceSnap = await getDocs(
              query(
                collection(db, "attendance"),
                where("batch_id", "==", batchId),
              ),
            );
            attendanceSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete payments for this batch
            const paymentsSnap = await getDocs(
              query(
                collection(db, "payments"),
                where("batch_id", "==", batchId),
              ),
            );
            paymentsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete study materials for this batch
            const materialsSnap = await getDocs(
              query(
                collection(db, "study_materials"),
                where("batch_id", "==", batchId),
              ),
            );
            materialsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete routines for this batch
            const routinesSnap = await getDocs(
              query(
                collection(db, "routines"),
                where("batch_id", "==", batchId),
              ),
            );
            routinesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete notices for this batch
            const noticesSnap = await getDocs(
              query(
                collection(db, "notices"),
                where("batch_id", "==", batchId),
              ),
            );
            noticesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete live classes for this batch
            const liveClassesSnap = await getDocs(
              query(
                collection(db, "live_classes"),
                where("batch_id", "==", batchId),
              ),
            );
            liveClassesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete video classes for this batch
            const videoClassesSnap = await getDocs(
              query(
                collection(db, "video_classes"),
                where("batch_id", "==", batchId),
              ),
            );
            videoClassesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete class slides for this batch
            const classSlidesSnap = await getDocs(
              query(
                collection(db, "class_slides"),
                where("batch_id", "==", batchId),
              ),
            );
            classSlidesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            await batchRef.commit();
            return createResponse({ success: true });
          } else if (collectionName === "exams") {
            // Cascading delete for exams
            const examId = docId;
            const batchRef = writeBatch(db);

            // Delete the exam itself
            batchRef.delete(doc(db, "exams", examId));

            // Delete results for this exam
            const resultsSnap = await getDocs(
              query(collection(db, "results"), where("exam_id", "==", examId)),
            );
            resultsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            await batchRef.commit();
            return createResponse({ success: true });
          } else if (collectionName === "programs") {
            // Cascading delete for programs
            const programId = id;
            const batchRef = writeBatch(db);

            // Delete the program itself
            batchRef.delete(doc(db, "programs", programId));

            // Delete batches in this program
            const batchesSnap = await getDocs(
              query(
                collection(db, "batches"),
                where("program_id", "==", programId),
              ),
            );
            batchesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete students in this program
            const studentsSnap = await getDocs(
              query(
                collection(db, "users"),
                where("program_id", "==", programId),
              ),
            );
            studentsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete exams for this program
            const examsSnap = await getDocs(
              query(
                collection(db, "exams"),
                where("program_id", "==", programId),
              ),
            );
            examsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete results for this program
            const resultsSnap = await getDocs(
              query(
                collection(db, "results"),
                where("program_id", "==", programId),
              ),
            );
            resultsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete attendance for this program
            const attendanceSnap = await getDocs(
              query(
                collection(db, "attendance"),
                where("program_id", "==", programId),
              ),
            );
            attendanceSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete payments for this program
            const paymentsSnap = await getDocs(
              query(
                collection(db, "payments"),
                where("program_id", "==", programId),
              ),
            );
            paymentsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete study materials for this program
            const materialsSnap = await getDocs(
              query(
                collection(db, "study_materials"),
                where("program_id", "==", programId),
              ),
            );
            materialsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete routines for this program
            const routinesSnap = await getDocs(
              query(
                collection(db, "routines"),
                where("program_id", "==", programId),
              ),
            );
            routinesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete notices for this program
            const noticesSnap = await getDocs(
              query(
                collection(db, "notices"),
                where("program_id", "==", programId),
              ),
            );
            noticesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete live classes for this program
            const liveClassesSnap = await getDocs(
              query(
                collection(db, "live_classes"),
                where("program_id", "==", programId),
              ),
            );
            liveClassesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            await batchRef.commit();
            return createResponse({ success: true });
          } else {
            console.log(
              `[Firebase Adapter] Deleting document from ${collectionName} with ID: ${docId}`,
            );
            await deleteDoc(doc(db, collectionName, docId));
          }
          return createResponse({ success: true });
        }
      }

      // Fallback for unhandled routes
      console.warn(
        `[Firebase Adapter] Unhandled route: ${method} /api/${path}`,
      );
      return createResponse(
        { error: "Route not implemented in Firebase Adapter" },
        404,
      );
    } catch (error: any) {
      console.error(
        `[Firebase Adapter] Error processing ${method} /api/${path}:`,
        error,
      );
      return createResponse({ error: error.message }, 500);
    }
  },
  writable: true,
  configurable: true,
});
