import { useRealtimeCollection } from '../hooks/useRealtime';
import { orderBy } from 'firebase/firestore';
import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Search, Calendar, Clock, Youtube, Filter, LayoutGrid, List } from 'lucide-react';
import DashboardLoading from '../components/DashboardLoading';

const RecordedClasses = () => {
  const { data: classes, loading } = useRealtimeCollection('web_recorded_classes', [orderBy('created_at', 'desc')]);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredClasses = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (q === '') return classes;
    return classes.filter(c => 
      c.title?.toLowerCase().includes(q) || 
      (c.batch_id && String(c.batch_id).toLowerCase().includes(q))
    );
  }, [searchQuery, classes]);

  const getYoutubeThumbnail = (url: string) => {
    const regExp = /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    if (match && match[2].length === 11) {
      return `https://img.youtube.com/vi/${match[2]}/maxresdefault.jpg`;
    }
    return 'https://picsum.photos/seed/physics/800/450';
  };

  // Only show loading if we literally have no data and it's the first load
  // if (loading && classes.length === 0) return <DashboardLoading />;

  return (
    <div className="min-h-screen pt-4 md:pt-8 pb-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h1 className="text-4xl font-black text-orange-600 tracking-tight flex items-center gap-4">
              <div className="p-3 bg-orange-100 rounded-2xl">
                <Youtube className="h-8 w-8 text-orange-600" />
              </div>
              Recorded Classes
            </h1>
            <p className="text-slate-500 mt-2 font-medium text-lg">Access previous lectures and revision materials anytime.</p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-wrap items-center gap-4 w-full md:w-auto"
          >
            <div className="relative flex-1 md:w-80 group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-orange-500 transition-colors" />
              <input 
                type="text" 
                placeholder="Search by title or batch..." 
                className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl shadow-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all font-medium"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-2.5 rounded-xl transition-all ${viewMode === 'grid' ? 'bg-orange-600 text-white shadow-lg shadow-orange-200' : 'text-slate-400 hover:bg-slate-50'}`}
              >
                <LayoutGrid className="h-5 w-5" />
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={`p-2.5 rounded-xl transition-all ${viewMode === 'list' ? 'bg-orange-600 text-white shadow-lg shadow-orange-200' : 'text-slate-400 hover:bg-slate-50'}`}
              >
                <List className="h-5 w-5" />
              </button>
            </div>
          </motion.div>
        </div>

        {/* Content Grid/List */}
        <AnimatePresence mode="wait">
          {filteredClasses.length > 0 ? (
            <motion.div 
              key={viewMode}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={viewMode === 'grid' 
                ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" 
                : "flex flex-col gap-4"
              }
            >
              {filteredClasses.map((video, index) => (
                <motion.div
                  key={video.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden hover:shadow-xl hover:shadow-orange-900/5 transition-all group ${viewMode === 'list' ? 'flex flex-col md:flex-row items-center' : ''}`}
                >
                  <a 
                    href={video.url} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className={`block relative bg-slate-900 overflow-hidden ${viewMode === 'grid' ? 'aspect-video w-full' : 'aspect-video w-full md:w-72 flex-shrink-0'}`}
                  >
                    <img 
                      src={getYoutubeThumbnail(video.url)} 
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-90 group-hover:opacity-100"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-14 h-14 bg-orange-600 rounded-full flex items-center justify-center text-white shadow-2xl transform group-hover:scale-110 transition-all duration-300">
                        <Play className="h-6 w-6 fill-current ml-1" />
                      </div>
                    </div>
                    {/* Badge */}
                    <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full border border-white/50 shadow-lg">
                      <span className="text-[10px] font-black text-orange-600 uppercase tracking-widest">
                        Batch {video.batch_id || 'All'}
                      </span>
                    </div>
                  </a>

                  <div className="p-8 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xl font-black text-slate-900 mb-4 line-clamp-2 leading-tight group-hover:text-orange-600 transition-colors">
                        {video.title}
                      </h3>
                      <div className="flex flex-wrap items-center gap-6 text-slate-400">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          <span className="text-xs font-bold">{new Date(video.created_at).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          <span className="text-xs font-bold">Recorded</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-8 flex items-center justify-between">
                      <a 
                        href={video.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm font-black text-orange-600 hover:text-orange-700 flex items-center gap-2 group/link"
                      >
                        Watch on YouTube
                        <div className="w-6 h-6 bg-orange-50 rounded-full flex items-center justify-center group-hover/link:translate-x-1 transition-transform">
                          <Play className="h-3 w-3 fill-current" />
                        </div>
                      </a>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-32 bg-white rounded-[3rem] border border-dashed border-slate-200"
            >
              <div className="max-w-xs mx-auto space-y-4">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto">
                  <Youtube className="h-10 w-10 text-slate-200" />
                </div>
                <h3 className="text-xl font-black text-slate-900">No classes found</h3>
                <p className="text-slate-500 font-medium">Try adjusting your search or check back later for new recordings.</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default RecordedClasses;
