import React from 'react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { Home, ArrowLeft } from 'lucide-react';

const NotFound = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 relative overflow-hidden px-4">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-orange-500/10 blur-[100px] rounded-full mix-blend-multiply" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[600px] h-[600px] bg-blue-500/10 blur-[100px] rounded-full mix-blend-multiply" />
        
        {/* Floating Numbers/Symbols */}
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ y: -100, x: `${Math.random() * 100}%`, opacity: 0 }}
            animate={{ 
              y: ['0vh', '110vh'],
              opacity: [0, 0.4, 0.4, 0],
              rotate: [0, 360]
            }}
            transition={{ 
              duration: 10 + Math.random() * 15,
              repeat: Infinity,
              delay: Math.random() * 20,
              ease: "linear"
            }}
            className="absolute text-slate-300 font-mono text-2xl font-bold select-none"
          >
            {['404', '∑', '∫', 'π', '∞', '∆', 'θ', '√'][Math.floor(Math.random() * 8)]}
          </motion.div>
        ))}
      </div>

      <div className="relative z-10 text-center w-full max-w-xl">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, type: "spring" }}
          className="relative inline-block mb-8"
        >
          <motion.h1 
            className="text-9xl md:text-[150px] font-black text-transparent bg-clip-text bg-gradient-to-br from-orange-500 to-orange-600 drop-shadow-sm select-none"
            animate={{ 
              textShadow: ["0px 0px 0px rgba(249, 115, 22, 0)", "0px 10px 30px rgba(249, 115, 22, 0.3)", "0px 0px 0px rgba(249, 115, 22, 0)"]
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            404
          </motion.h1>
          <motion.div 
            className="absolute -top-4 -right-8 text-orange-400"
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" />
              <path d="M12 2v20" />
            </svg>
          </motion.div>
        </motion.div>

        <motion.h2 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold text-slate-800 mb-4 tracking-tight"
        >
          Equation Unsolvable
        </motion.h2>

        <motion.p 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-slate-500 mb-10 text-lg max-w-sm mx-auto"
        >
          We couldn't find the page you're looking for. It might have been moved or the URL is incorrect.
        </motion.p>

        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button 
            onClick={() => navigate(-1)}
            className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-white text-slate-700 font-bold text-sm uppercase tracking-widest shadow-sm border border-slate-200 hover:bg-slate-50 hover:shadow-md transition-all flex items-center justify-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" /> Go Back
          </button>
          
          <button 
            onClick={() => navigate('/')}
            className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-orange-600 text-white font-bold text-sm uppercase tracking-widest shadow-lg shadow-orange-500/30 border border-orange-500 hover:bg-orange-500 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2"
          >
            <Home className="h-4 w-4" /> Home
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default NotFound;
