import { db } from "../firebase";
import {
  setDoc,
  collection,
  getDocs,
  deleteDoc,
  doc,
  updateDoc,
  query,
  orderBy,
  addDoc,
  getDoc,
  where,
  limit,
  startAfter,
  endBefore,
  limitToLast,
  Timestamp,
  writeBatch,
  onSnapshot,
} from "firebase/firestore";
import { showAlert, showConfirm } from "../utils/alert";
import { Html5QrcodeScanner } from "html5-qrcode";
import { safeJson } from "../utils/api";
import React, { useState, useEffect, useMemo, useRef, memo } from "react";
import { useAuth } from "../context/AuthContext";
import { useSettings } from "../context/SettingsContext";
import { motion, AnimatePresence } from "motion/react";
import {
  Users,
  Calendar,
  CreditCard,
  BookOpen,
  Settings,
  Plus,
  Activity,
  Trash2,
  Edit,
  Edit2,
  Search,
  CheckCircle,
  XCircle,
  ChevronRight,
  LogOut,
  Copy,
  History,
  Bell,
  FileText,
  Video,
  Image as ImageIcon,
  Award,
  BarChart,
  ArrowLeft,
  Mail,
  Clock,
  Package,
  Play,
  Menu,
  ExternalLink,
  LayoutDashboard,
  TrendingUp,
  DollarSign,
  UserCheck,
  PlayCircle,
  CheckCircle2,
  Shield,
  Upload,
  Info,
  Filter,
  ChevronDown,
  Eye,
  X,
  Tag,
  RefreshCw,
  PlusCircle,
  Archive,
  Phone,
  ShieldCheck,
  User,
  UserPlus,
  Hash,
  Layers,
  UserCog,
  Save,
  GraduationCap,
  UserMinus,
  LinkIcon,
  ArrowRight,
  Youtube,
  Download,
  Share2,
  MapPin,
  Lock,
  Unlock,
  ClipboardCheck,
  MessageSquare,
  CheckSquare,
  Camera,
  Send,
  ShieldAlert,
  Database,
  Laptop,
  Loader2,
  Zap,
} from "lucide-react";

import {
  BarChart as ReBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import {
  format,
  parseISO,
  eachDayOfInterval,
  isBefore,
  startOfDay,
} from "date-fns";
import { Link, useNavigate } from "react-router-dom";

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const Skeleton: React.FC<{ className?: string }> = ({ className }) => (
  <div className={`animate-pulse bg-slate-200 rounded-xl ${className}`} />
);

const OverviewSkeleton = () => (
  <div className="space-y-6 w-full">
    <div className="flex justify-between items-center">
      <Skeleton className="h-10 w-64" />
      <Skeleton className="h-10 w-40" />
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {[1, 2, 3, 4].map((i) => (
        <div
          key={i}
          className="glass p-6 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl h-32"
        >
          <Skeleton className="h-10 w-10 mb-4" />
          <Skeleton className="h-4 w-24 mb-2" />
          <Skeleton className="h-8 w-16" />
        </div>
      ))}
    </div>
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="glass p-6 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl h-96">
        <Skeleton className="h-6 w-48 mb-6" />
        <Skeleton className="h-full w-full" />
      </div>
      <div className="glass p-6 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl h-96">
        <Skeleton className="h-6 w-48 mb-6" />
        <Skeleton className="h-full w-full" />
      </div>
    </div>
  </div>
);

const TableSkeleton = () => (
  <div className="space-y-4">
    <div className="flex justify-between items-center">
      <Skeleton className="h-10 w-48" />
      <Skeleton className="h-10 w-64" />
    </div>
    <div className="glass rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl overflow-hidden">
      <div className="p-4 border-b border-white/20">
        <Skeleton className="h-6 w-full" />
      </div>
      <div className="p-4 space-y-4">
        {[1, 2, 3, 4, 5].map((i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    </div>
  </div>
);

const VideoSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-10 w-64" />
    <div className="glass p-6 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl h-64">
      <Skeleton className="h-6 w-48 mb-4" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-10 w-full" />
      </div>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div
          key={i}
          className="glass rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl overflow-hidden h-64"
        >
          <Skeleton className="h-40 w-full" />
          <div className="p-4 space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
          </div>
        </div>
      ))}
    </div>
  </div>
);

const DebouncedInput = ({ value, onChange, debounce = 300, onEnter, onKeyDown, ...props }: any) => {
  const [internalVal, setInternalVal] = useState(value || "");

  useEffect(() => {
    setInternalVal(value || "");
  }, [value]);

  useEffect(() => {
    const handler = setTimeout(() => {
      if (internalVal !== (value || "")) {
        onChange(internalVal);
      }
    }, debounce);
    return () => clearTimeout(handler);
  }, [internalVal, debounce, onChange, value]);

  return (
    <input
      value={internalVal}
      onChange={(e) => setInternalVal(e.target.value)}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          onChange(internalVal);
          if (onEnter) onEnter(internalVal);
        }
        if (onKeyDown) onKeyDown(e);
      }}
      {...props}
    />
  );
};

const SidebarItem = memo(({ item, activeTab, onClick }: any) => (
  <button
    onClick={() => onClick(item.id)}
    className={`flex items-center space-x-3 w-full px-4 py-2.5 rounded-xl transition-all duration-300 ${
      activeTab === item.id
        ? "bg-orange-600 text-white shadow-lg shadow-orange-900/20 translate-x-1"
        : "text-slate-500 hover:bg-orange-50 hover:text-orange-600 hover:translate-x-1"
    }`}
  >
    <item.icon className={`h-5 w-5 ${activeTab === item.id ? "animate-pulse" : ""}`} />
    <span className="font-bold text-sm tracking-tight">{item.label}</span>
  </button>
));

const StatCard = memo(({ stat, onReset }: any) => (
  <div className="glass p-6 md:p-8 rounded-[2.5rem] shadow-xl border border-white/60 hover:shadow-[0_20px_40px_-15px_rgba(234,88,12,0.3)] transition-all duration-500 relative group overflow-hidden cursor-pointer">
    <div className={`absolute top-0 right-0 w-48 h-48 ${stat.color.replace('bg-', 'bg-').replace('500', '500/10')} rounded-full blur-[40px] -mr-20 -mt-20 group-hover:scale-150 transition-transform duration-700`}></div>
    <div className={`absolute bottom-0 left-0 w-32 h-32 ${stat.color.replace('bg-', 'bg-').replace('500', '500/10')} rounded-full blur-[30px] -ml-16 -mb-16 group-hover:scale-150 transition-transform duration-700`}></div>
    
    {onReset && (
      <button
        onClick={() => onReset(stat.type)}
        className="absolute top-4 right-4 p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all z-20 opacity-0 group-hover:opacity-100"
        title={`Reset ${stat.label} Data`}
      >
        <Trash2 className="h-4 w-4" />
      </button>
    )}
    <div className="relative z-10 flex flex-col gap-4">
      <div className={`w-14 h-14 ${stat.color} rounded-2xl flex items-center justify-center text-white shadow-lg group-hover:scale-110 group-hover:-rotate-3 transition-transform duration-500`}>
        <stat.icon className="h-7 w-7" />
      </div>
      <div>
        <p className="text-[10px] sm:text-xs font-black text-slate-500 uppercase tracking-[0.2em] mb-1">
          {stat.label}
        </p>
        <p className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tighter">
          {stat.value}
        </p>
      </div>
      <div className="flex items-center gap-2 mt-2">
        <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-wider border ${
          stat.trend?.startsWith("+") || stat.trend === "Stable" 
            ? "border-emerald-200 bg-emerald-50 text-emerald-700" 
            : stat.trend === "Action Needed" ? "border-rose-200 bg-rose-50 text-rose-700" : "border-amber-200 bg-amber-50 text-amber-700"
        }`}>
          {stat.trend}
        </span>
      </div>
    </div>
  </div>
));

const AdminDashboard = () => {
  console.log("AdminDashboard component rendering");
  const navigate = useNavigate();
  const { token, logout, user, loading: authLoading } = useAuth();
  const { settings: globalSettings, refreshSettings } = useSettings();
  const [activeTab, setActiveTab] = useState<string>("overview");
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [paymentMethodFilter, setPaymentMethodFilter] = useState("");
  const [approvingRollNumber, setApprovingRollNumber] = useState("");
  const [expandedHistoryId, setExpandedHistoryId] = useState<string | null>(null);
  const [approvingMonthlyFee, setApprovingMonthlyFee] = useState("");
  const [approvingAdmissionFee, setApprovingAdmissionFee] = useState("");
  const [approvingBatchId, setApprovingBatchId] = useState("");

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [batches, setBatches] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [notices, setNotices] = useState<any[]>([]);
  const [resources, setResources] = useState<any[]>([]);
  const [routines, setRoutines] = useState<any[]>([]);
  const [galleryImages, setGalleryImages] = useState<any[]>([]);
  const [programs, setPrograms] = useState<any[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [moderators, setModerators] = useState<any[]>([]);
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [enrollmentProgramFilter, setEnrollmentProgramFilter] = useState("");
  const [selectedEnrollment, setSelectedEnrollment] = useState<any | null>(
    null,
  );
  const [liveClasses, setLiveClasses] = useState<any[]>([]);
  const [newLiveClass, setNewLiveClass] = useState({
    title: "",
    zoom_link: "",
    batch_id: "",
    course_id: "",
    zoom_id: "",
    zoom_password: "",
    status: "active",
    is_jitsi: false,
    program_id: "",
  });
  const [chapters, setChapters] = useState<any[]>([]);
  const [exams, setExams] = useState<any[]>([]);
  const [classSlides, setClassSlides] = useState<any[]>([]);
  const [markingAttendance, setMarkingAttendance] = useState<any | null>(null);
  const [showScanner, setShowScanner] = useState(false);
  const [scannerResult, setScannerResult] = useState("");
  const [attendanceList, setAttendanceList] = useState<any[]>([]);
  const [webRecordedClasses, setWebRecordedClasses] = useState<any[]>([]);
  const [webClassSchedules, setWebClassSchedules] = useState<any[]>([]);
  const [studyMaterials, setStudyMaterials] = useState<any[]>([]);
  const [degrees, setDegrees] = useState<any[]>([]);
  const [newDegree, setNewDegree] = useState({ title: "", description: "" });

  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearchTerm(searchTerm), 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);
  const [selectedStudent, setSelectedStudent] = useState<any | null>(null);
  const [isEditingStudent, setIsEditingStudent] = useState(false);
  const [editStudentData, setEditStudentData] = useState<any>(null);

  // Website Settings
  const [stagedSettings, setStagedSettings] = useState<any>({});

  const handleUpdateSetting = async (key: string, value: string) => {
    // If we're passing settings[key] from the UI, it already includes stagedSettings
    // But as an extra safety, we can ensure we have a value
    if (!value && stagedSettings[key] !== undefined) {
      value = stagedSettings[key];
    }

    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ key, value }),
      });
      if (res.ok) {
        showAlert("Setting updated successfully");
        // Real-time listener handles the globalSettings update
        setStagedSettings((prev: any) => {
          const next = { ...prev };
          delete next[key];
          return next;
        });
      } else {
        const err = await safeJson(res);
        showAlert(err.error || "Failed to update setting");
      }
    } catch (e) {
      console.error(e);
      showAlert("Network error updating setting");
    }
  };

  const settings = useMemo(
    () => ({
      ...globalSettings,
      ...stagedSettings,
    }),
    [globalSettings, stagedSettings],
  );

  // Forms
  const studentsMap = useMemo(() => {
    const map = new Map();
    students.forEach(s => {
      const roll = String(s.roll_number || "").toLowerCase().trim();
      const phone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
      const sid = String(s.id || "").toLowerCase().trim();
      const studentId = String(s.student_id || "").toLowerCase().trim();
      
      if (roll) map.set(roll, s);
      if (phone) map.set(phone, s);
      if (sid) map.set(sid, s);
      if (studentId) map.set(studentId, s);
    });
    return map;
  }, [students]);

  const [newBatch, setNewBatch] = useState({
    name: "",
    class: "",
    live_class_link: "",
    batch_days: "",
    batch_time: "",
    program_id: "",
  });
  const [newStudent, setNewStudent] = useState({
    name: "",
    email: "",
    password: "",
    roll_number: "",
    phone: "",
    program_title: "",
    program_id: "",
    batch_id: "",
    course_id: "",
    course_title: "",
    address: "",
    school_name: "",
    college_name: "",
    enrollment_id: "",
    admission_month: [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ][new Date().getMonth()],
    paid_amount: "",
    guardian_phone: "",
    batch_days: "",
    batch_time: "",
    admission_fee: "",
    current_class: "",
    class: "",
    monthly_fee: "",
    student_type: "offline",
    status: "approved",
    profile_pic: "",
    blood_group: "",
  });
  const [newNotice, setNewNotice] = useState({
    title: "",
    content: "",
    batch_id: "",
    program_id: "",
    author: "",
    attachment_url: "",
    is_verified: true,
    target_audience: "all",
  });
  const [newResource, setNewResource] = useState({
    title: "",
    type: "video",
    url: "",
    batch_id: "",
    program_id: "",
    description: "",
  });
  const [newRoutine, setNewRoutine] = useState({
    batch_id: "",
    program_id: "",
    course_id: "",
    image_url: "",
    content: "",
  });
  const [newImage, setNewImage] = useState({
    image_url: "",
    caption: "",
    category: "General",
  });
  const [newSlide, setNewSlide] = useState({
    title: "",
    image_url: "",
    batch_id: "",
    course_id: "",
    program_id: "",
  });
  const [pendingSlides, setPendingSlides] = useState<string[]>([]);
  const [newProgram, setNewProgram] = useState({
    title: "",
    description: "",
    features: "",
    target_audience: "",
    admission_fee: "",
    monthly_fee: "",
    image_url: "",
  });
  const [editingProgram, setEditingProgram] = useState<any | null>(null);
  const [newCourse, setNewCourse] = useState({
    title: "",
    description: "",
    price: "",
    image_url: "",
    zoom_id: "",
    zoom_password: "",
    duration: "",
    lecture_count: "",
    program_id: "",
  });
  const [newChapter, setNewChapter] = useState({
    batch_id: "",
    program_id: "",
    course_id: "",
    title: "",
    content: "",
    status: "active",
    description: "",
  });
  const [newExam, setNewExam] = useState({
    batch_id: "",
    program_id: "",
    exam_name: "",
    exam_date: "",
    category: "",
    question_pdf: "",
    answer_pdf: "",
    total_marks: "100",
  });
  const [newWebRecordedClass, setNewWebRecordedClass] = useState({
    title: "",
    url: "",
    description: "",
    course_id: "",
    program_id: "",
    batch_id: "",
  });
  const [newWebClassSchedule, setNewWebClassSchedule] = useState({
    title: "",
    image_url: "",
    program_id: "",
    batch_id: "",
  });
  const [newStudyMaterial, setNewStudyMaterial] = useState({
    student_id: "",
    title: "",
    url: "",
    type: "pdf",
    batch_id: "",
    course_id: "",
    program_id: "",
  });

  // Attendance State
  const [attendanceSearch, setAttendanceSearch] = useState({
    batch_id: "",
    program_id: "",
    roll_number: "",
  });
  const [autoMark, setAutoMark] = useState(false);
  const [attendanceReportFilter, setAttendanceReportFilter] = useState<{batch_id: string; program_id: string; startDate: string; endDate: string; type: string; status: string;}>({
    batch_id: "",
    program_id: "",
    startDate: format(new Date(), "yyyy-MM-dd"),
    endDate: format(new Date(), "yyyy-MM-dd"),
    type: "",
    status: "",
  });
  const [attendanceReport, setAttendanceReport] = useState<any[]>([]);
  const [attendanceTime, setAttendanceTime] = useState("");
  const [attendanceStudent, setAttendanceStudent] = useState<any | null>(null);

  const handleUpdateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;
    try {
      const payload: any = { ...editStudentData };
      if (editStudentData.batch_id && String(editStudentData.batch_id) !== String(selectedStudent.batch_id)) {
          payload.transfer_date = new Date().toISOString();
      }

      const res = await fetch(`/api/students/${selectedStudent.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("Failed to update student");
      showAlert("Student updated successfully", "success");
      setIsEditingStudent(false);
      // Let real-time update handle it, but update internal selected student
      setSelectedStudent({ ...selectedStudent, ...payload });
    } catch (e: any) {
      showAlert(e.message || "Error updating student", "error");
    }
  };

  const handleAddBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/batches", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(newBatch),
      });
      if (!res.ok) throw new Error("Failed to add batch");
      showAlert("Batch added successfully", "success");
      clearForm("batch");
    } catch(e: any) {
      showAlert(e.message || "Error", "error");
    }
  };

  const handleDeleteBatch = async (id: string) => {
      try {
        if (!await showConfirm("Are you sure?")) return;
        await deleteDoc(doc(db, "batches", id));
        showAlert("Batch deleted", "success");
      } catch(e) {}
  };

  const handleAddNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/notices", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(newNotice),
      });
      if (!res.ok) throw new Error("Failed");
      showAlert("Notice added", "success");
      clearForm("notice");
    } catch(e) {}
  };

  const handleAddImage = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch("/api/gallery", {
         method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
         body: JSON.stringify(newImage)
      });
      showAlert("Image added", "success");
      clearForm("gallery");
    } catch(e) {}
  };

  const handleAddReview = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
       await fetch("/api/reviews", {
         method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
         body: JSON.stringify({ ...newReview })
      });
      showAlert("Review added", "success");
      clearForm("review");
    } catch(e) {}
  };

  const handleApproveReview = async (id: string) => {
    try {
      await setDoc(doc(db, "reviews", id), { status: "approved" }, { merge: true });
    } catch(e) {}
  };
  const handleDeleteReview = async (id: string) => {
      try {
        if (!await showConfirm("Are you sure?")) return;
        await deleteDoc(doc(db, "reviews", id));
      } catch(e) {}
  };

  const handleAddWebRecordedClass = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch("/api/api-web-recorded", {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(newWebRecordedClass)
      });
      clearForm("web_recorded");  
    } catch(e) {}
  };
  const handleDeleteWebRecordedClass = async (id: string) => {
      try {
        if (!await showConfirm("Are you sure?")) return;
        await deleteDoc(doc(db, "web_recorded_classes", id));
      } catch(e) {}
  };
  
  const handleDeleteStudyMaterial = async (id: string) => {
      try {
        if (!await showConfirm("Are you sure?")) return;
        await deleteDoc(doc(db, "study_materials", id));
      } catch(e) {}
  };

  const handleAddWebClassSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch("/api/api-web-schedules", {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(newWebClassSchedule)
      });
      clearForm("web_schedule");
    } catch(e) {}
  };
  const handleDeleteWebClassSchedule = async (id: string) => {
      try {
        if (!await showConfirm("Are you sure?")) return;
        await deleteDoc(doc(db, "web_class_schedules", id));
      } catch(e) {}
  };

  const handleAddVideoClass = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch("/api/api-video-classes", {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(newWebRecordedClass)
      });
      clearForm("web_recorded");
    } catch (e) {}
  };
  const handleDeleteVideoClass = async (id: string) => {
      try {
        if (!await showConfirm("Are you sure?")) return;
        await deleteDoc(doc(db, "video_classes", id));
      } catch(e) {}
  };
  const attendanceCardRef = useRef<HTMLDivElement>(null);
  const autoAbsentTriggered = useRef<Record<string, string>>({});

  useEffect(() => {
    if (attendanceStudent && attendanceCardRef.current) {
      attendanceCardRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [attendanceStudent]);

  useEffect(() => {
    if (showScanner) {
      const scanner = new Html5QrcodeScanner(
        "reader",
        { fps: 10, qrbox: { width: 250, height: 250 } },
        /* verbose= */ false,
      );

      scanner.render(onScanSuccess, onScanFailure);

      function onScanSuccess(decodedText: string) {
        // Expected format: JABER-MATH-ROLL
        if (decodedText.startsWith("JABER-MATH-")) {
          const roll = decodedText.replace("JABER-MATH-", "");
          setAttendanceSearch((prev) => ({ ...prev, roll_number: roll }));
          setShowScanner(false);
          scanner.clear();
          // Trigger search automatically
          setTimeout(() => {
            const searchBtn = document.getElementById("search-student-btn");
            if (searchBtn) searchBtn.click();
          }, 100);
        }
      }

      function onScanFailure(error: any) {
        // console.warn(`Code scan error = ${error}`);
      }

      return () => {
        scanner.clear().catch((error) => {
          console.error("Failed to clear html5QrcodeScanner. ", error);
        });
      };
    }
  }, [showScanner]);

  const [allowCrossBatch, setAllowCrossBatch] = useState(false);
  const [attendanceConfirmed, setAttendanceConfirmed] = useState(false);
  const [attendanceLocked, setAttendanceLocked] = useState(true);

  // Exam Attendance State
  const [examAttendanceSearch, setExamAttendanceSearch] = useState({
    batch_id: "",
    program_id: "",
    exam_id: "",
    roll_number: "",
  });
  const [examAttendanceStudent, setExamAttendanceStudent] = useState<
    any | null
  >(null);
  const [examAttendanceTime, setExamAttendanceTime] = useState("");

  // Payment State
  const [paymentSearch, setPaymentSearch] = useState({
    batch_id: "",
    program_id: "",
    roll_number: "",
  });
  const [paymentStudent, setPaymentStudent] = useState<any | null>(null);
  const [paymentData, setPaymentData] = useState({
    amount: "",
    date: format(new Date(), "yyyy-MM-dd"),
    type: "monthly",
    month: format(new Date(), "MMMM"),
    year: format(new Date(), "yyyy"),
  });
  const [allPayments, setAllPayments] = useState<any[]>([]);
  const [studentListPage, setStudentListPage] = useState(1);
  const studentsPerPage = 20;
  const [paymentSort, setPaymentSort] = useState("date"); // date, student, batch
  const [paymentProgramFilter, setPaymentProgramFilter] = useState("");
  const [paymentLimit, setPaymentLimit] = useState(100);

  // Results State
  const [resultSearch, setResultSearch] = useState({
    batch_id: "",
    program_id: "",
    roll_number: "",
  });
  const [resultStudent, setResultStudent] = useState<any | null>(null);
  const [newResult, setNewResult] = useState({
    exam_id: "",
    correct_answers: "",
    wrong_answers: "",
    highest_marks: "",
    negative_marks: "",
    marking_mode: false,
    questions: [] as { id: number; status: "correct" | "wrong" | "none" }[],
  });
  const [allResults, setAllResults] = useState<any[]>([]);
  const [resultHistories, setResultHistories] = useState<any[]>([]);
  const [examCategories, setExamCategories] = useState<any[]>([]);
  const [newExamCategory, setNewExamCategory] = useState("");
  const [videoClasses, setVideoClasses] = useState<any[]>([]);
  const [newVideoClass, setNewVideoClass] = useState({
    title: "",
    youtube_id: "",
    program_id: "",
    batch_id: "",
    course_id: "",
    description: "",
  });
  const [reviews, setReviews] = useState<any[]>([]);
  const [newReview, setNewReview] = useState({
    student_name: "",
    student_image: "",
    comment: "",
    rating: 5,
    batch: "",
  });

  const handleImageError = (
    e: React.SyntheticEvent<HTMLImageElement, Event>,
  ) => {
    const target = e.target as HTMLImageElement;
    target.src = "https://picsum.photos/seed/broken/800/600"; // Fallback image
    target.onerror = null; // Prevent infinite loop
  };

  const fetchAllResults = async () => {
    try {
      const res = await fetch(`/api/public/results?t=${Date.now()}`, {
        headers: {
          "Cache-Control": "no-cache",
          Pragma: "no-cache",
        },
      });
      if (res.ok) {
        const data = await safeJson(res);
        setAllResults(Array.isArray(data) ? data : []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Add this to handle exam selection change
  const handleExamChange = (examId: string) => {
    const selectedExam = exams.find((e) => e.id == examId);
    setNewResult({
      ...newResult,
      exam_id: examId,
      highest_marks: selectedExam?.highest_marks?.toString() || selectedExam?.total_marks?.toString() || "",
      negative_marks: selectedExam?.negative_marks?.toString() || "",
    });
  };

  // Student Search State
  const [searchQuery, setSearchQuery] = useState({
    class: "",
    batch_id: "",
    program_id: "",
    roll_number: "",
  });
  const [searchResult, setSearchResult] = useState<any>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isAttendanceSearching, setIsAttendanceSearching] = useState(false);
  const [studentStatusFilter, setStudentStatusFilter] = useState("approved"); // all, approved, pending, upcoming, passed
  const [selectedBatch, setSelectedBatch] = useState<string | null>(null);

  const calculateUnpaidMonths = (student: any): string[] => {
    if (!student) return [];

    let startDateRaw = student.date_of_admission || student.created_at;
    if (!startDateRaw) return [];

    let startDate = new Date(startDateRaw);
    
    // If admission_month is provided, adjust the starting month
    if (student.admission_month) {
      const monthIndex = MONTHS.findIndex(m => m.toLowerCase() === String(student.admission_month).toLowerCase());
      if (monthIndex !== -1) {
        // If the admission month index is greater than the created_at month index, 
        // it likely means they joined in the previous year (e.g. added in Jan for Dec)
        // Adjust year if needed
        const createdMonth = startDate.getMonth();
        if (monthIndex > createdMonth) {
          startDate.setFullYear(startDate.getFullYear() - 1);
        }
        startDate.setMonth(monthIndex);
        startDate.setDate(1);
      }
    } else {
      startDate.setDate(1); // Ensure we start at the beginning of the month
    }

    const now = new Date();
    const unpaid: string[] = [];

    // Start from the month of admission
    let current = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
    const end = new Date(now.getFullYear(), now.getMonth(), 1);

    // Limit the search to prevent infinite loops or massive arrays if year is weird
    let safetyCounter = 0;
    while (current <= end && safetyCounter < 48) {
      safetyCounter++;
      const monthName = format(current, "MMMM");
      const currentYearStr = format(current, "yyyy");
      const monthYear = format(current, "MMM yy");

      const hasPayment = student.payments?.some(
        (p: any) =>
          p.type === "monthly" &&
          p.month && String(p.month).toLowerCase() === String(monthName).toLowerCase() &&
          (String(p.year || format(new Date(p.date), "yyyy")) === currentYearStr) &&
          p.status !== "rejected",
      );

      // Check if it's the admission month and they have a paid_amount (manually recorded fee)
      // Note: We no longer skip if they have paid_amount because admission fee doesn't necessarily cover monthly tuition
      const isAdmissionMonth = 
        student.admission_month && 
        monthName && 
        String(student.admission_month).toLowerCase() === String(monthName).toLowerCase() &&
        current.getFullYear() === startDate.getFullYear();
        
      if (!hasPayment) {
        unpaid.push(
          current.getFullYear() === now.getFullYear() ? monthName : monthYear,
        );
      }

      current.setMonth(current.getMonth() + 1);
    }

    return [...new Set(unpaid)];
  };

  const getFilteredBatches = (programId?: string | number, currentClass?: string) => {
    if (!programId) return [];
    return batches.filter((b) => {
      if (String(b.program_id) !== String(programId)) return false;
      if (currentClass && currentClass !== "all") {
        if (String(b.class) !== String(currentClass) && String(b.class_name) !== String(currentClass)) return false;
      }
      return true;
    });
  };
  const filteredBatches = useMemo(() => {
    let filtered = batches;
    if (searchQuery.class) {
      filtered = filtered.filter((b) => b.class === searchQuery.class || b.class_name === searchQuery.class || b.batch_class === searchQuery.class);
    }
    if (searchQuery.program_id) {
      filtered = filtered.filter(
        (b) => String(b.program_id) === String(searchQuery.program_id),
      );
    }
    return filtered;
  }, [searchQuery.class, searchQuery.program_id, batches]);

  const fetchSettings = async () => {
    try {
      await refreshSettings();
    } catch (e) {
      console.error(e);
    }
  };

  const processImage = (file: File, callback: (dataUrl: string) => void) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL("image/jpeg", 0.6);
          callback(dataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    settingKey: string,
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processImage(file, (dataUrl) => handleUpdateSetting(settingKey, dataUrl));
  };

  const handleResetData = async (type: string) => {
    const message =
      type === "attendance"
        ? "Are you sure you want to delete ALL attendance records for all students? This action cannot be undone."
        : `Are you sure you want to delete all ${type}? This action cannot be undone.`;

    if (await showConfirm(message)) {
      try {
        const res = await fetch("/api/reset-data", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ type }),
        });
        if (res.ok) {
          showAlert(`All ${type} deleted successfully`);
          if (
            type === "students" ||
            type === "offline_students" ||
            type === "online_students"
          ) {
            /* Handled by onSnapshot */
          }
          if (type === "batches") { /* Handled by onSnapshot */ }
          if (type === "payments") {
            fetchAllPayments();
            if (paymentStudent) {
              setPaymentStudent({ ...paymentStudent, payments: [] });
            }
          }
          if (type === "enrollments") { /* Handled by onSnapshot */ }
        } else {
          showAlert(`Failed to delete ${type}`);
        }
      } catch (error) {
        console.error("Failed to reset data", error);
        showAlert("An error occurred while resetting data");
      }
    }
  };

  useEffect(() => {
    console.log("AdminDashboard mounted, authLoading:", authLoading);
  }, [authLoading]);

  useEffect(() => {
    console.log("Programs state updated:", programs);
  }, [programs]);

  useEffect(() => {
    console.log("Batches state updated:", batches);
  }, [batches]);

  useEffect(() => {
    console.log("Attempting to fetch data, authLoading:", authLoading);
    if (authLoading) return;

    const runMaintenance = async () => {
      // Delete attendance records older than 2 months
      const twoMonthsAgo = new Date();
      twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);

      const lastRun = localStorage.getItem("lastMaintenanceRun");
      if (lastRun === format(new Date(), "yyyy-MM-dd")) return;

      const q = query(
        collection(db, "attendance"),
        where("date", "<", format(twoMonthsAgo, "yyyy-MM-dd")),
      );
      const snapshot = await getDocs(q);

      if (snapshot.size > 0) {
        console.log(`Deleting ${snapshot.size} old attendance records`);
        const batch = writeBatch(db);
        snapshot.docs.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
        console.log("Old attendance records deleted");
      }
      localStorage.setItem(
        "lastMaintenanceRun",
        format(new Date(), "yyyy-MM-dd"),
      );
    };

    const loadInitialData = async () => {
      // Don't run if still loading auth or if no token yet
      if (authLoading || !token) return;

      try {
        await runMaintenance();
      } catch (error) {
        console.error("Failed to run maintenance:", error);
      }
    };
    loadInitialData();
  }, [authLoading, token]);

  const fetchVideoClasses = async () => { /* Handled by onSnapshot instantly */ };

  // Core Real-time Listeners - Essential for startup
  useEffect(() => {
    if (authLoading || !token) return;
    const unsubscribes: (() => void)[] = [];

    // Students
    unsubscribes.push(
      onSnapshot(
        query(collection(db, "users"), where("role", "==", "student")),
        (snapshot) => {
          setStudents(snapshot.docs.map((d) => ({ ...d.data(), id: d.id })));
          setLoading(false);
        },
        (error) => {
          console.error("Student listener error: ", error);
          setLoading(false);
        },
      ),
    );
    
    // Do not block the whole dashboard waiting for students. Let UI render
    setTimeout(() => {
        if(loading) setLoading(false);
    }, 500);

    // Batches & Programs
    const collections = ["batches", "programs"];
    collections.forEach(col => {
      unsubscribes.push(
        onSnapshot(collection(db, col), 
          (snapshot) => {
            const docs = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }));
            if (col === "batches") setBatches(docs);
            else if (col === "programs") setPrograms(docs);
          },
          (error) => {
            console.error(`${col} listener error:`, error);
          }
        )
      );
    });

    unsubscribes.push(
      onSnapshot(
        query(collection(db, "users"), where("role", "==", "moderator")), 
        (snapshot) => {
          const docs = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }));
          setModerators(docs);
        },
        (error) => {
          console.error("Moderator listener error:", error);
        }
      )
    );

    return () => unsubscribes.forEach((unsub) => unsub());
  }, [authLoading, token]);

  // Secondary Data Listeners - Operations (Payments, Exams, Results)
  useEffect(() => {
    if (authLoading || !token) return;

    // Only load these if on relevant tabs to save performance
    const relevantTabs = ["overview", "search", "payments", "income", "results", "merit_list", "exams", "exam_attendance", "messages", "notices", "enrollments", "attendance", "exam_history"];
    if (!relevantTabs.includes(activeTab)) return;

    const unsubscribes: (() => void)[] = [];

    // Define which collections to listen to based on tab
    const tabMapping: { [key: string]: string[] } = {
      overview: ["notices", "exams", "payments", "enrollments"],
      search: ["payments", "results", "exams"],
      payments: ["payments"],
      income: ["payments"],
      results: ["results", "exams"],
      merit_list: ["results", "exams"],
      exams: ["exams", "exam_categories"],
      exam_attendance: ["exams"],
      attendance: ["exams", "payments"],
      messages: ["messages"],
      notices: ["notices"],
      enrollments: ["enrollments"],
      exam_history: ["result_histories"]
    };

    const collectionsToLoad = Array.from(new Set(tabMapping[activeTab] || []));
    
    collectionsToLoad.forEach(col => {
      unsubscribes.push(
        onSnapshot(collection(db, col), 
          (snapshot) => {
            const docs = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }));
            if (col === "payments") setAllPayments(docs);
            else if (col === "notices") setNotices(docs);
            else if (col === "exams") setExams(docs);
            else if (col === "results") setAllResults(docs);
            else if (col === "exam_categories") setExamCategories(docs);
            else if (col === "messages") setMessages(docs);
            else if (col === "enrollments") setEnrollments(docs);
            else if (col === "result_histories") setResultHistories(docs);
          },
          (error) => {
            console.error(`Error in onSnapshot for ${col}:`, error);
          }
        )
      );
    });

    return () => unsubscribes.forEach((unsub) => unsub());
  }, [authLoading, token, activeTab]);

  // Tertiary Data Listeners - Content & Resources (Lazy-ish based on active tab)
  useEffect(() => {
    if (authLoading || !token) return;
    
    // Only load content listeners if relevant tabs are active or it's been explicitly triggered
    // This significantly reduces the initial load weight
    const contentTabs = ["resources", "gallery", "video_classes", "chapters", "reviews", "notices", "study_materials", "routines", "courses", "live_classes", "web_recorded", "student_recorded", "web_schedule", "class_slides", "programs", "batches", "online_students"];
    if (!contentTabs.includes(activeTab) && activeTab !== "overview") return;

    const unsubscribes: (() => void)[] = [];
    const contentCollections = ["chapters", "routines", "study_materials", "gallery", "video_classes", "class_slides", "web_recorded_classes", "web_class_schedules", "degrees", "courses", "live_classes", "reviews"];
    
    contentCollections.forEach(col => {
      unsubscribes.push(
        onSnapshot(collection(db, col), 
          (snapshot) => {
            const docs = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }));
            if (col === "chapters") setChapters(docs);
            else if (col === "routines") setRoutines(docs);
            else if (col === "study_materials") setStudyMaterials(docs);
            else if (col === "gallery") setGalleryImages(docs);
            else if (col === "video_classes") setVideoClasses(docs);
            else if (col === "class_slides") setClassSlides(docs);
            else if (col === "web_recorded_classes") setWebRecordedClasses(docs);
            else if (col === "web_class_schedules") setWebClassSchedules(docs);
            else if (col === "degrees") setDegrees(docs);
            else if (col === "courses") setCourses(docs);
            else if (col === "live_classes") setLiveClasses(docs);
            else if (col === "reviews") setReviews(docs);
          },
          (error) => {
            console.error(`Content listener error for ${col}:`, error);
          }
        )
      );
    });

    return () => unsubscribes.forEach((unsub) => unsub());
  }, [authLoading, token, activeTab]);

  // Auto-absent logic
  useEffect(() => {
    const triggerAutoAbsent = async () => {
      const activeBatchId =
        activeTab === "attendance"
          ? attendanceSearch.batch_id
          : activeTab === "exam_attendance"
            ? examAttendanceSearch.batch_id
            : null;

      if (
        (activeTab === "attendance" || activeTab === "exam_attendance") &&
        activeBatchId &&
        token
      ) {
        const today = format(new Date(), "yyyy-MM-dd");
        const dayShort = format(new Date(), "EEE"); // e.g., 'Mon'
        const batch = batches.find(
          (b) => String(b.id) === String(activeBatchId),
        );

        // Check if today is a batch day or if we are taking exam attendance
        // (exams can happen on any day, so if exam_attendance tab is active, we might want to trigger it anyway)
        const isBatchDay =
          batch &&
          batch.batch_days &&
          (batch.batch_days === "Everyday" ||
            batch.batch_days === "Special" ||
            batch.batch_days.includes(dayShort));

        if (isBatchDay || activeTab === "exam_attendance") {
          const triggerKey = `${activeBatchId}_${today}`;
          if (autoAbsentTriggered.current[triggerKey]) return;
          autoAbsentTriggered.current[triggerKey] = "triggered";

          try {
            await fetch("/api/attendance/auto-absent", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
              },
              body: JSON.stringify({ batch_id: activeBatchId, date: today }),
            });
            // Auto-absent will naturally reflect via individual student loads when searchResult updates
          } catch (e) {
            console.error("Auto-absent failed:", e);
          }
        }
      }
    };
    triggerAutoAbsent();
  }, [
    attendanceSearch.batch_id,
    examAttendanceSearch.batch_id,
    activeTab,
    token,
    batches,
  ]);

  useEffect(() => {
    if (authLoading) return;

    if (activeTab === "reviews") {
      fetchReviews();
    }
    if (activeTab === "attendance_report") {
       if (attendanceReportFilter.batch_id || attendanceReportFilter.program_id) {
           fetchAttendanceReport();
       }
    }
  }, [activeTab, authLoading]);

  const fetchReviews = async () => {
    try {
      const q = query(collection(db, "reviews"), orderBy("created_at", "desc"));
      const querySnapshot = await getDocs(q);
      const data = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setReviews(data);
    } catch (e) {
      console.error(e);
      // Fallback if index missing
      try {
        const querySnapshot = await getDocs(collection(db, "reviews"));
        const data = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setReviews(data);
      } catch (err) {
        console.error("Secondary fallback failed", err);
      }
    }
  };

  const fetchDegrees = async () => { /* Handled by onSnapshot instantly */ };

  const fetchRoutines = async () => { /* Handled by onSnapshot instantly */ };

  const handleAddRoutine = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoutine.course_id && !newRoutine.program_id) {
      showAlert("Please select either a Program/Batch OR a Course.");
      return;
    }

    // Prepare data for submission
    const routineData = {
      ...newRoutine
    };

    try {
      const res = await fetch("/api/routines?t=" + Date.now(), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(routineData),
      });
      if (res.ok) {
        fetchRoutines();
        setNewRoutine({
          batch_id: "",
          program_id: "",
          course_id: "",
          image_url: "",
          content: "",
        });
        showAlert("Routine added successfully");
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteRoutine = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete routines", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "routines", id));
        showAlert("Routine deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete routine", "error");
      }
    }
  };

  const fetchStudyMaterials = async () => { /* Handled by onSnapshot instantly */ };

  const handleAddStudyMaterial = async (e: React.FormEvent, customData?: any) => {
    e.preventDefault();
    try {
      const dataToSubmit = customData || newStudyMaterial;
      const res = await fetch("/api/study-materials", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ ...dataToSubmit, url: dataToSubmit.url || "https#" })
      });
      if (!res.ok) throw new Error("Failed to create study material");
      
      setNewStudyMaterial({
        student_id: "",
        title: "",
        url: "",
        type: "pdf",
        batch_id: "",
        program_id: "",
        course_id: "",
      });
      showAlert(dataToSubmit.type === "video" ? "Recorded class added successfully" : "Study material added successfully", "success");
    } catch (e: any) {
      console.error(e);
      showAlert(e.message || "Error adding material", "error");
    }
  };

  const handleAddChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/chapters", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newChapter),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to create chapter");
      }
      fetchChapters();
      setNewChapter({
        batch_id: "",
        program_id: "",
        course_id: "",
        title: "",
        content: "",
        status: "active",
        description: "",
      });
      showAlert("Chapter created successfully");
    } catch (e: any) {
      console.error(e);
      showAlert(e.message || "Failed to create chapter");
    }
  };

  const handleMarkAttendance = async (exam: any) => {
    setActiveTab("exam_attendance");
    setExamAttendanceSearch((prev) => ({
      ...prev,
      program_id:
        batches.find((b) => b.id == exam.batch_id)?.program_id ||
        prev.program_id,
      batch_id: exam.batch_id === "all" ? "" : exam.batch_id,
      exam_id: exam.id,
      roll_number: "",
    }));
    setExamAttendanceStudent(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSaveAttendance = async () => {
    // This function can be removed or kept as a placeholder since the modal is removed,
    // but I will keep it empty to prevent typescript errors just in case it's lingering.
    setMarkingAttendance(null);
  };

  const handleAddExamCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExamCategory.trim()) return;
    try {
      await addDoc(collection(db, "exam_categories"), {
        name: newExamCategory,
        createdAt: new Date().toISOString()
      });
      setNewExamCategory("");
      showAlert("Category added successfully");
    } catch (e) {
      console.error(e);
      showAlert("Failed to add category");
    }
  };

  const handleDeleteExamCategory = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete categorys", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "exam_categories", id));
        showAlert("Category deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete category", "error");
      }
    }
  };

  const handleAddExam = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      const res = await fetch("/api/exams", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...newExam,
          total_marks: Number(newExam.total_marks || 100),
        }),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to create exam");
      }
      showAlert("Exam created successfully");
      setLoading(false);
      fetchExams();
      setNewExam({
        batch_id: "",
        program_id: "",
        exam_name: "",
        exam_date: "",
        category: "",
        question_pdf: "",
        answer_pdf: "",
        total_marks: "100"
      });
    } catch (e: any) {
      setLoading(false);
      console.error(e);
      showAlert(e.message || "Failed to create exam");
    }
  };

  const [passwordForm, setPasswordForm] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [profileForm, setProfileForm] = useState({
    name: user?.name || "",
    email: user?.email || "",
  });

  useEffect(() => {
    if (user) {
      setProfileForm({ name: user.name || "", email: user.email || "" });
    }
  }, [user]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/auth/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(profileForm),
      });
      if (res.ok) {
        showAlert(
          "Profile updated successfully. Please log in again to see changes.",
        );
        logout();
      } else {
        const data = await safeJson(res);
        showAlert(data.error || "Failed to update profile");
      }
    } catch (e) {
      console.error(e);
    }
  };

  const [newModerator, setNewModerator] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleAddModerator = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/moderators", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newModerator),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to add moderator");
      }
      showAlert("Moderator added successfully");
      setNewModerator({ name: "", email: "", password: "" });
      /* Handled by real-time listener */
    } catch (e: any) {
      console.error(e);
      showAlert(e.message || "Failed to add moderator");
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      showAlert("New passwords do not match");
      return;
    }
    try {
      const res = await fetch("/api/auth/password", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          oldPassword: passwordForm.oldPassword,
          newPassword: passwordForm.newPassword,
        }),
      });
      if (res.ok) {
        showAlert("Password changed successfully");
        setPasswordForm({
          oldPassword: "",
          newPassword: "",
          confirmPassword: "",
        });
      } else {
        const error = await safeJson(res);
        showAlert(error.error || "Failed to change password");
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleStudentSearch = async (e?: React.FormEvent, overrideRoll?: string) => {
    if (e) e.preventDefault();
    setIsSearching(true);
    setSearchResult(null);
    try {
      const val = overrideRoll || searchQuery.roll_number;
      const target = String(val).trim().toLowerCase();
      const targetQueryClean = target.replace(/[\s-]/g, "");

      // 1. If batch is selected, prioritize searching WITHIN that batch first
      let studentLocal = null;
      if (selectedBatch && selectedBatch !== "all") {
          studentLocal = students.find(s => {
              const belongs = String(s.batch_id) === String(selectedBatch) || String(s.batch_id_2) === String(selectedBatch);
              if (!belongs) return false;
              const sRoll = String(s.roll_number || "").toLowerCase().trim();
              const sPhone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
              return sRoll === target || sPhone === targetQueryClean || s.name?.toLowerCase().includes(target);
          });
      }
      
      // If batch is selected and we didn't find them in that batch, stop searching!
      // This prevents pulling a student from another batch with the same roll number.
      if (!studentLocal && selectedBatch && selectedBatch !== "all") {
          setIsSearching(false);
          showAlert(`Student not found in selected batch with query: ${val}`);
          return;
      }

      // 2. Fast Map Lookup (fallback only if no batch selected)
      if (!studentLocal) {
        studentLocal = studentsMap.get(target) || studentsMap.get(targetQueryClean);
      }
      
      // 3. Last Fallback: Global name search
      if (!studentLocal) {
          studentLocal = students.find(s => s.name?.toLowerCase().includes(target));
      }

      if (!studentLocal) {
        showAlert("Student not found.");
        setIsSearching(false);
        return;
      }

      const student = await fetchStudentDetails(studentLocal.id);

      if (student) {
        let allAttendance = student.attendance || [];

        const studentBatch = batches.find((b) => b.id == student.batch_id);
        const batchDays = student.batch_days || studentBatch?.batch_days || "";
        const startDateStr = student.transfer_date || student.created_at || student.admission_date || student.date_of_admission;

        // Generate virtual absent records for past class days
        if (batchDays && startDateStr) {
          const startDate = startOfDay(new Date(startDateStr));
          const endDate = startOfDay(new Date());

          if (
            isBefore(startDate, endDate) ||
            startDate.getTime() === endDate.getTime()
          ) {
            const days = eachDayOfInterval({
              start: startDate,
              end: endDate,
            });
            const dayMapping: Record<string, string> = {
              Saturday: "Sat",
              Sunday: "Sun",
              Monday: "Mon",
              Tuesday: "Tue",
              Wednesday: "Wed",
              Thursday: "Thu",
              Friday: "Fri",
            };

            days.forEach((day) => {
              const dayName = format(day, "EEEE");
              const dateStr = format(day, "yyyy-MM-dd");
              const dayShort = dayMapping[dayName];

              let isClassDay = false;
              const normalizedBatchDays = batchDays.toLowerCase().replace(/\s/g, '');
              if (normalizedBatchDays === "everyday") {
                isClassDay = dayName !== "Friday";
              } else if (batchDays.includes(dayShort) || batchDays.includes(dayName)) {
                isClassDay = true;
              }

              if (isClassDay) {
                // Check if record exists
                const exists = allAttendance.find(
                  (a: any) => a.date === dateStr && a.type !== "exam",
                );
                if (!exists) {
                  allAttendance.push({
                    id: `auto-${dateStr}`,
                    date: dateStr,
                    time: "N/A",
                    status: "absent",
                    type: "class",
                    isAuto: true,
                  });
                }
              }
            });
          }
        }
        
        // Check for missed exams
        const studentExams = exams.filter(e => (String(e.batch_id) === String(student.batch_id) || String(e.batch_id) === String(student.batch_id_2)) && e.published);
        studentExams.forEach(exam => {
           if (exam.date) {
               const examDateStr = new Date(exam.date).toISOString().split('T')[0];
               if (startDateStr && new Date(examDateStr) >= new Date(startDateStr)) {
                   // Exam happened after they joined
                   const examRecord = allAttendance.find((a: any) => a.date === examDateStr && a.type === "exam");
                   if (!examRecord) {
                       allAttendance.push({
                          id: `auto-exam-${exam.id}`,
                          date: examDateStr,
                          time: "N/A",
                          status: "absent",
                          type: "exam",
                          isAuto: true,
                       });
                   }
               }
           }
        });

        // Sort attendance
        allAttendance.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        student.attendance = allAttendance;


        // Sort by date descending
        allAttendance.sort(
          (a: any, b: any) =>
            new Date(b.date).getTime() - new Date(a.date).getTime(),
        );

        setSearchResult({ ...student, attendance: allAttendance });
      } else {
        showAlert("Student details not found");
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSearching(false);
    }
  };

  const fetchNotices = async () => { /* Handled by onSnapshot instantly */ };

  const handleDeleteProgram = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete programs", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "programs", id));
        showAlert("Program deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete program", "error");
      }
    }
  };

  const handleDeleteCourse = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete courses", "error");
      return;
    }
    if (await showConfirm("Are you sure? This will automatically delete all routines, materials, videos, slides, and live classes under this course.")) {
      try {
        const collectionsToDelete = [
          "chapters", "routines", "study_materials", 
          "video_classes", "class_slides", "web_recorded_classes", 
          "web_class_schedules"
        ];
        
        await Promise.all(collectionsToDelete.map(async (colName) => {
          const q = query(collection(db, colName), where("course_id", "==", id));
          const snapshot = await getDocs(q);
          if (!snapshot.empty) {
            const deletePromises = snapshot.docs.map(docSnap => deleteDoc(doc(db, colName, docSnap.id)));
            await Promise.all(deletePromises);
          }
        }));

        await deleteDoc(doc(db, "courses", id));
        showAlert("Course and all related items deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete course and related items", "error");
      }
    }
  };

  const handleDeleteImage = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete images", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "gallery", id));
        showAlert("Image deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete image", "error");
      }
    }
  };

  const handleDeleteNotice = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete notices", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "notices", id));
        showAlert("Notice deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete notice", "error");
      }
    }
  };

  const handleDeleteResource = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete resources", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "study_materials", id));
        showAlert("Resource deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete resource", "error");
      }
    }
  };

  const fetchStudentDetails = async (id: string): Promise<any> => {
    try {
      const docSnap = await getDoc(doc(db, "users", id));
      if (!docSnap.exists()) throw new Error("Student not found");
      const data = { id: docSnap.id, ...docSnap.data() };

      const [attSnap, paySnap, resSnap, enrollSnap] = await Promise.all([
        getDocs(query(collection(db, "attendance"), where("student_id", "==", id))),
        getDocs(query(collection(db, "payments"), where("student_id", "==", id))),
        getDocs(query(collection(db, "results"), where("student_id", "==", id))),
        getDocs(query(collection(db, "enrollments"), where("user_id", "==", id)))
      ]);

      return {
        ...data,
        attendance: attSnap.docs.map(d => ({ id: d.id, ...d.data() })),
        payments: paySnap.docs.map(d => ({ id: d.id, ...d.data() })),
        results: resSnap.docs.map(d => ({ id: d.id, ...d.data() })),
        enrollments: enrollSnap.docs.map(d => ({ id: d.id, ...d.data() }))
      };
    } catch (e: any) {
      console.error(e);
      throw e;
    }
  };

  const handleViewStudent = async (id: string) => {
    setSelectedStudent(null);
    try {
      const details = await fetchStudentDetails(id);
      if (details && details.error) {
        throw new Error(details.error);
      }
      setSelectedStudent(details);
    } catch (e: any) {
      showAlert(e.message || "Failed to fetch student details");
    }
  };

  // Attendance Logic
  const searchAttendanceStudent = async (overrideTarget?: string, isAutomatic = false) => {
    const val = overrideTarget || attendanceSearch.roll_number;
    if (!val) {
      if (!isAutomatic) {
        setAttendanceStudent(null);
        showAlert("Please enter a roll number");
      }
      return;
    }

    if (isAttendanceSearching) return;

    setIsAttendanceSearching(true);
    setAllowCrossBatch(false);
    try {
      const targetQuery = String(val).trim().toLowerCase();
      const targetQueryClean = targetQuery.replace(/[\s-]/g, "");
      const selectedBatchId = attendanceSearch.batch_id;
      
      if (!selectedBatchId || selectedBatchId === "all") {
        if (!isAutomatic) showAlert("Please select a specific batch first");
        setIsAttendanceSearching(false);
        return;
      }

      // 1. If batch is selected, prioritize searching WITHIN that batch first
      let student = null;
      if (selectedBatchId && selectedBatchId !== "all") {
          student = students.find(s => {
              const belongs = String(s.batch_id) === String(selectedBatchId) || String(s.batch_id_2) === String(selectedBatchId);
              if (!belongs) return false;
              const sRoll = String(s.roll_number || "").toLowerCase().trim();
              const sPhone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
              return sRoll === targetQuery || sPhone === targetQueryClean;
          });
      }

      // 2. Fast Lookup via Map (fallback or if no batch selected)
      if (!student) {
        student = studentsMap.get(targetQuery) || studentsMap.get(targetQueryClean);
        
        if (student && selectedBatchId && selectedBatchId !== "all") {
            const belongsToBatch = 
              String(student.batch_id) === String(selectedBatchId) || 
              String(student.batch_id_2) === String(selectedBatchId) ||
              (student.enrolled_courses && student.enrolled_courses.some((c: any) => String(c) === String(selectedBatchId) || (c.id && String(c.id) === String(selectedBatchId))));
            
            if (!belongsToBatch) {
              showAlert("স্টুডেন্টটি অন্য ব্যাচে পাওয়া গেছে। দয়া করে সঠিক ব্যাচ সিলেক্ট করুন অথবা 'All Batches' দিন।", "error");
              setIsAttendanceSearching(false);
              return;
            }
        }
      }

      // 3. Last Fallback: Global name/substring search
      if (!student) {
          student = students.find((s) => {
              const sRoll = String(s.roll_number || "").toLowerCase().trim();
              const sPhone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
              const sName = String(s.name || "").toLowerCase();
              
              const matches = sRoll.includes(targetQuery) || sPhone.includes(targetQueryClean) || sName.includes(targetQuery);
              if (!matches) return false;

              // If batch selected, only match if in batch
              if (selectedBatchId && selectedBatchId !== "all") {
                  return String(s.batch_id) === String(selectedBatchId) || String(s.batch_id_2) === String(selectedBatchId);
              }
              return true;
          });
      }

      if (!student) {
        setAttendanceStudent(null);
        if (!isAutomatic) showAlert(`Student not found with query: ${val}`);
        setIsAttendanceSearching(false);
        return;
      }

      // Fast Path: Show basic info instantly from students list
      setAttendanceLocked(false);
      setAllowCrossBatch(true);
      setAttendanceStudent({ ...student });
      setIsAttendanceSearching(false); // Move this up to clear searching state instantly

      // Immediate Auto-Mark (Optimization)
      if (autoMark) {
        // Clear search input to ready for next one immediately
        if (!isAutomatic) {
           setAttendanceSearch(prev => ({ ...prev, roll_number: "" }));
        }

        // Trigger mark attendance in background
        const todayStr = format(new Date(), "yyyy-MM-dd");
        fetch("/api/attendance/mark-present", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              student_id: student.id,
              batch_id: student.batch_id,
              date: todayStr,
              status: "present",
              type: "class",
            }),
        }).then(async (res) => {
            if (res.ok) {
              showAlert(`Student ${student.name} (Roll: ${student.roll_number}) marked present`);
              setAttendanceStudent((prev: any) => {
                if (!prev || prev.id !== student.id) return prev;
                return {
                  ...prev,
                  attendance: [
                    ...(prev?.attendance || []).filter((r: any) => !(r.date === todayStr && r.type !== "exam")),
                    { date: todayStr, status: "present", type: "class" },
                  ],
                };
              });
            }
        });
      }

      // Fetch full details in background to refresh UI if needed
      try {
          const details = await fetchStudentDetails(student.id);
          if (details && !details.error) {
             setAttendanceStudent((prev: any) => {
                 if (prev && prev.id === details.id) return details;
                 return prev;
             });
          }
      } catch (e) {
          console.warn("Background fetch failed", e);
      }
    } catch (e) {
      console.error(e);
      setIsAttendanceSearching(false);
    } finally {
      setIsAttendanceSearching(false);
    }
  };

  const searchExamAttendanceStudent = async (overrideRoll?: string, isAutomatic = false) => {
    const val = overrideRoll || examAttendanceSearch.roll_number;
    if (!val || !examAttendanceSearch.exam_id) {
      if (!isAutomatic) showAlert("Please select exam and enter roll number");
      return;
    }
    
    if (isAttendanceSearching) return;
    setIsAttendanceSearching(true);
    setExamAttendanceStudent(null);
    setAllowCrossBatch(false);
    try {
      const targetQuery = String(val).trim().toLowerCase();
      const targetQueryClean = targetQuery.replace(/[\s-]/g, "");
      const selectedBatchId = examAttendanceSearch.batch_id;
      
      if (!selectedBatchId || selectedBatchId === "all") {
        if (!isAutomatic) showAlert("Please select a specific batch first");
        return;
      }

      let student = null;
      if (selectedBatchId && selectedBatchId !== "all") {
        student = students.find((s) => {
          const isSameBatch =
            String(s.batch_id) === String(selectedBatchId) ||
            String(s.batch_id_2) === String(selectedBatchId);
          if (!isSameBatch) return false;

          const sRoll = String(s.roll_number || "").toLowerCase().trim();
          const sPhone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
          const sId = String(s.id || "").toLowerCase().trim();
          const sStudentId = String(s.student_id || "").toLowerCase().trim();
          const sName = String(s.name || "").toLowerCase();

          return (
            sRoll === targetQuery ||
            sRoll.includes(targetQuery) ||
            sPhone.endsWith(targetQueryClean) ||
            sPhone.includes(targetQueryClean) ||
            sId === targetQuery ||
            sStudentId === targetQuery ||
            sName.includes(targetQuery)
          );
        });
      }

      if (!student && selectedBatchId && selectedBatchId !== "all") {
        setExamAttendanceStudent(null);
        if (!isAutomatic) showAlert("স্টুডেন্টটি অন্য ব্যাচে পাওয়া গেছে। দয়া করে সঠিক ব্যাচ সিলেক্ট করুন অথবা 'All Batches' দিন।", "error");
        setIsAttendanceSearching(false);
        return;
      }

      if (!student) {
        student = students.find((s) => {
          const sRoll = String(s.roll_number || "").toLowerCase().trim();
          const sPhone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
          const sId = String(s.id || "").toLowerCase().trim();
          const sStudentId = String(s.student_id || "").toLowerCase().trim();
          const sName = String(s.name || "").toLowerCase();

          return (
            sRoll === targetQuery ||
            sRoll.includes(targetQuery) ||
            sPhone.endsWith(targetQueryClean) ||
            sPhone.includes(targetQueryClean) ||
            sId === targetQuery ||
            sStudentId === targetQuery ||
            sName.includes(targetQuery)
          );
        });
      }

      if (!student) {
        setExamAttendanceStudent(null);
        if (!isAutomatic) showAlert(`Student not found with query: ${val}`);
        setIsAttendanceSearching(false);
        return;
      }

      const initialStudentData = { ...student };
      setAllowCrossBatch(true);

      const details = await fetchStudentDetails(student.id);
      if (details && !details.error) {
        setExamAttendanceStudent(details);
      } else {
        setExamAttendanceStudent(initialStudentData);
        if (!isAutomatic) showAlert(details?.error || "Student details not found.");
      }
    } catch (e) {
      console.error(e);
      setIsAttendanceSearching(false);
    } finally {
      setIsAttendanceSearching(false);
    }
  };

  const markSingleAttendance = async (status: "present" | "absent") => {
    if (!attendanceStudent) return;

    // Check if student was enrolled before today
    const enrollmentDate = new Date(
      attendanceStudent.created_at ||
        attendanceStudent.date_of_admission ||
        new Date(),
    );
    enrollmentDate.setHours(0, 0, 0, 0);
    const todayObj = new Date();
    todayObj.setHours(0, 0, 0, 0);

    if (enrollmentDate > todayObj) {
      showAlert("Student was not enrolled when this class took place");
      return;
    }

    const date = format(new Date(), "yyyy-MM-dd");
    const time = ""; // Time no longer matters

    // Find existing record to update instead of creating a new one
    const existingTodayRecord = attendanceStudent.attendance?.find(
      (r: any) => r.date === date && r.type !== "exam" && !r.id?.includes("auto-absent"),
    );

    // Optimistic update
    const previousStudent = { ...attendanceStudent };
    const recordBatchId = attendanceSearch.batch_id === "all" ? (attendanceStudent.batch_id || "all") : (attendanceSearch.batch_id || attendanceStudent.batch_id);
    const batchName = batches.find((b) => String(b.id) === String(recordBatchId))?.name || "N/A";
    const programId = attendanceSearch.program_id || attendanceStudent.program_id;

    const newRecord: any = {
      date,
      time,
      status,
      type: "class",
      student_id: attendanceStudent.id,
      student_name: attendanceStudent.name,
      batch_id: recordBatchId,
      batch_name: batchName,
      program_id: programId,
      roll_number: attendanceStudent.roll_number,
    };

    const updatedAttendance = attendanceStudent.attendance
      ? [
          ...attendanceStudent.attendance.filter(
            (r: any) => !(r.date === date && r.type !== "exam"),
          ),
          { ...newRecord, id: existingTodayRecord?.id || `temp-${Date.now()}` },
        ]
      : [{ ...newRecord, id: `temp-${Date.now()}` }];

    setAttendanceStudent({
      ...attendanceStudent,
      attendance: updatedAttendance,
    });

    try {
      const url = existingTodayRecord?.id 
        ? `/api/attendance/${existingTodayRecord.id}` 
        : "/api/attendance";
      
      const res = await fetch(url, {
        method: existingTodayRecord?.id ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newRecord),
      });

      if (res.ok) {
        const result = await safeJson(res);
        if (!existingTodayRecord?.id && result.id) {
          // Update temp ID with real ID
          setAttendanceStudent((prev: any) => {
             if (!prev) return prev;
             return {
               ...prev,
               attendance: prev.attendance.map((r: any) => 
                 r.date === date && r.type !== "exam" ? { ...r, id: result.id } : r
               )
             };
          });
        }
        showAlert(`Marked as ${status}`);
        setAttendanceSearch(prev => ({ ...prev, roll_number: "" }));
      } else {
        setAttendanceStudent(previousStudent);
        const err = await safeJson(res);
        showAlert(err.error || "Failed to mark attendance");
      }
    } catch (e) {
      setAttendanceStudent(previousStudent);
      console.error(e);
    }
  };

  const markSingleExamAttendance = async (status: "present" | "absent") => {
    if (
      !examAttendanceStudent ||
      !examAttendanceSearch.exam_id ||
      !examAttendanceSearch.batch_id
    ) {
      showAlert("Please select an exam and search for a student first");
      return;
    }

    // Check if student was enrolled before today
    const enrollmentDate = new Date(
      examAttendanceStudent.created_at ||
        examAttendanceStudent.date_of_admission ||
        new Date(),
    );
    const todayObj = new Date();
    todayObj.setHours(0, 0, 0, 0);

    if (enrollmentDate > todayObj) {
      showAlert("Student was not enrolled when this exam took place");
      return;
    }

    const date = format(new Date(), "yyyy-MM-dd");
    const time = ""; // Time no longer matters

    // Find existing record
    const existingTodayRecord = examAttendanceStudent.attendance?.find(
      (r: any) => r.date === date && r.type === "exam" && String(r.exam_id) === String(examAttendanceSearch.exam_id),
    );

    // Optimistic update
    const previousStudent = { ...examAttendanceStudent };
    const recordBatchId = examAttendanceSearch.batch_id === "all" ? (examAttendanceStudent.batch_id || "all") : examAttendanceSearch.batch_id;
    const batchName = batches.find((b) => String(b.id) === String(recordBatchId))?.name || "N/A";
    const programId = examAttendanceSearch.program_id || examAttendanceStudent.program_id;
    const todayExam = exams.find((e) => String(e.id) === String(examAttendanceSearch.exam_id));

    const newRecord: any = {
      date,
      time,
      status,
      type: "exam",
      exam_id: examAttendanceSearch.exam_id,
      exam_name: todayExam?.exam_name || todayExam?.title || "Exam",
      student_id: examAttendanceStudent.id,
      student_name: examAttendanceStudent.name,
      batch_id: recordBatchId,
      batch_name: batchName,
      program_id: programId,
      roll_number: examAttendanceStudent.roll_number,
    };

    const updatedAttendance = examAttendanceStudent.attendance
      ? [
          ...examAttendanceStudent.attendance.filter(
            (r: any) =>
              !(
                r.date === date &&
                r.type === "exam" &&
                String(r.exam_id) === String(examAttendanceSearch.exam_id)
              ),
          ),
          { ...newRecord, id: existingTodayRecord?.id || `temp-${Date.now()}` },
        ]
      : [{ ...newRecord, id: `temp-${Date.now()}` }];

    setExamAttendanceStudent({
      ...examAttendanceStudent,
      attendance: updatedAttendance,
    });

    try {
      const url = existingTodayRecord?.id 
        ? `/api/attendance/${existingTodayRecord.id}` 
        : "/api/attendance";

      const res = await fetch(url, {
        method: existingTodayRecord?.id ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newRecord),
      });

      if (res.ok) {
        const result = await safeJson(res);
        if (!existingTodayRecord?.id && result.id) {
          setExamAttendanceStudent((prev: any) => {
            if (!prev) return prev;
            return {
              ...prev,
              attendance: prev.attendance.map((r: any) => 
                (r.date === date && r.type === "exam" && String(r.exam_id) === String(examAttendanceSearch.exam_id)) ? { ...r, id: result.id } : r
              )
            };
          });
        }
        showAlert(`Marked as ${status} for exam`);
        setExamAttendanceSearch(prev => ({ ...prev, roll_number: "" }));
      } else {
        setExamAttendanceStudent(previousStudent);
        const err = await safeJson(res);
        showAlert(err.error || "Failed to mark exam attendance");
      }
    } catch (e) {
      setExamAttendanceStudent(previousStudent);
      console.error(e);
    }
  };

  // Payment Logic
  const searchPaymentStudent = async (overrideTarget?: string, isAutomatic = false) => {
    setPaymentStudent(null);
    const val = overrideTarget || paymentSearch.roll_number;
    if (!val) return;
    try {
      const targetQuery = String(val).trim().toLowerCase();
      const targetQueryClean = targetQuery.replace(/[\s-]/g, "");
      const selectedBatchId = paymentSearch.batch_id;
      
      if (!selectedBatchId || selectedBatchId === "all") {
        if (!isAutomatic) showAlert("Please select a specific batch first");
        return;
      }

      let student = null;
      if (selectedBatchId && selectedBatchId !== "all") {
        student = students.find((s) => {
          const isSameBatch =
            String(s.batch_id) === String(selectedBatchId) ||
            String(s.batch_id_2) === String(selectedBatchId);
          if (!isSameBatch) return false;

          const sRoll = String(s.roll_number || "").toLowerCase().trim();
          const sPhone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
          const sId = String(s.id || "").toLowerCase().trim();
          const sStudentId = String(s.student_id || "").toLowerCase().trim();
          const sName = String(s.name || "").toLowerCase();

          return (
            sRoll === targetQuery ||
            sRoll.includes(targetQuery) ||
            sPhone.endsWith(targetQueryClean) ||
            sPhone.includes(targetQueryClean) ||
            sId === targetQuery ||
            sStudentId === targetQuery ||
            sName.includes(targetQuery)
          );
        });
      }

      if (!student && selectedBatchId && selectedBatchId !== "all") {
        setPaymentStudent(null);
        if (!isAutomatic) showAlert("স্টুডেন্টটি অন্য ব্যাচে পাওয়া গেছে। দয়া করে সঠিক ব্যাচ সিলেক্ট করুন অথবা 'All Batches' দিন।", "error");
        return;
      }

      if (!student) {
        student = students.find((s) => {
          const sRoll = String(s.roll_number || "").toLowerCase().trim();
          const sPhone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
          const sId = String(s.id || "").toLowerCase().trim();
          const sStudentId = String(s.student_id || "").toLowerCase().trim();
          const sName = String(s.name || "").toLowerCase();

          return (
            sRoll === targetQuery ||
            sRoll.includes(targetQuery) ||
            sPhone.endsWith(targetQueryClean) ||
            sPhone.includes(targetQueryClean) ||
            sId === targetQuery ||
            sStudentId === targetQuery ||
            sName.includes(targetQuery)
          );
        });
      }

      if (student) {
        // Fast Path: Show basic info instantly
        setPaymentStudent({ ...student });
        setPaymentData((prev) => ({
          ...prev,
          amount: student.monthly_fee?.toString() || "",
        }));

        const details = await fetchStudentDetails(student.id);
        if (details && !details.error) {
          setPaymentStudent(details);
        } else {
          if (!isAutomatic) showAlert(details?.error || "Student details not found");
        }
      } else {
        setPaymentStudent(null);
        if (!isAutomatic) showAlert(`Student not found with query: ${val}`);
      }
    } catch (e) {
      console.error(e);
      showAlert("Error searching for student");
    }
  };

  const handleAddPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentStudent) return;

    if (paymentData.type === "monthly" && paymentData.month) {
      const existingPayment = paymentStudent.payments?.find(
        (p: any) => 
          p.type === "monthly" && 
          p.month === paymentData.month && 
          (String(p.year) === String(paymentData.year) || (!p.year && format(new Date(p.date), "yyyy") === String(paymentData.year)))
      );
      if (existingPayment) {
        showAlert(
          `Payment for ${paymentData.month} ${paymentData.year} has already been recorded.`,
        );
        return;
      }
    }

    try {
      const batch = batches.find((b) => b.id == paymentSearch.batch_id);
      const batchName = batch?.name || "";
      const programId = batch?.program_id || "";
      const res = await fetch("/api/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...paymentData,
          student_id: paymentStudent.id,
          student_name: paymentStudent.name,
          roll_number: paymentStudent.roll_number,
          batch_name: batchName,
          batch_id: paymentSearch.batch_id,
          program_id: programId,
        }),
      });

      showAlert("Payment recorded");
      setPaymentData({ ...paymentData, amount: "", type: "monthly" });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to record payment");
      }

      const details = await fetchStudentDetails(paymentStudent.id);
      setPaymentStudent(details);
      fetchAllPayments();
    } catch (e: any) {
      console.error(e);
      showAlert(e.message || "Failed to record payment");
    }
  };

  // Results Logic
  const searchResultStudent = async (overrideTarget?: string, isAutomatic = false) => {
    const val = overrideTarget || resultSearch.roll_number;
    if (!val) {
      if (!isAutomatic) showAlert("Please enter a roll or phone number");
      return;
    }
    setResultStudent(null);
    try {
      const targetQuery = String(val).trim().toLowerCase();
      const targetQueryClean = targetQuery.replace(/[\s-]/g, "");
      const selectedBatchId = resultSearch.batch_id;
      
      if (!selectedBatchId || selectedBatchId === "all") {
        if (!isAutomatic) showAlert("Please select a specific batch first");
        return;
      }

      let student = null;
      if (selectedBatchId && selectedBatchId !== "all") {
        student = students.find((s) => {
          const isSameBatch =
            String(s.batch_id) === String(selectedBatchId) ||
            String(s.batch_id_2) === String(selectedBatchId);
          if (!isSameBatch) return false;

          const sRoll = String(s.roll_number || "").toLowerCase().trim();
          const sPhone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
          const sId = String(s.id || "").toLowerCase().trim();
          const sStudentId = String(s.student_id || "").toLowerCase().trim();
          const sName = String(s.name || "").toLowerCase();

          return (
            sRoll === targetQuery ||
            sRoll.includes(targetQuery) ||
            sPhone.endsWith(targetQueryClean) ||
            sPhone.includes(targetQueryClean) ||
            sId === targetQuery ||
            sStudentId === targetQuery ||
            sName.includes(targetQuery)
          );
        });
      }

      if (!student && selectedBatchId && selectedBatchId !== "all") {
        setResultStudent(null);
        if (!isAutomatic) showAlert("স্টুডেন্টটি অন্য ব্যাচে পাওয়া গেছে। দয়া করে সঠিক ব্যাচ সিলেক্ট করুন অথবা 'All Batches' দিন।", "error");
        return;
      }

      if (!student) {
        student = students.find((s) => {
          const sRoll = String(s.roll_number || "").toLowerCase().trim();
          const sPhone = String(s.phone || "").toLowerCase().replace(/[\s-]/g, "");
          const sId = String(s.id || "").toLowerCase().trim();
          const sStudentId = String(s.student_id || "").toLowerCase().trim();
          const sName = String(s.name || "").toLowerCase();

          return (
            sRoll === targetQuery ||
            sRoll.includes(targetQuery) ||
            sPhone.endsWith(targetQueryClean) ||
            sPhone.includes(targetQueryClean) ||
            sId === targetQuery ||
            sStudentId === targetQuery ||
            sName.includes(targetQuery)
          );
        });
      }

      if (student) {
        // Fast Path: Show basic info instantly
        setResultStudent({ ...student });

        const details = await fetchStudentDetails(student.id);
        if (details && !details.error) {
          setResultStudent(details);
        } else {
          if (!isAutomatic) showAlert(details?.error || "Student details not found");
        }
      } else {
        setResultStudent(null);
        if (!isAutomatic) showAlert(`Student not found with query: ${val}`);
      }
    } catch (e) {
      console.error(e);
      showAlert("Error searching for student");
    }
  };

  const handleAddResult = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resultStudent) return;

    // Find the selected exam to get its name and total marks
    const selectedExam = exams.find((e) => e.id == newResult.exam_id);
    const exam_name = selectedExam ? selectedExam.exam_name : "Unknown Exam";
    const total_marks = selectedExam
      ? selectedExam.total_marks || selectedExam.marks || 0
      : 0;

    // Calculate marks
    const correct = parseFloat(newResult.correct_answers) || 0;
    const wrong = parseFloat(newResult.wrong_answers) || 0;
    const negative = parseFloat(newResult.negative_marks) || 0;
    const marks = correct - wrong * negative;

    try {
      const res = await fetch("/api/results", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...newResult,
          marks,
          total_marks,
          student_id: resultStudent.id,
          student_name: resultStudent.name,
          roll_number: resultStudent.roll_number,
          batch_id: resultSearch.batch_id,
          exam_name,
        }),
      });

      showAlert("Result added successfully");
      // Keep exam details for batch entry, only clear student-specific marks
      setNewResult((prev) => ({
        ...prev,
        correct_answers: "",
        wrong_answers: "",
      }));

      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to add result");
      }

      // Refresh student details to show updated results if needed
      const details = await fetchStudentDetails(resultStudent.id);
      setResultStudent(details);
      fetchAllResults();
    } catch (e: any) {
      console.error(e);
      showAlert(e.message || "Failed to add result");
    }
  };

  const handleDeleteResultHistory = async (id: string) => {
    if (await showConfirm("Are you sure you want to delete this exam history?")) {
      try {
        await deleteDoc(doc(db, "result_histories", id));
        showAlert("Result history deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete result history", "error");
      }
    }
  };

  const handlePublishResults = async (examId: string) => {
    const confirm = await showConfirm(
      "Are you sure you want to publish results for this exam? This will calculate merit positions for all students.",
    );
    if (!confirm) return;

    setLoading(true);
    try {
      // 1. Fetch all results for this exam
      const resultsRes = await fetch(`/api/results?exam_id=${examId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!resultsRes.ok) throw new Error("Failed to fetch results");
      const examResults = await safeJson(resultsRes);

      if (!Array.isArray(examResults) || examResults.length === 0) {
        showAlert("No results found for this exam to publish.");
        return;
      }

      // 2. Sort by marks descending
      const sortedResults = [...examResults].sort(
        (a, b) => (b.marks || 0) - (a.marks || 0),
      );
      const highestMarks =
        sortedResults.length > 0 ? sortedResults[0].marks || 0 : 0;

      // 3. Update each result with merit position and highest marks
      const updatePromises = sortedResults.map((res, index) => {
        return fetch(`/api/results/${res.id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            ...res,
            merit_position: index + 1,
            highest_marks: highestMarks,
          }),
        });
      });

      await Promise.all(updatePromises);

      // 4. Mark exam as published
      await fetch(`/api/exams/${examId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ published: true }),
      });

      // 5. Store a snapshot in result_histories
      const examName = examResults[0]?.exam_name || "Unknown Exam";
      const examBatchId = examResults[0]?.batch_id || "";

      await addDoc(collection(db, "result_histories"), {
        exam_id: examId,
        exam_name: examName,
        batch_id: examBatchId,
        highest_marks: highestMarks,
        total_students: sortedResults.length,
        published_at: new Date().toISOString(),
        content: JSON.stringify(
          sortedResults.map((r, i) => ({
            roll_number: r.roll_number,
            student_name: r.student_name,
            marks: r.marks,
            merit_position: i + 1,
            batch_id: r.batch_id,
          }))
        )
      });

      showAlert("Results published successfully with merit positions!");
      fetchExams();
      fetchAllResults();
    } catch (error: any) {
      console.error(error);
      showAlert(error.message || "Failed to publish results");
    } finally {
      setLoading(false);
    }
  };

  const filteredStudents = useMemo(
    () => {
      // Only compute if we are on student management tabs
      if (!["students", "online_students", "attendance"].includes(activeTab)) return [];

      return students.filter(
        (s) =>
          (s.name?.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
            String(s.roll_number || "")
              .toLowerCase()
              .includes(debouncedSearchTerm.toLowerCase()) ||
            String(s.phone || "")
              .toLowerCase()
              .includes(debouncedSearchTerm.toLowerCase()) ||
            String(s.id || "")
              .toLowerCase()
              .includes(debouncedSearchTerm.toLowerCase())) &&
          (activeTab === "online_students" ||
            !selectedBatch ||
            selectedBatch === "all" ||
            String(s.batch_id) === String(selectedBatch) ||
            String(s.batch_id_2) === String(selectedBatch)) &&
          (activeTab === "online_students" || studentStatusFilter === "all" || s.status === studentStatusFilter) &&
          (activeTab === "online_students"
            ? (s.student_type === "online" || !!s.course_id || (Array.isArray(s.enrolled_courses) && s.enrolled_courses.length > 0))
            : (s.student_type !== "online" && !s.course_id && (!Array.isArray(s.enrolled_courses) || s.enrolled_courses.length === 0))),
      );
    },
    [
      students,
      debouncedSearchTerm,
      selectedBatch,
      studentStatusFilter,
      activeTab,
    ],
  );

  const allStudentsByBatch = useMemo(() => {
    const grouped: Record<string, any[]> = {};
    students.forEach((s) => {
      if (s.batch_id) {
        if (!grouped[s.batch_id]) grouped[s.batch_id] = [];
        grouped[s.batch_id].push(s);
      }
      if (s.batch_id_2 && s.batch_id_2 !== s.batch_id) {
        if (!grouped[s.batch_id_2]) grouped[s.batch_id_2] = [];
        grouped[s.batch_id_2].push(s);
      }
    });
    return grouped;
  }, [students]);

  const chartData = useMemo(() => {
    return batches.map((b) => {
      const batchStudents = allStudentsByBatch[b.id] || [];
      return {
        name: b.name,
        students: batchStudents.filter(
          (s) => s.student_type !== "online" && s.status === "approved",
        ).length,
      };
    });
  }, [batches, allStudentsByBatch]);

  const programStats = useMemo(() => {
    // Pre-calculate student counts and payments per program
    const studentCountByProg: Record<string, number> = {};
    const revenueByProg: Record<string, number> = {};
    const batchCountByProg: Record<string, number> = {};

    students.forEach((s) => {
      if (s.status === "approved" && s.program_id) {
        studentCountByProg[s.program_id] = (studentCountByProg[s.program_id] || 0) + 1;
      }
    });

    batches.forEach((b) => {
      if (b.program_id) {
        batchCountByProg[b.program_id] = (batchCountByProg[b.program_id] || 0) + 1;
      }
    });

    allPayments.forEach((p) => {
      if (p.program_id) {
        revenueByProg[p.program_id] = (revenueByProg[p.program_id] || 0) + (Number(p.amount) || 0);
      }
    });

    return programs.map((prog) => {
      return {
        ...prog,
        studentCount: studentCountByProg[prog.id] || 0,
        batchCount: batchCountByProg[prog.id] || 0,
        totalRevenue: revenueByProg[prog.id] || 0,
      };
    });
  }, [programs, students, batches, allPayments]);

  const sortedPayments = useMemo(() => {
    let filtered = [...allPayments];
    if (paymentProgramFilter) {
      filtered = filtered.filter((p) => {
        if (p.program_id)
          return String(p.program_id) === String(paymentProgramFilter);
        // Fallback for existing payments: find student by roll_number
        const student = students.find((s) => s.roll_number === p.roll_number);
        if (student) {
          const program = programs.find(
            (pr) => pr.title === student.program_title,
          );
          return program?.id == paymentProgramFilter;
        }
        return false;
      });
    }
    return filtered.sort((a, b) => {
      if (paymentSort === "date")
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      if (paymentSort === "student")
        return (a.student_name || "").localeCompare(b.student_name || "");
      if (paymentSort === "batch")
        return (a.batch_name || "").localeCompare(b.batch_name || "");
      return 0;
    });
  }, [allPayments, paymentSort, paymentProgramFilter, students, programs]);

  const meritPositions = useMemo(() => {
    const positions: Record<string, Record<string, number>> = {};
    const grouped: Record<string, any[]> = {};
    allResults.forEach((r) => {
      const key = r.exam_id || r.exam_name;
      if (key) {
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(r);
      }
    });

    Object.keys(grouped).forEach((key) => {
      const results = [...grouped[key]];
      results.sort(
        (a, b) => parseFloat(b.marks || "0") - parseFloat(a.marks || "0"),
      );
      positions[key] = {};
      results.forEach((r, index) => {
        positions[key][r.student_id] = index + 1;
      });
    });
    return positions;
  }, [allResults]);

  const batchMap = useMemo(() => {
    const map = new Map();
    batches.forEach((b) => map.set(String(b.id), b));
    return map;
  }, [batches]);

  const programMap = useMemo(() => {
    const map = new Map();
    programs.forEach((p) => map.set(String(p.id), p));
    return map;
  }, [programs]);

  const dashboardStats = useMemo(() => {
    let offlineCount = 0;
    let onlineCount = 0;
    
    students.forEach((s) => {
      if (s.status === "approved") {
        if (s.student_type === "online") onlineCount++;
        else offlineCount++;
      }
    });

    const pendingEnrollCount = enrollments.filter((e) => e.status === "pending").length;
    const totalRev = allPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

    return {
      offlineCount,
      onlineCount,
      pendingEnrollCount,
      totalRev,
    };
  }, [students, enrollments, allPayments]);

  const studentsByBatch = useMemo(() => {
    // Only compute if we are on students tab
    if (activeTab !== "students" && activeTab !== "attendance") return {};
    
    const grouped: Record<string, any[]> = {};
    filteredStudents.forEach((s) => {
      if (s.batch_id) {
        if (!grouped[s.batch_id]) grouped[s.batch_id] = [];
        grouped[s.batch_id].push(s);
      }
      if (s.batch_id_2 && s.batch_id_2 !== s.batch_id) {
        if (!grouped[s.batch_id_2]) grouped[s.batch_id_2] = [];
        grouped[s.batch_id_2].push(s);
      }
    });
    Object.keys(grouped).forEach((key) => {
      grouped[key].sort(
        (a, b) =>
          (parseInt(a.roll_number) || 0) - (parseInt(b.roll_number) || 0),
      );
    });
    return grouped;
  }, [filteredStudents, activeTab]);

  const studentsByCourse = useMemo(() => {
    // Only compute if we are on online_students tab
    if (activeTab !== "online_students") return {};

    const grouped: Record<string, any[]> = {};
    filteredStudents.forEach((s) => {
      // Check both course_id and enrolled_courses array
      const cid = s.course_id || (Array.isArray(s.enrolled_courses) ? s.enrolled_courses[0] : null);
      if (cid) {
        if (!grouped[cid]) grouped[cid] = [];
        grouped[cid].push(s);
      }
    });
    Object.keys(grouped).forEach((key) => {
      grouped[key].sort(
        (a, b) =>
          (parseInt(a.roll_number) || 0) - (parseInt(b.roll_number) || 0),
      );
    });
    return grouped;
  }, [filteredStudents, activeTab]);

  const isClassDay = (student: any) => {
    return true; // Always allow attendance marking in admin panel
  };

  const handleDeletePayment = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete payment records", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "payments", id));
        showAlert("Payment record deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete payment record", "error");
      }
    }
  };

  const handleDeleteChapter = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete chapters", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "chapters", id));
        showAlert("Chapter deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete chapter", "error");
      }
    }
  };

  const handleDeleteExam = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete exams", "error");
      return;
    }
    if (await showConfirm("Are you sure? This will also delete all attendance records for this exam.")) {
      try {
        const attSnap = await getDocs(query(collection(db, "attendance"), where("exam_id", "==", id)));
        const batchRef = writeBatch(db);
        attSnap.docs.forEach(d => batchRef.delete(d.ref));
        await batchRef.commit();

        await deleteDoc(doc(db, "exams", id));
        showAlert("Exam and its attendance deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete exam", "error");
      }
    }
  };

  const handleDeleteResult = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete results", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "results", id));
        showAlert("Result deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete result", "error");
      }
    }
  };

  const handleDeleteEnrollment = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete enrollments", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "enrollments", id));
        showAlert("Enrollment deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete enrollment", "error");
      }
    }
  };

  const handleDeleteStudent = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete students", "error");
      return;
    }
    if (await showConfirm("Are you sure you want to delete this student?")) {
      try {
        setStudents(prev => prev.filter(s => s.id !== id));
        if (searchResult?.id === id) setSearchResult(null);
        if (selectedStudent?.id === id) setSelectedStudent(null);
        
        const res = await fetch(`/api/students/${id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error("Failed to delete student");
        showAlert("Student deleted successfully", "success");
      } catch (e: any) {
        console.error(e);
        showAlert(e.message || "Error deleting student", "error");
      }
    }
  };

  const getYoutubeThumbnail = (url: string) => {
    const regExp =
      /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    if (match && match[2].length === 11) {
      return `https://img.youtube.com/vi/${match[2]}/mqdefault.jpg`;
    }
    return "https://picsum.photos/seed/video/400/225";
  };

  const fetchAllPayments = async () => {};
  const fetchChapters = async () => {};
  const fetchExams = async () => {};
  const fetchCourses = async () => {};
  const fetchGallery = async () => {};
  const fetchResources = async () => {};
  const fetchMessages = async () => {};
  const fetchSlides = async () => {
    try {
      const res = await fetch("/api/class-slides?t=" + Date.now(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await safeJson(res);
        setClassSlides(data);
      }
    } catch (e) {
      console.error(e);
    }
  };
  const fetchAttendanceReport = async () => {
    if (!attendanceReportFilter.batch_id && !attendanceReportFilter.startDate && !attendanceReportFilter.endDate && !attendanceReportFilter.program_id) {
      showAlert("Please enter a filter criteria (Batch or Date Range recommended)");
      return;
    }
    
    try {
      const queryParams = new URLSearchParams();
      if (attendanceReportFilter.batch_id) queryParams.append("batch_id", attendanceReportFilter.batch_id);
      if (attendanceReportFilter.program_id) queryParams.append("program_id", attendanceReportFilter.program_id);
      if (attendanceReportFilter.startDate) queryParams.append("startDate", attendanceReportFilter.startDate);
      if (attendanceReportFilter.endDate) queryParams.append("endDate", attendanceReportFilter.endDate);
      if (attendanceReportFilter.type) queryParams.append("type", attendanceReportFilter.type);
      if (attendanceReportFilter.status) queryParams.append("status", attendanceReportFilter.status);

      const res = await fetch(`/api/attendance/report?${queryParams.toString()}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) throw new Error("Failed to fetch report");
      
      let finalData = await res.json();
      
      if (attendanceReportFilter.program_id && !attendanceReportFilter.batch_id) {
         const programBatches = batches.filter(b => String(b.program_id) === String(attendanceReportFilter.program_id)).map(b => String(b.id));
         finalData = finalData.filter((d: any) => programBatches.includes(String(d.batch_id)));
      }
      
      finalData.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime() || (b.time || "").localeCompare(a.time || ""));
      setAttendanceReport(finalData);
      
      if (finalData.length === 0) showAlert("No records found", "error");
      else showAlert(`Loaded ${finalData.length} records`, "success");
      
    } catch(e: any) {
      console.error(e);
      showAlert("Failed to load attendance report");
    }
  };

  const handleAddDegree = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      const res = await fetch("/api/degrees", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: "New Degree", // You would typically have a state for form inputs
        }),
      });
      if (!res.ok) throw new Error("Failed to add degree");
      showAlert("Degree added successfully", "success");
    } catch (e: any) {
      showAlert(e.message || "Failed to add degree", "error");
    } finally {
      setLoading(false);
    }
  };
  const handleDeleteDegree = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete degrees", "error");
      return;
    }
    if (await showConfirm("Are you sure you want to delete this degree?")) {
      try {
        await deleteDoc(doc(db, "degrees", id));
        showAlert("Degree deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete degree", "error");
      }
    }
  };

  const handleAddProgram = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/programs", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(newProgram)
      });
      if (res.ok) {
        setNewProgram({ title: "", description: "", features: "", target_audience: "", admission_fee: "", monthly_fee: "", image_url: "" });
        showAlert("Program added successfully");
      }
    } catch (e) { console.error(e); }
  };

  const handleUpdateProgram = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProgram) return;
    try {
      setLoading(true);
      const res = await fetch(`/api/programs/${editingProgram.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(editingProgram),
      });
      if (!res.ok) throw new Error("Failed to update program");
      showAlert("Program updated successfully", "success");
      setEditingProgram(null);
    } catch (e: any) {
      showAlert(e.message || "Failed to update program", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleCancelEnrollment = async (id: string) => {
    if (await showConfirm("Cancel this enrollment?")) {
      try {
        const res = await fetch(`/api/enrollments/${id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error("Failed to cancel enrollment");
        showAlert("Enrollment cancelled successfully", "success");
      } catch (e: any) {
        showAlert(e.message || "Failed to cancel enrollment", "error");
      }
    }
  };

  const handleUpdateEnrollmentStatus = async (id: string, status: string, roll_number?: string, monthly_fee?: string, admission_fee?: string, batch_id?: string) => {
    try {
      const payload: any = { status };
      if (status === "approved") {
        if (roll_number) payload.roll_number = roll_number;
        if (monthly_fee) payload.monthly_fee = monthly_fee;
        if (admission_fee) payload.admission_fee = admission_fee;
        if (batch_id) payload.batch_id = batch_id;
      }
      
      const res = await fetch(`/api/enrollments/${id}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("Failed to update status");
      showAlert("Enrollment status updated", "success");
    } catch (e: any) {
      showAlert(e.message || "Failed to update status", "error");
    }
  };

  const handleAddLiveClass = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      const res = await fetch("/api/live-classes", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(newLiveClass),
      });
      if (!res.ok) throw new Error("Failed to add live class");
      showAlert("Live class added successfully", "success");
      setNewLiveClass({ title: "", zoom_link: "", batch_id: "", course_id: "", zoom_id: "", zoom_password: "", status: "scheduled", is_jitsi: false, program_id: "" });
    } catch (e: any) {
      showAlert(e.message || "Failed to add live class", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteLiveClass = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete live classs", "error");
      return;
    }
    if (await showConfirm("Are you sure you want to delete this live class?")) {
      try {
        await deleteDoc(doc(db, "live_classes", id));
        showAlert("Live class deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete live class", "error");
      }
    }
  };

  const handleUpdateStudentStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/students/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed to update student status");
      showAlert("Status updated successfully", "success");
    } catch (e: any) {
      showAlert(e.message || "Failed to update student status", "error");
    }
  };

  const handleCancelRegistration = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete students", "error");
      return;
    }
    if (await showConfirm("Are you sure you want to cancel this registration and delete the student?")) {
      try {
        // Optimistic UI updates
        setStudents((prev) => prev.filter((s) => s.id !== id));
        if (searchResult?.id === id) setSearchResult(null);
        if (selectedStudent?.id === id) setSelectedStudent(null);

        const res = await fetch(`/api/students/${id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error("Failed to delete student");
        showAlert("Registration cancelled successfully", "success");
      } catch (e: any) {
        console.error("Error cancelling registration:", e);
        showAlert(e.message || "Error cancelling registration", "error");
      }
    }
  };

  const handleAddCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      const res = await fetch("/api/courses", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(newCourse),
      });
      if (!res.ok) throw new Error("Failed to add course");
      showAlert("Course added successfully", "success");
      setNewCourse({ title: "", description: "", price: "", image_url: "", zoom_id: "", zoom_password: "", duration: "", lecture_count: "", program_id: "" });
    } catch (e: any) {
      showAlert(e.message || "Failed to add course", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleAddStudent = async (e: React.FormEvent, type: "online" | "offline") => {
    e.preventDefault();
    try {
      setLoading(true);
      const studentData: any = { ...newStudent, student_type: type };
      if (type === "online" && newStudent.course_id) {
        studentData.enrolled_courses = [newStudent.course_id];
      }
      const res = await fetch("/api/students", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(studentData),
      });
      if (!res.ok) {
        const err = await safeJson(res);
        throw new Error(err.error || "Failed to add student");
      }
      showAlert(`${type === "online" ? "Online" : "Offline"} student added successfully`, "success");
      setNewStudent({
          name: "",
          email: "",
          password: "",
          roll_number: "",
          phone: "",
          program_title: "",
          program_id: "",
          batch_id: "",
          course_id: "",
          course_title: "",
          address: "",
          admission_month: [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ][new Date().getMonth()],
          paid_amount: "",
          guardian_phone: "",
          batch_days: "",
          batch_time: "",
          admission_fee: "",
          current_class: "",
          class: "",
          monthly_fee: "",
          student_type: "offline",
          status: "approved",
          school_name: "",
          college_name: "",
          enrollment_id: "",
          profile_pic: "",
          blood_group: "",
        });
    } catch (e: any) {
      showAlert(e.message || "Failed to add student", "error");
    } finally {
      setLoading(false);
    }
  };

  const clearForm = (type: string) => {
    switch (type) {
      case "batch":
        setNewBatch({
          name: "",
          class: "",
          live_class_link: "",
          batch_days: "",
          batch_time: "",
          program_id: "",
        });
        break;
      case "student":
        setNewStudent({
          name: "",
          email: "",
          password: "",
          roll_number: "",
          phone: "",
          program_title: "",
          program_id: "",
          batch_id: "",
          course_id: "",
          course_title: "",
          address: "",
          admission_month: [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ][new Date().getMonth()],
          paid_amount: "",
          guardian_phone: "",
          batch_days: "",
          batch_time: "",
          admission_fee: "",
          current_class: "",
          class: "",
          monthly_fee: "",
          student_type: "offline",
          status: "approved",
          school_name: "",
          college_name: "",
          enrollment_id: "",
          profile_pic: "",
          blood_group: "",
        });
        break;
      case "notice":
        setNewNotice({
          title: "",
          content: "",
          batch_id: "",
          program_id: "",
          author: "",
          attachment_url: "",
          is_verified: true,
          target_audience: "all",
        });
        break;
      case "resource":
        setNewResource({
          title: "",
          type: "video",
          url: "",
          batch_id: "",
          program_id: "",
          description: "",
        });
        break;
      case "routine":
        setNewRoutine({
          batch_id: "",
          program_id: "",
          course_id: "",
          image_url: "",
          content: "",
        });
        break;
      case "gallery":
        setNewImage({ image_url: "", caption: "", category: "General" });
        break;
      case "review":
        setNewReview({
          student_name: "",
          student_image: "",
          comment: "",
          rating: 5,
          batch: "",
        });
        break;
      case "web_recorded":
        setNewWebRecordedClass({
          title: "",
          url: "",
          description: "",
          course_id: "",
          program_id: "",
          batch_id: "",
        });
        break;
      case "web_schedule":
        setNewWebClassSchedule({ title: "", image_url: "", program_id: "", batch_id: "" });
        break;
      case "study_materials":
        setNewStudyMaterial({
          student_id: "",
          title: "",
          url: "",
          type: "pdf",
          batch_id: "",
          course_id: "",
          program_id: "",
        });
        break;
      case "moderators":
        setNewModerator({ name: "", email: "", password: "" });
        break;
      case "program":
        setNewProgram({
          title: "",
          description: "",
          features: "",
          target_audience: "",
          admission_fee: "",
          monthly_fee: "",
          image_url: "",
        });
        break;
      case "course":
        setNewCourse({
          title: "",
          description: "",
          price: "",
          image_url: "",
          zoom_id: "",
          zoom_password: "",
          duration: "",
          lecture_count: "",
          program_id: "",
        });
        break;
      case "chapter":
        setNewChapter({
          batch_id: "",
          program_id: "",
          course_id: "",
          title: "",
          content: "",
          status: "active",
          description: "",
        });
        break;
      case "exam":
        setNewExam({
          batch_id: "",
          program_id: "",
          exam_name: "",
          exam_date: "",
          category: "",
          question_pdf: "",
          answer_pdf: "",
          total_marks: "100"
        });
        break;
      case "attendance":
        setAttendanceSearch((prev) => ({ ...prev, roll_number: "" }));
        setAttendanceStudent(null);
        setTimeout(() => {
          const el = document.getElementById("attendance_roll_input");
          if (el) {
            el.focus();
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 50);
        break;
      case "payment":
        setPaymentSearch((prev) => ({ ...prev, roll_number: "" }));
        setPaymentStudent(null);
        setPaymentData({
          amount: "",
          date: format(new Date(), "yyyy-MM-dd"),
          type: "monthly",
          month: "",
          year: new Date().getFullYear().toString(),
        });
        setTimeout(() => {
          const el = document.getElementById("payment_roll_input");
          if (el) {
            el.focus();
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 50);
        break;
      case "result":
        setResultSearch({ batch_id: "", program_id: "", roll_number: "" });
        setResultStudent(null);
        setNewResult({
          exam_id: "",
          correct_answers: "",
          wrong_answers: "",
          highest_marks: "",
          negative_marks: "",
          marking_mode: false,
          questions: [],
        });
        break;
      case "search":
        setSearchQuery({
          class: "",
          batch_id: "",
          program_id: "",
          roll_number: "",
        });
        setSearchResult(null);
        break;
    }
  };

  return (
    <>
      <div className="flex h-[100dvh] bg-slate-50 overflow-hidden relative">
        {/* Mobile Sidebar Overlay */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-slate-900/50 z-20 lg:hidden"
            />
          )}
        </AnimatePresence>

        {/* Sidebar */}
        <div
          className={`fixed lg:static inset-y-0 left-0 w-64 bg-white border-r border-slate-200 text-slate-900 flex flex-col h-full shadow-xl z-30 transform transition-transform duration-300 lg:translate-x-0 ${isSidebarOpen ? "translate-x-0" : "-translate-x-full"}`}
        >
          <div className="p-6 border-b border-slate-100 bg-orange-50/30 space-y-4 flex-shrink-0">
            <div className="flex justify-between items-center">
              <Link
                to="/"
                className="flex items-center gap-2 text-slate-500 hover:text-orange-600 transition-colors text-sm font-medium"
              >
                <ArrowLeft className="h-4 w-4" /> Go to Website
              </Link>
              <button
                onClick={() => setIsSidebarOpen(false)}
                className="lg:hidden text-slate-400 hover:text-slate-900"
              >
                <XCircle className="h-6 w-6" />
              </button>
            </div>
            <div className="flex items-center gap-2">
              <img
                src={
                  globalSettings.logo_url ||
                  "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
                }
                alt="Logo"
                className="h-10 w-10 rounded-full border-2 border-white shadow-lg shadow-orange-200"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
                }}
              />
              <div className="flex flex-col">
                <span className="font-black text-lg text-orange-600 leading-none tracking-tighter uppercase">
                  {globalSettings.site_name || "Admin Panel"}
                </span>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">
                  {user?.role === "moderator" ? "Moderator" : "Administrator"}
                </span>
              </div>
            </div>
          </div>
          <nav className="flex-1 px-4 py-6 space-y-8 overflow-y-auto touch-pan-y scrollbar-hide">
            {/* Management Group */}
            <div className="space-y-2">
              <h3 className="px-4 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4 flex items-center gap-2">
                <LayoutDashboard className="h-3 w-3" /> Management
              </h3>
              {[
                { id: "overview", icon: LayoutDashboard, label: "Overview" },
                { id: "degrees", icon: GraduationCap, label: "Degrees" },
                {
                  id: "financials",
                  icon: DollarSign,
                  label: "Financials",
                  hidden: user?.role !== "admin",
                },
                {
                  id: "moderators",
                  icon: Users,
                  label: "Moderators",
                  hidden: user?.role !== "admin",
                },
                {
                  id: "messages",
                  icon: MessageSquare,
                  label: "Contact Messages",
                },
                {
                  id: "website_settings",
                  icon: Settings,
                  label: "Website Settings",
                  hidden: user?.role !== "admin",
                },
                {
                  id: "system_config",
                  icon: Settings,
                  label: "System Configurations",
                  hidden: true // Hidden because user asked to remove system configs
                },
              ]
                .filter((item) => !item.hidden)
                .map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      if (activeTab === item.id) {
                        if (item.id === "overview") {
                          /* Handled by onSnapshot */
                        } else if (item.id === "financials") {
                          /* Handled by onSnapshot */
                        } else if (item.id === "website_settings") {
                          /* Handled by onSnapshot */
                        } else if (item.id === "moderators") { /* Handled by snapshot */ }
                        else if (item.id === "messages") fetchMessages();
                      }
                      setActiveTab(item.id);
                      setSelectedStudent(null);
                      setAttendanceStudent(null);
                      setPaymentStudent(null);
                      setResultStudent(null);
                      setSearchResult(null);
                      setIsSidebarOpen(false);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className={`flex items-center space-x-3 w-full px-4 py-2.5 rounded-xl transition-all duration-300 ${
                      activeTab === item.id
                        ? "bg-orange-600 text-white shadow-lg shadow-orange-900/20 translate-x-1"
                        : "text-slate-500 hover:bg-orange-50 hover:text-orange-600 hover:translate-x-1"
                    }`}
                  >
                    <item.icon
                      className={`h-5 w-5 ${activeTab === item.id ? "animate-pulse" : ""}`}
                    />
                    <span className="font-bold text-sm tracking-tight">
                      {item.label}
                    </span>
                  </button>
                ))}
            </div>

            {/* Student Management Group */}
            <div className="space-y-2">
              <h3 className="px-4 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4 flex items-center gap-2">
                <Users className="h-3 w-3" /> Student Management
              </h3>
              {[
                { id: "students", icon: Users, label: "Offline Students" },
                {
                  id: "online_students",
                  icon: Users,
                  label: "Online Students",
                },
                { id: "studentSearch", icon: Search, label: "Search Student" },
                { id: "sms_center", icon: MessageSquare, label: "SMS Center", hidden: user?.role !== "admin" },
                { id: "email_center", icon: Mail, label: "Email Center", hidden: user?.role !== "admin" },
                { id: "enrollments", icon: FileText, label: "Enrollments" },
                {
                  id: "attendance",
                  icon: CheckCircle,
                  label: "Class Attendance",
                },
                {
                  id: "exam_attendance",
                  icon: CheckCircle,
                  label: "Exam Attendance",
                },
                {
                  id: "attendance_report",
                  icon: FileText,
                  label: "Attendance Report",
                },
                { id: "results", icon: BarChart, label: "Results" },
                { id: "exam_history", icon: Archive, label: "Exam History" },
                { id: "batches", icon: Calendar, label: "Batches" },
                { id: "exams", icon: Calendar, label: "Exams" },
                { id: "programs", icon: Award, label: "Programs" },
                { id: "chapters", icon: BookOpen, label: "Chapters" },
                { id: "payments", icon: CreditCard, label: "New Payment" },
                {
                  id: "payments_history",
                  icon: FileText,
                  label: "Payment History",
                  hidden: user?.role !== "admin",
                },
              ]
                .filter((item) => !item.hidden)
                .map((item) => (
                  <SidebarItem
                    key={item.id}
                    item={item}
                    activeTab={activeTab}
                    onClick={(id: string) => {
                      setActiveTab(id);
                      setSelectedStudent(null);
                      setAttendanceStudent(null);
                      setPaymentStudent(null);
                      setResultStudent(null);
                      setSearchResult(null);
                      setIsSidebarOpen(false);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                  />
                ))}
            </div>

              <div className="space-y-2">
                <h3 className="px-4 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4 flex items-center gap-2">
                  <BookOpen className="h-3 w-3" /> Educational Content
                </h3>
                {[
                  { id: "live_classes", icon: Video, label: "Live Classes" },
                  { id: "courses", icon: Video, label: "Online Courses" },
                  { id: "notices", icon: Bell, label: "Notices" },
                  { id: "routines", icon: Calendar, label: "Class Routine" },
                  {
                    id: "video_classes",
                    icon: Youtube,
                    label: "Jaber Math Care Tube",
                  },
                  { id: "web_recorded", icon: PlayCircle, label: "Web Recorded" },
                  {
                    id: "student_recorded",
                    icon: PlayCircle,
                    label: "Student Recorded",
                  },
                  { id: "web_schedule", icon: Calendar, label: "Web Schedule" },
                  {
                    id: "study_materials",
                    icon: BookOpen,
                    label: "Study Materials",
                  },
                  { id: "gallery", icon: ImageIcon, label: "Gallery" },
                  { id: "reviews", icon: Award, label: "Student Testimonials" },
                  { id: "class_slides", icon: ImageIcon, label: "Class Slides" },
                ].map((item) => (
                  <SidebarItem
                    key={item.id}
                    item={item}
                    activeTab={activeTab}
                    onClick={(id: string) => {
                      setActiveTab(id);
                      setSelectedStudent(null);
                      setAttendanceStudent(null);
                      setPaymentStudent(null);
                      setResultStudent(null);
                      setSearchResult(null);
                      setIsSidebarOpen(false);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                  />
                ))}
              </div>

            {/* System Group */}
            <div className="space-y-2">
              <h3 className="px-4 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4">
                System
              </h3>
              {[{ id: "profile", icon: User, label: "Profile Settings" }].map(
                (item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setSelectedStudent(null);
                      setAttendanceStudent(null);
                      setPaymentStudent(null);
                      setResultStudent(null);
                      setSearchResult(null);
                      setIsSidebarOpen(false);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className={`flex items-center space-x-3 w-full px-4 py-2.5 rounded-xl transition-all duration-300 ${
                      activeTab === item.id
                        ? "bg-orange-600 text-white shadow-lg shadow-orange-900/20 translate-x-1"
                        : "text-slate-500 hover:bg-orange-50 hover:text-orange-600 hover:translate-x-1"
                    }`}
                  >
                    <item.icon
                      className={`h-5 w-5 ${activeTab === item.id ? "animate-pulse" : ""}`}
                    />
                    <span className="font-bold text-sm tracking-tight">
                      {item.label}
                    </span>
                  </button>
                ),
              )}
            </div>
          </nav>
          <div className="p-4 border-t border-slate-100">
            <button
              onClick={logout}
              className="flex items-center space-x-3 w-full px-4 py-3 rounded-lg text-slate-500 hover:bg-red-50 hover:text-red-600 transition-colors"
            >
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </button>
            <div className="mt-4 text-center text-xs text-slate-500 opacity-75">
              Developed By{" "}
              <a
                href="#"
                className="hover:text-slate-300 underline decoration-slate-600 underline-offset-2 transition-all"
              >
                Mohammad Jaber Bin Razzak
              </a>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Mobile Header */}
          <header className="lg:hidden bg-white border-b border-slate-200 h-16 px-3 flex justify-between items-center shadow-sm z-20">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              <Menu className="h-6 w-6" />
            </button>
            <div className="w-10"></div>
          </header>

          <div className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 bg-slate-50 scrollbar-hide w-full max-w-full overflow-x-hidden">
            <style>{`
              .scrollbar-hide::-webkit-scrollbar {
                  display: none;
              }
              .scrollbar-hide {
                  -ms-overflow-style: none;
                  scrollbar-width: none;
              }
              .input-field {
                @apply w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all;
              }
              .btn-primary {
                @apply px-6 py-2 bg-orange-600 text-white rounded-xl font-bold hover:bg-orange-700 transition-all active:scale-95 disabled:opacity-50;
              }
              .btn-secondary {
                @apply px-6 py-2 bg-slate-200 text-slate-700 rounded-xl font-bold hover:bg-slate-300 transition-all active:scale-95;
              }
            `}</style>
            {/* Overview Tab */}
            {activeTab === "messages" && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                    <MessageSquare className="h-6 w-6 text-orange-600" />{" "}
                    Contact Messages
                  </h2>
                  <button
                    onClick={fetchMessages}
                    className="p-2 hover:bg-slate-100 rounded-xl transition-all"
                    title="Refresh Messages"
                  >
                    <RefreshCw
                      className={`h-5 w-5 text-slate-400 ${loading ? "animate-spin" : ""}`}
                    />
                  </button>
                </div>

                <div className="glass rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-orange-600 text-white">
                          <th className="p-4 font-bold uppercase text-xs tracking-widest">
                            Date
                          </th>
                          <th className="p-4 font-bold uppercase text-xs tracking-widest">
                            Sender
                          </th>
                          <th className="p-4 font-bold uppercase text-xs tracking-widest">
                            Contact Info
                          </th>
                          <th className="p-4 font-bold uppercase text-xs tracking-widest">
                            Message
                          </th>
                          <th className="p-4 font-bold uppercase text-xs tracking-widest">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/20">
                        {messages.length === 0 ? (
                          <tr>
                            <td
                              colSpan={5}
                              className="p-12 text-center text-slate-500 font-medium"
                            >
                              No messages found.
                            </td>
                          </tr>
                        ) : (
                          messages
                            .sort(
                              (a, b) =>
                                new Date(b.created_at || 0).getTime() -
                                new Date(a.created_at || 0).getTime(),
                            )
                            .map((msg) => (
                              <tr
                                key={msg.id}
                                className={`hover:bg-white/40 transition-colors ${!msg.is_read ? "bg-orange-50/30" : ""}`}
                              >
                                <td className="p-4 text-xs font-medium text-slate-500">
                                  {msg.created_at
                                    ? format(
                                        new Date(msg.created_at),
                                        "MMM dd, yyyy HH:mm",
                                      )
                                    : "N/A"}
                                </td>
                                <td className="p-4">
                                  <div className="font-bold text-slate-900">
                                    {msg.name}
                                  </div>
                                  <div className="text-[10px] text-slate-500 uppercase tracking-wider">
                                    {msg.current_class}
                                  </div>
                                </td>
                                <td className="p-4">
                                  <div className="text-sm font-medium text-slate-700">
                                    {msg.email}
                                  </div>
                                  <div className="text-sm text-slate-500">
                                    {msg.phone}
                                  </div>
                                </td>
                                <td className="p-4">
                                  <div className="text-xs font-bold text-orange-600 mb-1 uppercase tracking-tighter">
                                    {msg.subject}
                                  </div>
                                  <div className="text-sm text-slate-600 line-clamp-2 max-w-xs">
                                    {msg.message}
                                  </div>
                                </td>
                                <td className="p-4">
                                  <div className="flex items-center gap-2">
                                    <button
                                      onClick={async () => {
                                        await showAlert(
                                          msg.message,
                                          msg.subject || "Message Content",
                                        );
                                        if (!msg.is_read) {
                                          try {
                                            await deleteDoc(doc(db, "messages", msg.id));
                                            fetchMessages();
                                          } catch (e) {
                                            console.error(e);
                                          }
                                        }
                                      }}
                                      className="p-2 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-100 transition-all"
                                      title="View Full Message"
                                    >
                                      <Eye className="h-4 w-4" />
                                    </button>
                                    <button
                                      onClick={async () => {
                                        if (
                                          await showConfirm(
                                            "Delete this message?",
                                          )
                                        ) {
                                          try {
                                            await deleteDoc(doc(db, "messages", msg.id));
                                            fetchMessages();
                                          } catch (e) {
                                            console.error(e);
                                          }
                                        }
                                      }}
                                      className="p-2 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-all"
                                      title="Delete Message"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "overview" && (
              <div className="space-y-6 w-full">
                {authLoading ? (
                  <OverviewSkeleton />
                ) : (
                  <>
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                      <h2 className="text-2xl md:text-3xl font-bold text-slate-800 flex items-center gap-3">
                        <LayoutDashboard className="h-6 w-6 md:h-8 md:w-8 text-orange-600" />{" "}
                        Dashboard Overview
                      </h2>
                      <div className="flex items-center gap-4">
                        <div className="text-sm text-slate-500 font-medium hidden md:block">
                          {new Date().toLocaleDateString("en-US", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </div>
                        <button
                          onClick={() => window.location.reload()}
                          className="p-3 bg-white/40 backdrop-blur-md rounded-2xl border border-white/60 hover:bg-orange-600 hover:text-white transition-all shadow-xl group"
                          title="Refresh All Data"
                        >
                          <RefreshCw className="h-4 w-4 group-hover:rotate-180 transition-transform duration-700" />
                        </button>
                      </div>
                    </div>

                    {/* Stats Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                      {[
                        {
                          label: "Total Revenue",
                          value: `৳${dashboardStats.totalRev.toLocaleString()}`,
                          icon: DollarSign,
                          color: "bg-emerald-500",
                          trend: "+12%",
                          type: "payments",
                        },
                        {
                          label: "Offline Students",
                          value: dashboardStats.offlineCount,
                          icon: Users,
                          color: "bg-orange-500",
                          trend: "+5%",
                          type: "offline_students",
                        },
                        {
                          label: "Online Students",
                          value: dashboardStats.onlineCount,
                          icon: Users,
                          color: "bg-blue-500",
                          trend: "+5%",
                          type: "online_students",
                        },
                        {
                          label: "Active Batches",
                          value: batches.length,
                          icon: Calendar,
                          color: "bg-orange-500",
                          trend: "Stable",
                          type: "batches",
                        },
                        {
                          label: "Pending Apps",
                          value: dashboardStats.pendingEnrollCount,
                          icon: UserPlus,
                          color: "bg-purple-500",
                          trend: "Action Needed",
                          type: "enrollments",
                        },
                      ].map((stat, i) => (
                        <StatCard key={i} stat={stat} onReset={handleResetData} />
                      ))}
                    </div>
                    
                    {/* Quick Access Tools */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 relative z-10 w-full mb-2">
                      {[
                        { label: "SMS Center", icon: MessageSquare, tab: "sms_center", color: "text-orange-600 bg-orange-50", border: "border-orange-100 border hover:border-orange-300 hover:shadow-orange-200" },
                        { label: "Email Broadcast", icon: Mail, tab: "email_center", color: "text-blue-600 bg-blue-50", border: "border-blue-100 border hover:border-blue-300 hover:shadow-blue-200" },
                        { label: "Search Student", icon: Search, tab: "studentSearch", color: "text-purple-600 bg-purple-50", border: "border-purple-100 border hover:border-purple-300 hover:shadow-purple-200" },
                        { label: "Website Settings", icon: Settings, tab: "website_settings", color: "text-emerald-600 bg-emerald-50", border: "border-emerald-100 border hover:border-emerald-300 hover:shadow-emerald-200" },
                      ].map((tool, i) => (
                        <button 
                          key={i} 
                          onClick={() => setActiveTab(tool.tab)}
                          className={`flex flex-col items-center justify-center p-6 rounded-[2.5rem] ${tool.color} ${tool.border} transition-all active:scale-95 group shadow-sm hover:shadow-xl`}
                        >
                          <tool.icon className="h-8 w-8 mb-3 group-hover:scale-110 transition-transform" />
                          <span className="text-xs font-black uppercase tracking-widest text-slate-700 text-center">{tool.label}</span>
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      {/* Revenue Chart */}
                      <div className="glass p-4 md:p-8 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                        <h3 className="text-lg md:text-xl font-black text-slate-900 mb-8 flex items-center gap-2 relative z-10">
                          <TrendingUp className="h-5 w-5 md:h-6 md:w-6 text-orange-600" />{" "}
                          Revenue Growth
                        </h3>
                        <div className="h-80 w-full relative z-10">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart
                              data={allPayments.slice(-10).map((p) => ({
                                name: p.date,
                                amount: p.amount,
                              }))}
                            >
                              <CartesianGrid
                                strokeDasharray="3 3"
                                vertical={false}
                                stroke="#f1f5f9"
                              />
                              <XAxis
                                dataKey="name"
                                axisLine={false}
                                tickLine={false}
                                tick={{ fill: "#64748b", fontSize: 12 }}
                              />
                              <YAxis
                                axisLine={false}
                                tickLine={false}
                                tick={{ fill: "#64748b", fontSize: 12 }}
                              />
                              <Tooltip
                                contentStyle={{
                                  backgroundColor: "#fff",
                                  borderRadius: "12px",
                                  border: "none",
                                  boxShadow:
                                    "0 10px 15px -3px rgb(0 0 0 / 0.1)",
                                }}
                              />
                              <Line
                                type="monotone"
                                dataKey="amount"
                                stroke="#f97316"
                                strokeWidth={3}
                                dot={{ r: 4, fill: "#f97316" }}
                                activeDot={{ r: 6 }}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Student Type Ratio - Pie Chart */}
                      <div className="glass p-4 md:p-8 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                        <h3 className="text-lg md:text-xl font-black text-slate-900 mb-8 flex items-center gap-2 relative z-10">
                          <Activity className="h-5 w-5 md:h-6 md:w-6 text-blue-600" />{" "}
                          Student Base Ratio
                        </h3>
                        <div className="h-80 w-full relative z-10">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={[
                                  { name: 'Offline Students', value: students.filter(s => s.student_type !== 'online').length },
                                  { name: 'Online Enrollments', value: students.filter(s => s.student_type === 'online').length }
                                ]}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={100}
                                paddingAngle={5}
                                dataKey="value"
                              >
                                {[
                                  { name: 'Offline Students', value: students.filter(s => s.student_type !== 'online').length },
                                  { name: 'Online Enrollments', value: students.filter(s => s.student_type === 'online').length }
                                ].map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={['#3b82f6', '#f97316'][index % 2]} />
                                ))}
                              </Pie>
                              <Tooltip 
                                contentStyle={{
                                  backgroundColor: "#fff",
                                  borderRadius: "12px",
                                  border: "none",
                                  boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1)",
                                }}
                              />
                              <Legend verticalAlign="bottom" height={36} iconType="circle" />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Student Distribution */}
                      <div className="glass p-4 md:p-8 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                        <h3 className="text-lg md:text-xl font-black text-slate-900 mb-8 flex items-center gap-2 relative z-10">
                          <Users className="h-5 w-5 md:h-6 md:w-6 text-orange-600" />{" "}
                          Student Distribution
                        </h3>
                        <div className="h-80 w-full relative z-10">
                          <ResponsiveContainer width="100%" height="100%">
                            <ReBarChart data={chartData}>
                              <CartesianGrid
                                strokeDasharray="3 3"
                                vertical={false}
                                stroke="#f1f5f9"
                              />
                              <XAxis
                                dataKey="name"
                                axisLine={false}
                                tickLine={false}
                                tick={{ fill: "#64748b", fontSize: 12 }}
                              />
                              <YAxis
                                axisLine={false}
                                tickLine={false}
                                tick={{ fill: "#64748b", fontSize: 12 }}
                              />
                              <Tooltip
                                contentStyle={{
                                  backgroundColor: "#fff",
                                  borderRadius: "12px",
                                  border: "none",
                                  boxShadow:
                                    "0 10px 15px -3px rgb(0 0 0 / 0.1)",
                                }}
                              />
                              <Bar
                                dataKey="students"
                                fill="#f97316"
                                radius={[4, 4, 0, 0]}
                              />
                            </ReBarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>

                    {/* Recent Activity */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="glass p-4 md:p-8 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                        <h3 className="text-lg md:text-xl font-black text-slate-900 mb-8 relative z-10">
                          Recent Enrollments
                        </h3>
                        <div className="overflow-x-auto relative z-10">
                          <table className="w-full">
                            <thead>
                              <tr className="text-left border-b border-slate-100">
                                <th className="pb-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Student
                                </th>
                                <th className="pb-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Program
                                </th>
                                <th className="pb-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Date
                                </th>
                                <th className="pb-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Status
                                </th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                              {[...enrollments]
                                .sort(
                                  (a, b) =>
                                    new Date(b.created_at || 0).getTime() -
                                    new Date(a.created_at || 0).getTime(),
                                )
                                .slice(0, 3)
                                .map((en, i) => (
                                  <tr
                                    key={i}
                                    className="hover:bg-orange-50/50 transition-colors group"
                                  >
                                    <td className="py-4">
                                      <div className="font-bold text-slate-800 group-hover:text-orange-600 transition-colors">
                                        {en.name}
                                      </div>
                                      <div className="text-xs text-slate-500">
                                        {en.phone}
                                      </div>
                                    </td>
                                    <td className="py-4 text-sm text-slate-600 font-medium">
                                      {en.program_title}
                                    </td>
                                    <td className="py-4 text-sm text-slate-600">
                                      {new Date(
                                        en.created_at,
                                      ).toLocaleDateString()}
                                    </td>
                                    <td className="py-4">
                                      <span
                                        className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                                          en.status === "approved"
                                            ? "bg-emerald-100 text-emerald-700"
                                            : en.status === "rejected"
                                              ? "bg-orange-100 text-orange-700"
                                              : "bg-orange-100 text-orange-700"
                                        }`}
                                      >
                                        {en.status}
                                      </span>
                                    </td>
                                  </tr>
                                ))}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div className="glass p-4 md:p-8 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                        <h3 className="text-lg md:text-xl font-black text-slate-900 mb-8 relative z-10">
                          Recent Offline Students
                        </h3>
                        <div className="overflow-x-auto relative z-10">
                          <table className="w-full">
                            <thead>
                              <tr className="text-left border-b border-slate-100">
                                <th className="pb-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Student
                                </th>
                                <th className="pb-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Batch
                                </th>
                                <th className="pb-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Roll
                                </th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                              {[...students]
                                .filter(
                                  (s) =>
                                    s.student_type === "offline" &&
                                    s.status === "approved",
                                )
                                .sort(
                                  (a, b) =>
                                    new Date(b.admission_date || 0).getTime() -
                                    new Date(a.admission_date || 0).getTime(),
                                )
                                .slice(0, 3)
                                .map((s, i) => (
                                  <tr
                                    key={i}
                                    className="hover:bg-orange-50/50 transition-colors group"
                                  >
                                    <td className="py-4">
                                      <div className="font-bold text-slate-800 group-hover:text-orange-600 transition-colors">
                                        {s.name}
                                      </div>
                                      <div className="text-xs text-slate-500">
                                        {s.phone}
                                      </div>
                                    </td>
                                    <td className="py-4 text-sm text-slate-600 font-medium">
                                      {s.batch_name}
                                    </td>
                                    <td className="py-4 text-sm text-slate-600 font-mono">
                                      {s.roll_number}
                                    </td>
                                  </tr>
                                ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>

                    {/* Bento Admin Features & Feedback Stats Row */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
                      {/* Quick Management Shortcuts */}
                      <div className="glass p-6 md:p-8 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden lg:col-span-2">
                        <div className="absolute top-0 right-0 w-48 h-48 bg-orange-600/5 rounded-full blur-2xl -mr-24 -mt-24"></div>
                        <h3 className="text-lg md:text-xl font-black text-slate-900 mb-6 relative z-10 flex items-center gap-2">
                          <Zap className="h-5 w-5 text-orange-600" />
                          Bento Admin Quick Panel
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 relative z-10">
                          {[
                            { label: "Approve Students", tab: "enrollments", desc: "Process pending applications", color: "from-purple-500/10 to-purple-600/10 text-purple-700 hover:from-purple-500 hover:to-purple-600 hover:text-white" },
                            { label: "Post New Notice", tab: "notices", desc: "Share announcements", color: "from-orange-500/10 to-orange-600/10 text-orange-700 hover:from-orange-500 hover:to-orange-600 hover:text-white" },
                            { label: "Manage Batches", tab: "batches", desc: "Organize student batches", color: "from-blue-500/10 to-blue-600/10 text-blue-700 hover:from-blue-500 hover:to-blue-600 hover:text-white" },
                            { label: "Collect Fee / Payments", tab: "payments", desc: "Track tuition transactions", color: "from-emerald-500/10 to-emerald-600/10 text-emerald-700 hover:from-emerald-500 hover:to-emerald-600 hover:text-white" },
                            { label: "Add Class Slides", tab: "class_slides", desc: "Upload presentations", color: "from-rose-500/10 to-rose-600/10 text-rose-700 hover:from-rose-500 hover:to-rose-600 hover:text-white" },
                            { label: "Settings Panel", tab: "settings", desc: "Configure portal options", color: "from-slate-500/10 to-slate-600/10 text-slate-700 hover:from-slate-500 hover:to-slate-600 hover:text-white" },
                          ].map((act, i) => (
                            <button
                              key={i}
                              onClick={() => {
                                setActiveTab(act.tab);
                                window.scrollTo(0, 0);
                              }}
                              className={`p-4 rounded-2xl border border-transparent hover:border-white transition-all duration-300 text-left cursor-pointer hover:shadow-lg flex flex-col justify-between bg-gradient-to-br ${act.color} group`}
                            >
                              <span className="font-extrabold text-sm group-hover:underline">{act.label}</span>
                              <span className="text-[10px] font-medium opacity-80 mt-1 line-clamp-1">{act.desc}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* General Feedback & Reviews Status */}
                      <div className="glass p-6 md:p-8 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden flex flex-col justify-between">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl -mr-16 -mt-16"></div>
                        <div>
                          <h3 className="text-lg md:text-xl font-black text-slate-900 mb-6 relative z-10 flex items-center gap-2">
                            <MessageSquare className="h-5 w-5 text-blue-600" />
                            User Reviews & Messages
                          </h3>
                          <div className="space-y-4 relative z-10">
                            <div className="flex items-center justify-between p-3 bg-white/40 rounded-2xl border border-white/50">
                              <span className="text-xs font-bold text-slate-600">Total Approved Reviews</span>
                              <span className="font-black text-orange-600 text-lg bg-orange-50 px-3 py-1 rounded-xl">
                                {reviews.filter(r => r.status === "approved").length}
                              </span>
                            </div>
                            <div className="flex items-center justify-between p-3 bg-white/40 rounded-2xl border border-white/50">
                              <span className="text-xs font-bold text-slate-600">Pending Reviews Approval</span>
                              <span className="font-black text-blue-600 text-lg bg-blue-50 px-3 py-1 rounded-xl animate-pulse">
                                {reviews.filter(r => r.status !== "approved").length}
                              </span>
                            </div>
                            <div className="flex items-center justify-between p-3 bg-white/40 rounded-2xl border border-white/50">
                              <span className="text-xs font-bold text-slate-600">Total Enquiries Received</span>
                              <span className="font-black text-emerald-600 text-lg bg-emerald-50 px-3 py-1 rounded-xl">
                                {messages.length}
                              </span>
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            setActiveTab("reviews");
                            window.scrollTo(0, 0);
                          }}
                          className="mt-6 w-full py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all hover:-translate-y-0.5"
                        >
                          Review Submissions
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Degrees Tab */}
            {activeTab === "degrees" && (
              <div className="space-y-6 md:space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <div className="flex justify-between items-center">
                  <div className="space-y-1">
                    <h2 className="text-2xl md:text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                      <GraduationCap className="h-8 w-8 md:h-10 md:w-10 text-orange-600" />
                      Academic <span className="text-orange-600">Degrees</span>
                    </h2>
                    <p className="text-slate-500 font-black uppercase tracking-widest text-[10px]">
                      Manage mentor qualifications for About page
                    </p>
                  </div>
                </div>

                <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl">
                  <h3 className="text-xl font-black text-slate-900 mb-8 flex items-center gap-3">
                    <Plus className="h-5 w-5 text-orange-600" /> Add New Degree
                  </h3>
                  <form
                    onSubmit={handleAddDegree}
                    className="grid grid-cols-1 md:grid-cols-2 gap-8"
                  >
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Degree Title
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., B.Sc in Engineering"
                        className="glass-input w-full"
                        value={newDegree.title}
                        onChange={(e) =>
                          setNewDegree((prev) => ({
                            ...prev,
                            title: e.target.value,
                          }))
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Description (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., Academic Qualification"
                        className="glass-input w-full"
                        value={newDegree.description}
                        onChange={(e) =>
                          setNewDegree((prev) => ({
                            ...prev,
                            description: e.target.value,
                          }))
                        }
                      />
                    </div>
                    <div className="md:col-span-2 flex justify-end">
                      <button
                        type="submit"
                        className="px-10 py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all active:scale-95 shadow-lg shadow-orange-200 flex items-center gap-2"
                      >
                        <Plus className="h-5 w-5" /> Add Degree
                      </button>
                    </div>
                  </form>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {degrees.map((deg) => (
                    <div
                      key={deg.id}
                      className="glass p-8 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl group hover:bg-white/40 transition-all"
                    >
                      <div className="flex justify-between items-start mb-6">
                        <div className="p-4 rounded-2xl bg-orange-100 text-orange-600">
                          <GraduationCap className="h-6 w-6" />
                        </div>
                        <button
                          onClick={() => handleDeleteDegree(deg.id)}
                          className="text-slate-400 hover:text-red-600 p-2 rounded-xl hover:bg-red-50 transition-all opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          {deg.description || "Academic Qualification"}
                        </p>
                        <h3 className="text-xl font-black text-slate-900 tracking-tight">
                          {deg.title}
                        </h3>
                      </div>
                    </div>
                  ))}
                  {degrees.length === 0 && (
                    <div className="md:col-span-3 p-20 text-center glass rounded-[2.5rem] border border-white text-slate-400 italic font-medium">
                      No degrees added yet.
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === "financials" && (
              <div className="space-y-6 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-bold text-slate-800 flex items-center gap-3">
                    <DollarSign className="h-8 w-8 text-orange-600" /> Financial
                    Overview
                  </h2>
                  <div className="flex gap-4">
                    <select
                      className="glass-select border-2 border-orange-100 w-48"
                      value={paymentMethodFilter}
                      onChange={(e) => setPaymentMethodFilter(e.target.value)}
                    >
                      <option value="">All Payment Methods</option>
                      <option value="Cash">Cash</option>
                      <option value="Bkash">Bkash</option>
                      <option value="Nagad">Nagad</option>
                      <option value="Rocket">Rocket</option>
                      <option value="Online">Online (Other)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="glass p-8 rounded-3xl shadow-xl border border-white/40 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full blur-2xl -mr-16 -mt-16 group-hover:bg-orange-500/10 transition-colors"></div>
                    <div className="flex items-center gap-6 relative z-10">
                      <div className="p-4 bg-emerald-100 rounded-2xl text-emerald-600 shadow-lg shadow-emerald-50">
                        <DollarSign className="h-8 w-8" />
                      </div>
                      <div>
                        <h3 className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">
                          Total Revenue
                        </h3>
                        <p className="text-2xl sm:text-3xl md:text-4xl font-black text-slate-900 break-all">
                          ৳{dashboardStats.totalRev.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="glass p-8 rounded-3xl shadow-xl border border-white/40 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full blur-2xl -mr-16 -mt-16 group-hover:bg-orange-500/10 transition-colors"></div>
                    <div className="flex items-center gap-6 relative z-10">
                      <div className="p-4 bg-blue-100 rounded-2xl text-blue-600 shadow-lg shadow-blue-50">
                        <CreditCard className="h-8 w-8" />
                      </div>
                      <div>
                        <h3 className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">
                          Total Payments
                        </h3>
                        <p className="text-4xl font-black text-slate-900">
                          {allPayments.length}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="glass rounded-3xl shadow-2xl border border-white/40 overflow-hidden relative">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                  <div className="p-8 border-b border-slate-100 relative z-10">
                    <h3 className="text-xl font-black text-slate-900">
                      Recent Transactions
                    </h3>
                  </div>
                  <div className="overflow-x-auto relative z-10">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50/50 border-b border-slate-100">
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Date
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Student Name
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Roll No
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Amount
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Method
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Transaction ID
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Month
                          </th>
                          <th className="p-6 font-black text-center text-slate-400 text-[10px] uppercase tracking-widest">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {allPayments
                          .filter(
                            (p) =>
                              !paymentMethodFilter ||
                              p.payment_method === paymentMethodFilter,
                          )
                          .slice(0, 50)
                          .map((payment, index) => (
                            <tr
                              key={index}
                              className="border-b border-slate-50 hover:bg-orange-50/50 transition-colors group"
                            >
                              <td className="p-6 text-slate-600 font-medium">
                                {payment.date?.toDate
                                  ? payment.date.toDate().toLocaleDateString()
                                  : payment.date || "N/A"}
                              </td>
                              <td className="p-6 font-bold text-slate-800 group-hover:text-orange-600 transition-colors">
                                {payment.student_name || payment.student_id}
                              </td>
                              <td className="p-6">
                                <span className="bg-orange-50 text-orange-600 px-3 py-1 rounded-lg font-mono font-bold border border-orange-100">
                                  {payment.roll_number || "-"}
                                </span>
                              </td>
                              <td className="p-6 font-black text-emerald-600 text-lg">
                                ৳{payment.amount}
                              </td>
                              <td className="p-6">
                                <span
                                  className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                                    payment.payment_method === "Cash"
                                      ? "bg-slate-100 text-slate-600"
                                      : "bg-orange-100 text-orange-600"
                                  }`}
                                >
                                  {payment.payment_method || "Cash"}
                                </span>
                              </td>
                              <td className="p-6 font-mono text-xs text-slate-500">
                                {payment.transaction_id || "-"}
                              </td>
                              <td className="p-6 text-slate-600 font-medium">
                                {payment.month || "N/A"}
                              </td>
                              <td className="p-6 text-center">
                                <button
                                  onClick={() =>
                                    handleDeletePayment(payment.id)
                                  }
                                  className="text-orange-500 hover:text-white p-3 rounded-2xl hover:bg-orange-600 transition-all shadow-sm hover:shadow-orange-200"
                                >
                                  <Trash2 className="h-5 w-5" />
                                </button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "attendance" && (
              <div id="attendance-section" className="space-y-6 w-full">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <h2 className="text-2xl md:text-3xl font-bold text-slate-800 flex items-center gap-3">
                      <ClipboardCheck className="h-8 w-8 text-orange-600" />{" "}
                      Mark Attendance (Roll)
                    </h2>
                    <button
                      onClick={() => setAttendanceLocked(!attendanceLocked)}
                      className={`p-2 rounded-xl ${attendanceLocked ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"}`}
                    >
                      {attendanceLocked ? (
                        <Lock className="h-5 w-5" />
                      ) : (
                        <Unlock className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => clearForm("attendance")}
                      className="text-slate-400 hover:text-slate-600 flex items-center gap-1 text-sm font-bold"
                    >
                      <XCircle className="h-4 w-4" /> Clear
                    </button>
                  </div>
                </div>

                <div className="glass p-8 md:p-10 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8 relative z-10">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        Program (Optional)
                      </label>
                      <select
                        className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                        value={attendanceSearch.program_id}
                        onChange={(e) =>
                          setAttendanceSearch((prev) => ({
                            ...prev,
                            program_id: e.target.value,
                          }))
                        }
                      >
                        <option value="">All Programs</option>
                        {programs.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.title}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-orange-600 uppercase ml-1 tracking-widest">
                        Select Batch
                      </label>
                      <select
                        className="glass-select w-full border-2 border-orange-200 focus:border-orange-500 disabled:opacity-50 disabled:cursor-not-allowed"
                        value={attendanceSearch.batch_id}
                        onChange={(e) =>
                          setAttendanceSearch((prev) => ({
                            ...prev,
                            batch_id: e.target.value,
                          }))
                        }
                      >
                        <option value="">Select Batch</option>
                        {getFilteredBatches(attendanceSearch.program_id).map(
                          (b) => (
                            <option key={b.id} value={b.id}>
                              {b.name}
                            </option>
                          ),
                        )}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        Phone Number or Roll
                      </label>
                      <input
                        type="text"
                        placeholder="Enter Phone Number or Roll"
                        className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                        value={attendanceSearch.roll_number}
                        onChange={(e) => {
                          setAttendanceSearch((prev) => ({
                            ...prev,
                            roll_number: e.target.value,
                          }));
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            searchAttendanceStudent();
                          }
                        }}
                      />
                    </div>
                    <div className="flex items-end gap-4">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          id="autoMark"
                          checked={autoMark}
                          onChange={(e) => setAutoMark(e.target.checked)}
                          className="w-5 h-5 rounded border-orange-300 text-orange-600 focus:ring-orange-500"
                        />
                        <label
                          htmlFor="autoMark"
                          className="text-xs font-black text-slate-600 uppercase tracking-widest"
                        >
                          Auto-mark Present
                        </label>
                      </div>
                      <button
                        id="search-student-btn"
                        onClick={() => searchAttendanceStudent()}
                        disabled={isAttendanceSearching}
                        className="bg-orange-600 text-white w-full h-[52px] rounded-2xl font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-lg shadow-orange-200 active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                        {isAttendanceSearching ? (
                          <>
                            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            Searching...
                          </>
                        ) : (
                          "Search Student"
                        )}
                      </button>
                    </div>
                  </div>

                  {attendanceStudent && (
                    <motion.div
                      key={attendanceStudent.id}
                      ref={attendanceCardRef}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="glass p-4 md:p-8 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl flex flex-col gap-6"
                    >
                      <div className="flex flex-col md:flex-row items-start gap-4 md:gap-8">
                        {/* Mobile Top Row: Photo, Name, Roll, Buttons */}
                        <div className="flex flex-row w-full md:w-auto items-center justify-between gap-4 md:hidden">
                          <div className="flex items-center gap-3">
                            <div className="w-16 h-16 flex-shrink-0 bg-orange-100 rounded-2xl flex items-center justify-center text-2xl font-bold text-orange-600 border-2 border-white shadow-md overflow-hidden">
                              {attendanceStudent.profile_pic ? (
                                <img
                                  src={attendanceStudent.profile_pic}
                                  alt={attendanceStudent.name}
                                  className="w-full h-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                attendanceStudent.name.charAt(0)
                              )}
                            </div>
                            <div className="flex flex-col">
                              <h3 className="text-lg font-bold text-slate-900 leading-tight">
                                {attendanceStudent.name}
                              </h3>
                              <p className="text-slate-500 text-xs">
                                Roll:{" "}
                                <span className="font-mono font-bold text-orange-600">
                                  {attendanceStudent.roll_number}
                                </span>
                              </p>
                            </div>
                          </div>

                          {/* Mobile Buttons */}
                          <div className="flex flex-col gap-2 shrink-0">
                            {(() => {
                              const todayRecord =
                                attendanceStudent.attendance?.find(
                                  (r: any) =>
                                    r.date ===
                                      format(new Date(), "yyyy-MM-dd") &&
                                    r.type !== "exam",
                                );
                              const isPresent =
                                todayRecord?.status === "present";
                              const isWrongBatch =
                                attendanceSearch.batch_id &&
                                String(attendanceStudent.batch_id) !==
                                  String(attendanceSearch.batch_id) &&
                                String(attendanceStudent.batch_id_2) !==
                                  String(attendanceSearch.batch_id);

                              return (
                                <div className="flex flex-col gap-1">
                                  {isWrongBatch && (
                                    <label className="flex items-center justify-center gap-1 p-1 bg-orange-50 text-orange-700 rounded-lg border border-orange-200 text-[10px] font-bold cursor-pointer mb-1">
                                      <input
                                        type="checkbox"
                                        checked={allowCrossBatch}
                                        onChange={(e) =>
                                          setAllowCrossBatch(e.target.checked)
                                        }
                                        className="rounded text-orange-600 focus:ring-orange-500 w-3 h-3"
                                      />
                                      Cross-Batch Attendance
                                    </label>
                                  )}
                                  <div id="attendance-buttons-container">
                                    <button
                                      disabled={
                                        isWrongBatch && !allowCrossBatch
                                      }
                                      onClick={() =>
                                        markSingleAttendance(
                                          isPresent ? "absent" : "present",
                                        )
                                      }
                                      className={`py-3 px-6 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all active:scale-95 shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:grayscale ${
                                        isPresent
                                          ? "bg-emerald-600 text-white shadow-emerald-500/20"
                                          : "bg-rose-600 text-white shadow-rose-500/20"
                                      }`}
                                    >
                                      {isPresent ? (
                                        <CheckCircle className="h-5 w-5" />
                                      ) : (
                                        <XCircle className="h-5 w-5" />
                                      )}
                                      {isPresent ? "Present" : "Absent"}
                                      {isWrongBatch && !allowCrossBatch && (
                                        <Lock className="h-3 w-3 ml-1" />
                                      )}
                                    </button>
                                  </div>
                                </div>
                              );
                            })()}
                          </div>
                        </div>

                        {/* Desktop Photo */}
                        <div className="w-32 h-32 flex-shrink-0 bg-orange-100 rounded-full hidden md:flex items-center justify-center text-4xl font-bold text-orange-600 border-4 border-white shadow-md overflow-hidden">
                          {attendanceStudent.profile_pic ? (
                            <img
                              src={attendanceStudent.profile_pic}
                              alt={attendanceStudent.name}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            attendanceStudent.name.charAt(0)
                          )}
                        </div>

                        <div className="flex-1 text-left space-y-4 w-full">
                          <div className="hidden md:block">
                            <h3 className="text-2xl md:text-3xl font-bold text-slate-900">
                              {attendanceStudent.name}
                            </h3>
                            <p className="text-slate-500 mt-1">
                              Roll:{" "}
                              <span className="font-mono font-bold text-orange-600 text-lg">
                                {attendanceStudent.roll_number}
                              </span>
                            </p>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-3 text-sm md:text-base">
                            <p className="text-slate-500">
                              Batch:{" "}
                              <span className="font-bold text-slate-700">
                                {
                                  batches.find(
                                    (b) => b.id == attendanceStudent.batch_id,
                                  )?.name
                                }
                              </span>
                            </p>
                            <p className="text-slate-500">
                              Class:{" "}
                              <span className="font-bold text-slate-700">
                                {attendanceStudent.current_class || "N/A"}
                              </span>
                            </p>
                            <p
                              className="text-slate-500 truncate"
                              title={attendanceStudent.phone}
                            >
                              Phone:{" "}
                              <span className="font-bold text-slate-700">
                                {attendanceStudent.phone || "N/A"}
                              </span>
                            </p>
                            <p
                              className="text-slate-500 truncate"
                              title={attendanceStudent.guardian_phone}
                            >
                              Guardian:{" "}
                              <span className="font-bold text-slate-700">
                                {attendanceStudent.guardian_phone || "N/A"}
                              </span>
                            </p>
                            <p
                              className="text-slate-500 truncate"
                              title={attendanceStudent.school_name}
                            >
                              School:{" "}
                              <span className="font-bold text-slate-700">
                                {attendanceStudent.school_name || "N/A"}
                              </span>
                            </p>
                          </div>

                          <div className="pt-4 border-t border-slate-100 flex flex-wrap justify-center md:justify-start gap-3">
                            {attendanceStudent.attendance?.find(
                              (r: any) =>
                                r.date === format(new Date(), "yyyy-MM-dd") &&
                                r.type !== "exam",
                            ) ? (
                              <div
                                className={`px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2 ${
                                  attendanceStudent.attendance.find(
                                    (r: any) =>
                                      r.date ===
                                        format(new Date(), "yyyy-MM-dd") &&
                                      r.type !== "exam",
                                  ).status === "present"
                                    ? "bg-emerald-100 text-emerald-700"
                                    : "bg-orange-100 text-orange-700"
                                }`}
                              >
                                <div
                                  className={`w-2 h-2 rounded-full ${attendanceStudent.attendance.find((r: any) => r.date === format(new Date(), "yyyy-MM-dd") && r.type !== "exam").status === "present" ? "bg-emerald-500" : "bg-orange-500"}`}
                                />
                                Today:{" "}
                                {attendanceStudent.attendance
                                  .find(
                                    (r: any) =>
                                      r.date ===
                                        format(new Date(), "yyyy-MM-dd") &&
                                      r.type !== "exam",
                                  )
                                  .status.toUpperCase()}
                                {attendanceStudent.attendance.find(
                                  (r: any) =>
                                    r.date ===
                                      format(new Date(), "yyyy-MM-dd") &&
                                    r.type !== "exam",
                                ).time && (
                                  <span className="opacity-60 ml-1">
                                    at{" "}
                                    {
                                      attendanceStudent.attendance.find(
                                        (r: any) =>
                                          r.date ===
                                            format(new Date(), "yyyy-MM-dd") &&
                                          r.type !== "exam",
                                      ).time
                                    }
                                  </span>
                                )}
                              </div>
                            ) : (
                              <div className="px-4 py-2 rounded-full bg-orange-100 text-orange-700 text-sm font-bold flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full bg-orange-500" />
                                Today: Not Marked
                              </div>
                            )}

                            {/* Exam Status for Today */}
                            {(() => {
                              const todayExam = exams.find(
                                (e) =>
                                  String(e.batch_id) ===
                                    String(attendanceStudent.batch_id) &&
                                  e.exam_date ===
                                    format(new Date(), "yyyy-MM-dd"),
                              );
                              if (!todayExam) return null;

                              const examRecord =
                                attendanceStudent.attendance?.find(
                                  (r: any) =>
                                    r.date ===
                                      format(new Date(), "yyyy-MM-dd") &&
                                    r.type === "exam" &&
                                    r.exam_id == todayExam.id,
                                );

                              const status = examRecord
                                ? examRecord.status
                                : "absent";

                              return (
                                <div
                                  className={`px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2 ${
                                    status === "present"
                                      ? "bg-emerald-100 text-emerald-700"
                                      : "bg-orange-100 text-orange-700"
                                  }`}
                                >
                                  <div
                                    className={`w-2 h-2 rounded-full ${status === "present" ? "bg-emerald-500" : "bg-orange-500"}`}
                                  />
                                  Exam ({todayExam.exam_name}):{" "}
                                  {status.toUpperCase()}
                                </div>
                              );
                            })()}

                            {(() => {
                              const unpaidM =
                                calculateUnpaidMonths(attendanceStudent);
                              if (unpaidM.length > 0) {
                                return (
                                  <div className="px-4 py-2 rounded-full bg-rose-100 text-rose-700 text-sm font-bold flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-rose-500" />
                                    Fee Due: {unpaidM.join(", ")}
                                  </div>
                                );
                              }
                              return null;
                            })()}
                          </div>
                        </div>

                        <div className="flex flex-col gap-4 w-full md:w-64 flex-shrink-0 order-1 md:order-none">
                          <div className="flex flex-col gap-3">
                            <div className="relative">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 mb-1 block">
                                Attendance Time
                              </label>
                              <input
                                type="time"
                                className="input-field w-full text-center font-bold text-lg bg-white border-2 border-slate-100 focus:border-orange-500"
                                value={attendanceTime}
                                onChange={(e) =>
                                  setAttendanceTime(e.target.value)
                                }
                              />
                            </div>

                            {(() => {
                              const todayRecord =
                                attendanceStudent.attendance?.find(
                                  (r: any) =>
                                    r.date ===
                                      format(new Date(), "yyyy-MM-dd") &&
                                    r.type !== "exam",
                                );
                              const status = todayRecord?.status || "absent";
                              const isPresent = status === "present";
                              const isWrongBatch =
                                attendanceSearch.batch_id &&
                                String(attendanceStudent.batch_id) !==
                                  String(attendanceSearch.batch_id) &&
                                String(attendanceStudent.batch_id_2) !==
                                  String(attendanceSearch.batch_id);

                              return (
                                <div className="space-y-4">
                                  <div className="hidden md:block">
                                    {isWrongBatch && (
                                      <label className="flex items-center justify-center gap-2 p-3 bg-orange-50 text-orange-700 rounded-2xl border border-orange-200 text-xs font-black uppercase tracking-widest cursor-pointer hover:bg-orange-100 transition-colors">
                                        <input
                                          type="checkbox"
                                          checked={allowCrossBatch}
                                          onChange={(e) =>
                                            setAllowCrossBatch(e.target.checked)
                                          }
                                          className="rounded text-orange-600 focus:ring-orange-500 h-4 w-4"
                                        />
                                        Allow Cross-Batch
                                      </label>
                                    )}
                                  </div>

                                  {/* Desktop View: Original Buttons */}
                                  <div className="hidden md:grid grid-cols-1 gap-3">
                                    <button
                                      disabled={
                                        isWrongBatch && !allowCrossBatch
                                      }
                                      onClick={() =>
                                        markSingleAttendance(
                                          isPresent ? "absent" : "present",
                                        )
                                      }
                                      className={`py-5 rounded-2xl font-black text-xl uppercase tracking-widest flex items-center justify-center gap-3 transition-all active:scale-95 shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:grayscale ${
                                        isPresent
                                          ? "bg-emerald-600 text-white shadow-emerald-200 hover:bg-emerald-700"
                                          : "bg-rose-600 text-white shadow-rose-200 hover:bg-rose-700"
                                      }`}
                                    >
                                      {isPresent ? (
                                        <CheckCircle className="h-6 w-6" />
                                      ) : (
                                        <XCircle className="h-6 w-6" />
                                      )}
                                      {isPresent ? "Present" : "Absent"}
                                      {isWrongBatch && !allowCrossBatch && (
                                        <Lock className="h-5 w-5 ml-1" />
                                      )}
                                    </button>

                                    <div className="text-center">
                                      <span
                                        className={`text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full ${
                                          isPresent
                                            ? "bg-emerald-100 text-emerald-700"
                                            : "bg-rose-100 text-rose-700"
                                        }`}
                                      >
                                        Current Status: {status.toUpperCase()}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              );
                            })()}
                          </div>
                        </div>
                      </div>

                      {/* Attendance marking is always enabled for admins */}
                    </motion.div>
                  )}
                </div>
              </div>
            )}

            {/* Exam Attendance Tab */}
            {activeTab === "exam_attendance" && (
              <div className="space-y-10 w-full animate-in fade-in slide-in-from-bottom-4 duration-700">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div className="relative">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                      <div className="p-3 rounded-2xl bg-emerald-500 text-white shadow-lg shadow-emerald-200">
                        <CheckCircle className="h-8 w-8" />
                      </div>
                      Exam Attendance
                    </h2>
                    <div className="absolute -bottom-2 left-16 w-24 h-1.5 bg-emerald-500 rounded-full"></div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="glass px-4 py-2 rounded-xl border border-white/40 shadow-sm">
                      <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest block mb-0.5">
                        Total Exams
                      </span>
                      <div className="text-lg font-black text-slate-900">
                        {exams.length}
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setExamAttendanceSearch({
                          batch_id: "",
                          program_id: "",
                          exam_id: "",
                          roll_number: "",
                        });
                        setExamAttendanceStudent(null);
                      }}
                      className="px-4 py-2 bg-white/60 backdrop-blur-md border border-white/60 text-slate-500 hover:text-orange-600 rounded-xl text-xs font-black uppercase tracking-widest transition-all hover:shadow-lg active:scale-95 flex items-center gap-2 whitespace-nowrap"
                    >
                      <XCircle className="h-4 w-4" /> Clear Search
                    </button>
                  </div>
                </div>

                <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-[100px] -mr-48 -mt-48 group-hover:bg-emerald-500/10 transition-colors duration-700"></div>

                  <div className="flex items-center gap-4 mb-10 relative z-10">
                    <div className="h-12 w-1.5 bg-emerald-500 rounded-full"></div>
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                      Search Student for Attendance
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 relative z-10">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-emerald-600 ml-4">
                        1. Select Exam
                      </label>
                      <select
                        className="glass-select border-2 border-emerald-100 focus:border-emerald-500"
                        value={examAttendanceSearch.exam_id}
                        onChange={(e) => {
                          const examId = e.target.value;
                          const exam = exams.find((ex) => ex.id == examId);
                          if (exam) {
                            setExamAttendanceSearch((prev) => ({
                              ...prev,
                              exam_id: examId,
                              batch_id: exam.batch_id?.toString() || "",
                              program_id: exam.program_id?.toString() || "",
                            }));
                          } else {
                            setExamAttendanceSearch((prev) => ({
                              ...prev,
                              exam_id: examId,
                            }));
                          }
                        }}
                      >
                        <option value="">Select Exam</option>
                        {exams
                          .sort(
                            (a, b) =>
                              new Date(b.exam_date || b.date).getTime() -
                              new Date(a.exam_date || a.date).getTime(),
                          )
                          .map((exam) => (
                            <option key={exam.id} value={exam.id}>
                              {exam.exam_name || exam.title} (
                              {exam.batch_name || "All Batches"})
                            </option>
                          ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                        2. Program
                      </label>
                      <select
                        className="glass-select bg-slate-50/50"
                        value={examAttendanceSearch.program_id}
                        onChange={(e) =>
                          setExamAttendanceSearch((prev) => ({
                            ...prev,
                            program_id: e.target.value,
                          }))
                        }
                      >
                        <option value="">All Programs</option>
                        {programs.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.title}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                        3. Batch
                      </label>
                      <select
                        className="glass-select bg-slate-50/50 disabled:opacity-50 disabled:cursor-not-allowed"
                        value={examAttendanceSearch.batch_id}
                        onChange={(e) =>
                          setExamAttendanceSearch((prev) => ({
                            ...prev,
                            batch_id: e.target.value,
                          }))
                        }
                        disabled={!examAttendanceSearch.program_id}
                      >
                        <option value="">
                          {examAttendanceSearch.program_id
                            ? "Select Batch"
                            : "Select Program First"}
                        </option>
                        {getFilteredBatches(
                          examAttendanceSearch.program_id,
                        ).map((b) => (
                          <option key={b.id} value={b.id}>
                            {b.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-emerald-600 ml-4">
                        4. Roll or Phone Number
                      </label>
                      <div className="relative">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-emerald-500 z-10" />
                        <input
                          type="text"
                          placeholder="Enter Roll or Phone"
                          className="glass-input pl-12 border-2 border-emerald-100 focus:border-emerald-500"
                          value={examAttendanceSearch.roll_number}
                          onChange={(e) => {
                            setExamAttendanceSearch((prev) => ({
                              ...prev,
                              roll_number: e.target.value,
                            }));
                          }}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              searchExamAttendanceStudent();
                            }
                          }}
                        />
                      </div>
                    </div>

                    <div className="flex items-end">
                      <button
                        onClick={() => searchExamAttendanceStudent()}
                        disabled={!examAttendanceSearch.exam_id}
                        className="glass-btn w-full h-[54px] bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200"
                      >
                        <Search className="h-5 w-5" /> Search
                      </button>
                    </div>
                  </div>
                </div>

                {examAttendanceStudent && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass p-4 md:p-8 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl flex flex-col gap-6"
                  >
                    <div className="flex flex-col md:flex-row items-start gap-4 md:gap-8">
                      {/* Mobile Top Row: Photo, Name, Roll, Buttons */}
                      <div className="flex flex-row w-full md:w-auto items-center justify-between gap-4 md:hidden">
                        <div className="flex items-center gap-3">
                          <div className="w-16 h-16 flex-shrink-0 bg-emerald-100 rounded-2xl flex items-center justify-center text-2xl font-bold text-emerald-600 border-2 border-white shadow-md overflow-hidden">
                            {examAttendanceStudent.profile_pic ? (
                              <img
                                src={examAttendanceStudent.profile_pic}
                                alt={examAttendanceStudent.name}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              examAttendanceStudent.name.charAt(0)
                            )}
                          </div>
                          <div className="flex flex-col">
                            <h3 className="text-lg font-bold text-slate-900 leading-tight">
                              {examAttendanceStudent.name}
                            </h3>
                            <p className="text-slate-500 text-xs">
                              Roll:{" "}
                              <span className="font-mono font-bold text-emerald-600">
                                {examAttendanceStudent.roll_number}
                              </span>
                            </p>
                          </div>
                        </div>

                        {/* Mobile Buttons */}
                        <div className="flex flex-col gap-2 shrink-0">
                          {(() => {
                            const todayRecord =
                              examAttendanceStudent.attendance?.find(
                                (r: any) =>
                                  r.date === format(new Date(), "yyyy-MM-dd") &&
                                  r.type === "exam" &&
                                  r.exam_id == examAttendanceSearch.exam_id,
                              );
                            const isPresent = todayRecord?.status === "present";
                            const isWrongBatch =
                              examAttendanceSearch.batch_id !== "all" &&
                              String(examAttendanceStudent.batch_id) !==
                                String(examAttendanceSearch.batch_id) &&
                              String(examAttendanceStudent.batch_id_2) !==
                                String(examAttendanceSearch.batch_id);

                            return (
                              <div className="flex flex-col gap-1">
                                {isWrongBatch && (
                                  <label className="flex items-center justify-center gap-1 p-1 bg-orange-50 text-orange-700 rounded-lg border border-orange-200 text-[10px] font-bold cursor-pointer mb-1">
                                    <input
                                      type="checkbox"
                                      checked={allowCrossBatch}
                                      onChange={(e) =>
                                        setAllowCrossBatch(e.target.checked)
                                      }
                                      className="rounded text-orange-600 focus:ring-orange-500 w-3 h-3"
                                    />
                                    Cross-Batch
                                  </label>
                                )}
                                <button
                                  onClick={() =>
                                    markSingleExamAttendance(
                                      isPresent ? "absent" : "present",
                                    )
                                  }
                                  disabled={isWrongBatch && !allowCrossBatch}
                                  className={`p-2 px-4 rounded-xl font-black text-xs flex items-center justify-center gap-1 transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:grayscale ${
                                    isPresent
                                      ? "bg-emerald-600 text-white shadow-lg shadow-emerald-500/20"
                                      : "bg-rose-600 text-white shadow-lg shadow-rose-500/20"
                                  }`}
                                >
                                  {isPresent ? (
                                    <CheckCircle className="h-4 w-4" />
                                  ) : (
                                    <XCircle className="h-4 w-4" />
                                  )}
                                  {isPresent ? "Present" : "Absent"}
                                  {isWrongBatch && !allowCrossBatch && (
                                    <Lock className="h-3 w-3 ml-1" />
                                  )}
                                </button>
                              </div>
                            );
                          })()}
                        </div>
                      </div>

                      {/* Desktop Photo */}
                      <div className="hidden md:flex relative group flex-shrink-0">
                        <div className="w-32 h-32 rounded-[2rem] bg-emerald-100 flex items-center justify-center text-5xl font-black text-emerald-600 border-4 border-white shadow-xl overflow-hidden group-hover:scale-105 transition-transform duration-500">
                          {examAttendanceStudent.profile_pic ? (
                            <img
                              src={examAttendanceStudent.profile_pic}
                              alt={examAttendanceStudent.name}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            examAttendanceStudent.name.charAt(0)
                          )}
                        </div>
                      </div>

                      {/* Details & Desktop Buttons */}
                      <div className="flex-1 flex flex-col md:flex-row gap-6 w-full">
                        <div className="flex-1 space-y-4">
                          <div className="hidden md:block">
                            <h3 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight mb-2">
                              {examAttendanceStudent.name}
                            </h3>
                            <div className="flex flex-wrap gap-2">
                              <span className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-black uppercase tracking-widest border border-emerald-100">
                                Roll: {examAttendanceStudent.roll_number}
                              </span>
                              <span className="px-3 py-1 bg-slate-50 text-slate-500 rounded-lg text-xs font-black uppercase tracking-widest border border-slate-100">
                                Class:{" "}
                                {examAttendanceStudent.current_class || "N/A"}
                              </span>
                              <span className="px-3 py-1 bg-slate-50 text-slate-500 rounded-lg text-xs font-black uppercase tracking-widest border border-slate-100">
                                Batch:{" "}
                                {batches.find(
                                  (b) => b.id == examAttendanceStudent.batch_id,
                                )?.name || "N/A"}
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div className="glass bg-white/40 p-3 rounded-2xl border border-white/60">
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                                Contact Phone
                              </p>
                              <p className="text-sm font-bold text-slate-800">
                                {examAttendanceStudent.phone || "N/A"}
                              </p>
                            </div>
                            <div className="glass bg-white/40 p-3 rounded-2xl border border-white/60">
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                                Guardian Phone
                              </p>
                              <p className="text-sm font-bold text-slate-800">
                                {examAttendanceStudent.guardian_phone || "N/A"}
                              </p>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2">
                            {/* Exam Status for Today */}
                            {(() => {
                              const todayExam = exams.find(
                                (e) =>
                                  String(e.batch_id) ===
                                    String(examAttendanceStudent.batch_id) &&
                                  e.exam_date ===
                                    format(new Date(), "yyyy-MM-dd"),
                              );
                              if (!todayExam) return null;

                              const examRecord =
                                examAttendanceStudent.attendance?.find(
                                  (r: any) =>
                                    r.date ===
                                      format(new Date(), "yyyy-MM-dd") &&
                                    r.type === "exam" &&
                                    r.exam_id == todayExam.id,
                                );

                              const status = examRecord
                                ? examRecord.status
                                : "absent";

                              return (
                                <div
                                  className={`px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2 ${
                                    status === "present"
                                      ? "bg-emerald-100 text-emerald-700"
                                      : "bg-orange-100 text-orange-700"
                                  }`}
                                >
                                  <div
                                    className={`w-2 h-2 rounded-full ${status === "present" ? "bg-emerald-500" : "bg-orange-500"}`}
                                  />
                                  Exam ({todayExam.exam_name}):{" "}
                                  {status.toUpperCase()}
                                </div>
                              );
                            })()}
                          </div>
                        </div>

                        <div className="hidden md:flex flex-col gap-4 w-full md:w-48 flex-shrink-0 order-1 md:order-none">
                          {(() => {
                            const todayRecord =
                              examAttendanceStudent.attendance?.find(
                                (r: any) =>
                                  r.date === format(new Date(), "yyyy-MM-dd") &&
                                  r.type === "exam" &&
                                  r.exam_id == examAttendanceSearch.exam_id,
                              );
                            const isPresent = todayRecord?.status === "present";
                            const isAbsent = todayRecord?.status === "absent";

                            const isWrongBatch =
                              examAttendanceSearch.batch_id !== "all" &&
                              String(examAttendanceStudent.batch_id) !==
                                String(examAttendanceSearch.batch_id) &&
                              String(examAttendanceStudent.batch_id_2) !==
                                String(examAttendanceSearch.batch_id);

                            return (
                              <div className="flex flex-col gap-2 w-full">
                                <div className="hidden md:block">
                                  {isWrongBatch && (
                                    <label className="flex items-center justify-center gap-2 p-2 bg-orange-50 text-orange-700 rounded-lg border border-orange-200 text-xs font-bold cursor-pointer mb-2">
                                      <input
                                        type="checkbox"
                                        checked={allowCrossBatch}
                                        onChange={(e) =>
                                          setAllowCrossBatch(e.target.checked)
                                        }
                                        className="rounded text-orange-600 focus:ring-orange-500"
                                      />
                                      Allow Cross-Batch
                                    </label>
                                  )}
                                </div>
                                <button
                                  disabled={isWrongBatch && !allowCrossBatch}
                                  onClick={() =>
                                    markSingleExamAttendance("present")
                                  }
                                  className={`py-4 rounded-xl font-black text-lg flex items-center justify-center gap-2 transition-all active:scale-95 w-full disabled:opacity-50 disabled:cursor-not-allowed disabled:grayscale ${
                                    isPresent
                                      ? "bg-emerald-700 text-white shadow-lg shadow-emerald-500/20 ring-2 ring-emerald-400 ring-offset-2"
                                      : "bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/20"
                                  }`}
                                >
                                  <CheckCircle className="h-5 w-5" /> Present
                                  {isWrongBatch && !allowCrossBatch && (
                                    <Lock className="h-4 w-4 ml-1" />
                                  )}
                                </button>
                                <button
                                  disabled={isWrongBatch && !allowCrossBatch}
                                  onClick={() =>
                                    markSingleExamAttendance("absent")
                                  }
                                  className={`py-4 rounded-xl font-black text-lg flex items-center justify-center gap-2 transition-all active:scale-95 w-full disabled:opacity-50 disabled:cursor-not-allowed disabled:grayscale ${
                                    isAbsent
                                      ? "bg-rose-700 text-white shadow-lg shadow-rose-500/20 ring-2 ring-rose-400 ring-offset-2"
                                      : "bg-rose-500 hover:bg-rose-600 text-white shadow-lg shadow-rose-500/20"
                                  }`}
                                >
                                  <XCircle className="h-5 w-5" /> Absent
                                  {isWrongBatch && !allowCrossBatch && (
                                    <Lock className="h-4 w-4 ml-1" />
                                  )}
                                </button>
                              </div>
                            );
                          })()}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>
            )}

            {activeTab === "attendance_report" && (
              <div className="space-y-8 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                    <ClipboardCheck className="h-8 w-8 text-orange-600" />{" "}
                    Attendance Report
                  </h2>
                </div>

                <div className="glass p-8 md:p-10 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                  <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-8 relative z-10">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        Program
                      </label>
                      <select
                        className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                        value={attendanceReportFilter.program_id}
                        onChange={(e) =>
                          setAttendanceReportFilter((prev) => ({
                            ...prev,
                            program_id: e.target.value,
                            batch_id: "",
                          }))
                        }
                      >
                        <option value="">Select Program</option>
                        {programs.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.title}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        Batch
                      </label>
                      <select
                        className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                        value={attendanceReportFilter.batch_id}
                        onChange={(e) =>
                          setAttendanceReportFilter((prev) => ({
                            ...prev,
                            batch_id: e.target.value,
                          }))
                        }
                      >
                        <option value="">All Batches</option>
                        {getFilteredBatches(
                          attendanceReportFilter.program_id,
                        ).map((b) => (
                          <option key={b.id} value={b.id}>
                            {b.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        Type
                      </label>
                      <select
                        className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                        value={attendanceReportFilter.type || ""}
                        onChange={(e) =>
                          setAttendanceReportFilter((prev) => ({
                            ...prev,
                            type: e.target.value,
                          }))
                        }
                      >
                        <option value="">All Types</option>
                        <option value="regular">Regular Class</option>
                        <option value="exam">Exam</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        Start Date
                      </label>
                      <input
                        type="date"
                        className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                        value={attendanceReportFilter.startDate}
                        onChange={(e) =>
                          setAttendanceReportFilter((prev) => ({
                            ...prev,
                            startDate: e.target.value,
                          }))
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        End Date
                      </label>
                      <input
                        type="date"
                        className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                        value={attendanceReportFilter.endDate}
                        onChange={(e) =>
                          setAttendanceReportFilter((prev) => ({
                            ...prev,
                            endDate: e.target.value,
                          }))
                        }
                      />
                    </div>
                    <div className="flex items-end gap-2">
                      <select
                        className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500 h-[52px]"
                        value={attendanceReportFilter.status || ""}
                        onChange={(e) =>
                          setAttendanceReportFilter({
                            ...attendanceReportFilter,
                            status: e.target.value,
                          })
                        }
                      >
                        <option value="">All Status</option>
                        <option value="present">Present</option>
                        <option value="absent">Absent</option>
                      </select>
                      <button
                        onClick={fetchAttendanceReport}
                        className="bg-orange-600 text-white w-full h-[52px] rounded-2xl font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-lg shadow-orange-200 active:scale-95 flex items-center justify-center gap-2"
                      >
                        <FileText className="h-5 w-5" /> Generate
                      </button>
                      <button
                        onClick={() => {
                          setAttendanceReportFilter({
                            program_id: "",
                            batch_id: "",
                            type: "",
                            status: "",
                            startDate: format(new Date(), "yyyy-MM-dd"),
                            endDate: format(new Date(), "yyyy-MM-dd"),
                          });
                          setAttendanceReport([]);
                        }}
                        className="bg-slate-200 text-slate-600 px-4 h-[52px] rounded-2xl font-black uppercase tracking-widest hover:bg-slate-300 transition-all shadow-lg shadow-slate-100 active:scale-95 flex items-center justify-center"
                        title="Reset Form and Clear List"
                      >
                        <RefreshCw className="h-5 w-5" />
                      </button>
                    </div>
                  </div>

                  {attendanceReport.length > 0 ? (
                    <div className="overflow-x-auto relative z-10">
                      {(() => {
                        const studentMap = new Map();
                        students.forEach((s) => {
                          if (s.id) studentMap.set(String(s.id), s);
                          if (s.roll_number)
                            studentMap.set(String(s.roll_number), s);
                        });
                        return (
                          <table className="w-full text-left border-collapse min-w-[800px]">
                            <thead>
                              <tr className="bg-slate-50/50 border-b border-slate-100">
                                <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Date
                                </th>
                                <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Type
                                </th>
                                <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Roll
                                </th>
                                <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Name
                                </th>
                                <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Batch
                                </th>
                                <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Status
                                </th>
                                <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                  Time
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              {attendanceReport.map((record, idx) => {
                                const student =
                                  studentMap.get(String(record.student_id)) ||
                                  studentMap.get(String(record.roll_number));
                                const phone =
                                  student?.guardian_phone || student?.phone;
                                return (
                                  <tr
                                    key={idx}
                                    className="border-b border-slate-50 hover:bg-orange-50/50 transition-colors group"
                                  >
                                    <td className="p-6 text-slate-600 font-medium">
                                      {record.date}
                                    </td>
                                    <td className="p-6">
                                      <span
                                        className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                                          record.type === "exam"
                                            ? "bg-purple-100 text-purple-700"
                                            : "bg-blue-100 text-blue-700"
                                        }`}
                                      >
                                        {record.type === "exam"
                                          ? "Exam"
                                          : "Class"}
                                      </span>
                                    </td>
                                    <td className="p-6">
                                      <span className="bg-orange-50 text-orange-600 px-3 py-1 rounded-lg font-mono font-bold border border-orange-100">
                                        {record.roll_number}
                                      </span>
                                    </td>
                                    <td className="p-6 transition-colors">
                                      <div className="font-bold text-slate-800 group-hover:text-orange-600 truncate">
                                        {student?.name || record.student_name || "Unknown"}
                                      </div>
                                      {phone ? (
                                        <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1 flex items-center gap-1">
                                          <span className="text-orange-500 text-xs">
                                            G:
                                          </span>{" "}
                                          {phone}
                                        </div>
                                      ) : null}
                                    </td>
                                    <td className="p-6 text-slate-600 font-medium">
                                      {record.batch_name}
                                    </td>
                                    <td className="p-6">
                                      <span
                                        className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                                          record.status === "present"
                                            ? "bg-emerald-100 text-emerald-700"
                                            : "bg-orange-100 text-orange-700"
                                        }`}
                                      >
                                        {record.status}
                                      </span>
                                    </td>
                                    <td className="p-6 text-slate-500 font-mono text-xs">
                                      {record.time || "-"}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        );
                      })()}
                    </div>
                  ) : (
                    <div className="text-center py-20 text-slate-400 relative z-10">
                      <FileText className="h-16 w-16 mx-auto mb-6 opacity-10" />
                      <p className="font-bold uppercase tracking-widest text-[10px]">
                        No records found
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Payments Tab */}
            {activeTab === "payments" && (
              <div className="space-y-8 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                    <CreditCard className="h-8 w-8 text-orange-600" /> Record
                    Payment
                  </h2>
                  <button
                    onClick={() => clearForm("payment")}
                    className="text-slate-400 hover:text-orange-600 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-colors"
                  >
                    <XCircle className="h-4 w-4" /> Clear
                  </button>
                </div>

                <div className="glass p-8 md:p-10 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 relative z-10">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        Program
                      </label>
                      <select
                        className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                        value={paymentSearch.program_id}
                        onChange={(e) =>
                          setPaymentSearch({
                            ...paymentSearch,
                            program_id: e.target.value,
                            batch_id: "",
                          })
                        }
                      >
                        <option value="">Select Program</option>
                        {programs.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.title}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        Batch
                      </label>
                      <select
                        className="glass-select w-full border-2 border-orange-100 focus:border-orange-500 disabled:opacity-50 disabled:cursor-not-allowed"
                        value={paymentSearch.batch_id}
                        onChange={(e) =>
                          setPaymentSearch({
                            ...paymentSearch,
                            batch_id: e.target.value,
                          })
                        }
                        disabled={!paymentSearch.program_id}
                      >
                        <option value="">
                          {paymentSearch.program_id
                            ? "Select Batch"
                            : "Select Program First"}
                        </option>
                        {getFilteredBatches(paymentSearch.program_id).map(
                          (b) => (
                            <option key={b.id} value={b.id}>
                              {b.name}
                            </option>
                          ),
                        )}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                        Phone Number
                      </label>
                      <div className="flex gap-4">
                        <DebouncedInput
                          id="payment_roll_input"
                          type="text"
                          placeholder="Enter Phone Number"
                          debounce={0}
                          className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                          value={paymentSearch.roll_number}
                          onChange={(value: string) => {
                            setPaymentSearch({
                              ...paymentSearch,
                              roll_number: value,
                            });
                          }}
                          onEnter={(val: string) => searchPaymentStudent(val)}
                        />
                        <button
                          onClick={() => searchPaymentStudent()}
                          className="bg-orange-600 text-white px-8 rounded-2xl font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-lg shadow-orange-200 active:scale-95"
                        >
                          Search
                        </button>
                      </div>
                    </div>
                  </div>

                  {paymentStudent && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-8 relative z-10"
                    >
                      <div className="glass p-8 rounded-3xl border border-white/40 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                        <div className="flex items-center gap-6">
                          <div className="w-20 h-20 bg-orange-100 rounded-2xl flex items-center justify-center text-2xl font-black text-orange-600 border-4 border-white shadow-lg overflow-hidden">
                            {paymentStudent.profile_pic ? (
                              <img
                                src={paymentStudent.profile_pic}
                                alt={paymentStudent.name}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              paymentStudent.name.charAt(0)
                            )}
                          </div>
                          <div>
                            <h3 className="text-2xl font-black text-slate-900">
                              {paymentStudent.name}
                            </h3>
                            <div className="flex flex-wrap items-center gap-3 mt-1">
                              <span className="bg-orange-50 text-orange-600 px-3 py-1 rounded-lg font-mono font-bold border border-orange-100">
                                Roll: {paymentStudent.roll_number}
                              </span>
                              <span className="text-slate-500 font-medium">
                                {paymentStudent.program_title}
                              </span>
                              <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">
                                | {paymentStudent.current_class || "N/A"}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right w-full md:w-auto">
                          <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">
                            Current Month Status
                          </div>
                          {paymentStudent.payments?.some(
                            (p: any) =>
                              p.type === "monthly" &&
                              p.month === format(new Date(), "MMMM"),
                          ) ? (
                            <div className="bg-emerald-50 text-emerald-600 px-4 py-2 rounded-xl font-black uppercase tracking-widest text-xs flex items-center gap-2 justify-center md:justify-end border border-emerald-100">
                              <CheckCircle className="h-4 w-4" /> Paid
                            </div>
                          ) : (
                            <div className="bg-orange-50 text-orange-600 px-4 py-2 rounded-xl font-black uppercase tracking-widest text-xs flex flex-col items-center md:items-end gap-1 border border-orange-100">
                              <span className="flex items-center gap-2">
                                <XCircle className="h-4 w-4" /> Unpaid
                              </span>
                              <span className="text-[10px] opacity-70">
                                Due: ৳{Number(paymentStudent.monthly_fee) || 0}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Student Registration Details */}
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="glass p-6 rounded-3xl border border-white/40 shadow-lg">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                            Registration Date
                          </p>
                          <p className="text-lg font-black text-slate-800">
                            {paymentStudent.date_of_admission ||
                              paymentStudent.created_at ||
                              "N/A"}
                          </p>
                        </div>
                        <div className="glass p-6 rounded-3xl border border-white/40 shadow-lg">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                            Added By
                          </p>
                          <p className="text-lg font-black text-slate-800">
                            {paymentStudent.added_by_name || "Admin"}
                          </p>
                        </div>
                        <div className="glass p-6 rounded-3xl border border-white/40 shadow-lg">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                            {paymentStudent.course_id
                              ? "Course Fee"
                              : "Admission Fee"}
                          </p>
                          <p className="text-lg font-black text-slate-800">
                            ৳{Number(paymentStudent.admission_fee) || 0}
                          </p>
                        </div>
                        {!paymentStudent.course_id && (
                          <div className="glass p-6 rounded-3xl border border-white/40 shadow-lg">
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                              Regular Fee
                            </p>
                            <p className="text-lg font-black text-slate-800">
                              ৳{Number(paymentStudent.monthly_fee) || 0}
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Monthly Payment Status Grid */}
                      <div className="glass p-8 rounded-3xl border border-white/40 shadow-xl">
                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-orange-600" />{" "}
                          Monthly Payment Status
                        </h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                          {MONTHS.map((month) => {
                            const currentMonthIndex = new Date().getMonth();
                            const isPaid = paymentStudent.payments?.some(
                              (p: any) =>
                                (p.type === "monthly" || p.type === "admission") && 
                                p.month && 
                                p.month.toLowerCase() === month.toLowerCase(),
                            ) || (
                              paymentStudent.admission_month && 
                              paymentStudent.admission_month.toLowerCase() === month.toLowerCase() && 
                              Number(paymentStudent.paid_amount || 0) > 0
                            );
                            const enrollmentDateRaw = paymentStudent.date_of_admission || paymentStudent.created_at || new Date();
                            const enrollmentDate = new Date(enrollmentDateRaw);
                            
                            // Adjust starting month if admission_month is set
                            let enrollmentMonthIndex = enrollmentDate.getMonth();
                            if (paymentStudent.admission_month) {
                              const mIdx = MONTHS.indexOf(paymentStudent.admission_month);
                              if (mIdx !== -1) {
                                enrollmentMonthIndex = mIdx;
                              }
                            }

                            const monthStr = month || "January";
                            const monthIndex = MONTHS.indexOf(monthStr);

                            // Only hide months that are truly before the admission month 
                            // in the same year or future years if added recently
                            if (monthIndex < enrollmentMonthIndex) return null;

                            return (
                              <div
                                key={month}
                                className={`p-4 rounded-2xl border-2 text-center transition-all ${
                                  isPaid
                                    ? "bg-emerald-50/50 border-emerald-200 text-emerald-700 shadow-sm"
                                    : monthIndex <= currentMonthIndex
                                      ? "bg-orange-50/50 border-orange-200 text-orange-700 shadow-sm"
                                      : "bg-slate-50/50 border-slate-100 text-slate-400 opacity-50"
                                }`}
                              >
                                <p className="text-[10px] font-black uppercase tracking-widest mb-1">
                                  {month}
                                </p>
                                <p className="text-xs font-bold">
                                  {isPaid
                                    ? "PAID"
                                    : monthIndex <= currentMonthIndex
                                      ? "DUE"
                                      : "PENDING"}
                                </p>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <form
                        onSubmit={handleAddPayment}
                        className="glass p-8 md:p-10 rounded-3xl border border-white/40 shadow-xl relative z-10"
                      >
                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">
                          Record New Payment
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                              Amount (৳)
                            </label>
                            <input
                              type="number"
                              placeholder="Amount"
                              className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                              value={paymentData.amount}
                              onChange={(e) =>
                                setPaymentData({
                                  ...paymentData,
                                  amount: e.target.value,
                                })
                              }
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                              Date
                            </label>
                            <input
                              type="date"
                              className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                              value={paymentData.date}
                              onChange={(e) =>
                                setPaymentData({
                                  ...paymentData,
                                  date: e.target.value,
                                })
                              }
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                              Type
                            </label>
                            <select
                              className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                              value={paymentData.type}
                              onChange={(e) =>
                                setPaymentData({
                                  ...paymentData,
                                  type: e.target.value,
                                })
                              }
                            >
                              <option value="monthly">Monthly Fee</option>
                              <option value="admission">Admission Fee</option>
                              <option value="exam">Exam Fee</option>
                            </select>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                                Month
                              </label>
                              <select
                                className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                                value={paymentData.month}
                                onChange={(e) =>
                                  setPaymentData({
                                    ...paymentData,
                                    month: e.target.value,
                                  })
                                }
                                required={paymentData.type === "monthly"}
                              >
                                <option value="">
                                  Select Month{" "}
                                  {paymentData.type === "monthly"
                                    ? ""
                                    : "(Optional)"}
                                </option>
                                {MONTHS.map((m) => (
                                  <option key={m} value={m}>
                                    {m}
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">
                                Year
                              </label>
                              <select
                                className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                                value={paymentData.year}
                                onChange={(e) =>
                                  setPaymentData({
                                    ...paymentData,
                                    year: e.target.value,
                                  })
                                }
                              >
                                {[
                                  new Date().getFullYear() - 1,
                                  new Date().getFullYear(),
                                  new Date().getFullYear() + 1,
                                ].map((y) => (
                                  <option key={y} value={y}>
                                    {y}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>
                        </div>
                        <button
                          type="submit"
                          className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 active:scale-[0.98] flex items-center justify-center gap-3"
                        >
                          <DollarSign className="h-6 w-6" /> Confirm Payment
                        </button>
                      </form>
                    </motion.div>
                  )}
                </div>
              </div>
            )}

            {/* Payment History Tab */}
            {activeTab === "payments_history" && (
              <div className="space-y-8 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                    <History className="h-8 w-8 text-orange-600" /> Payment
                    History
                  </h2>
                  <div className="flex flex-wrap items-center gap-4">
                    <select
                      className="glass-select w-48 border-2 border-orange-100 focus:border-orange-500"
                      value={paymentProgramFilter}
                      onChange={(e) => setPaymentProgramFilter(e.target.value)}
                    >
                      <option value="">All Programs</option>
                      {programs.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.title}
                        </option>
                      ))}
                    </select>
                    <select
                      className="glass-select w-48 border-2 border-orange-100 focus:border-orange-500"
                      value={paymentSort}
                      onChange={(e) => setPaymentSort(e.target.value)}
                    >
                      <option value="date">Sort by Date</option>
                      <option value="student">Sort by Student</option>
                      <option value="batch">Sort by Batch</option>
                    </select>
                  </div>
                </div>

                <div className="glass p-8 md:p-10 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                  <div className="overflow-x-auto relative z-10">
                    <table className="w-full text-left border-collapse min-w-[1000px]">
                      <thead>
                        <tr className="bg-slate-50/50 border-b border-slate-100">
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Date
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Student Name
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Roll No
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Batch
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Month
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Type
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest text-right">
                            Amount
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest text-center">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {sortedPayments
                          .slice(0, paymentLimit)
                          .map((payment) => (
                            <tr
                              key={payment.id}
                              className="border-b border-slate-50 hover:bg-orange-50/50 transition-colors group"
                            >
                              <td className="p-6 text-slate-600 font-medium">
                                {payment.date}
                              </td>
                              <td className="p-6 font-bold text-slate-800 group-hover:text-orange-600 transition-colors">
                                {payment.student_name}
                              </td>
                              <td className="p-6">
                                <span className="bg-orange-50 text-orange-600 px-3 py-1 rounded-lg font-mono font-bold border border-orange-100">
                                  {payment.roll_number}
                                </span>
                              </td>
                              <td className="p-6 text-slate-600 font-medium">
                                {payment.batch_name || "-"}
                              </td>
                              <td className="p-6 text-slate-600 font-medium">
                                {payment.month || "-"}
                              </td>
                              <td className="p-6">
                                <span
                                  className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                                    payment.type === "admission"
                                      ? "bg-purple-100 text-purple-700"
                                      : payment.type === "course"
                                        ? "bg-orange-100 text-orange-700"
                                        : payment.type === "exam"
                                          ? "bg-blue-100 text-blue-700"
                                          : "bg-emerald-100 text-emerald-700"
                                  }`}
                                >
                                  {payment.type}
                                </span>
                              </td>
                              <td className="p-6 text-right font-black text-slate-800">
                                ৳{payment.amount}
                              </td>
                              <td className="p-6 text-center">
                                <button
                                  onClick={() =>
                                    handleDeletePayment(payment.id)
                                  }
                                  className="text-orange-500 hover:text-white p-3 rounded-xl hover:bg-orange-600 transition-all active:scale-90 shadow-sm hover:shadow-orange-200"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                    {allPayments.length === 0 && (
                      <div className="text-center py-20 text-slate-400 relative z-10">
                        <DollarSign className="h-16 w-16 mx-auto mb-6 opacity-10" />
                        <p className="font-bold uppercase tracking-widest text-[10px]">
                          No payment records found
                        </p>
                      </div>
                    )}
                    {sortedPayments.length > paymentLimit && (
                      <div className="p-8 text-center relative z-10">
                        <button
                          onClick={() => setPaymentLimit((prev) => prev + 100)}
                          className="px-10 py-4 bg-slate-100 text-slate-600 font-black uppercase tracking-widest text-xs rounded-2xl hover:bg-orange-600 hover:text-white transition-all shadow-sm active:scale-95"
                        >
                          Load More Records
                        </button>
                      </div>
                    )}
                    <div className="p-8 text-right border-t border-slate-100 relative z-10">
                      <button
                        onClick={() => handleResetData("payments")}
                        className="bg-red-50 hover:bg-red-100 text-red-600 px-6 py-3 rounded-2xl font-bold text-sm uppercase tracking-widest inline-flex items-center gap-2 transition-all border border-red-200"
                        title="Delete All Payments"
                      >
                        <Trash2 className="h-4 w-4" /> Delete All Records
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Results Tab */}
            {activeTab === "results" && (
              <div className="space-y-10 w-full animate-in fade-in slide-in-from-bottom-4 duration-700">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div className="relative">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                      <div className="p-3 rounded-2xl bg-orange-500 text-white shadow-lg shadow-orange-200">
                        <BarChart className="h-8 w-8" />
                      </div>
                      Exam Results
                    </h2>
                    <div className="absolute -bottom-2 left-16 w-24 h-1.5 bg-orange-500 rounded-full"></div>
                  </div>
                  <div className="flex items-center gap-4 w-full md:w-auto">
                    <div className="relative flex-1 md:w-80">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                      <DebouncedInput
                        type="text"
                        placeholder="Search results..."
                        className="glass-input pl-10 py-3 w-full"
                        value={searchTerm}
                        onChange={(value: string) => setSearchTerm(value)}
                      />
                    </div>
                    <button
                      onClick={() => clearForm("result")}
                      className="px-4 py-2 bg-white/60 backdrop-blur-md border border-white/60 text-slate-500 hover:text-orange-600 rounded-xl text-xs font-black uppercase tracking-widest transition-all hover:shadow-lg active:scale-95 flex items-center gap-2 whitespace-nowrap"
                    >
                      <XCircle className="h-4 w-4" /> Clear
                    </button>
                  </div>
                </div>

                {authLoading ? (
                  <TableSkeleton />
                ) : (
                  <>
                    <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl relative overflow-hidden group">
                      <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48 group-hover:bg-orange-500/10 transition-colors duration-700"></div>

                      <div className="flex items-center gap-4 mb-10 relative z-10">
                        <div className="h-12 w-1.5 bg-orange-500 rounded-full"></div>
                        <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                          Upload New Result
                        </h3>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10 relative z-10">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            1. Program (Optional)
                          </label>
                          <select
                            className="glass-select bg-slate-50/50"
                            value={resultSearch.program_id}
                            onChange={(e) => {
                              setResultSearch((prev) => ({
                                ...prev,
                                program_id: e.target.value,
                                batch_id: "", // Reset batch when program changes
                              }));
                              setNewResult((prev) => ({
                                ...prev,
                                exam_id: "", // Reset exam as well
                                highest_marks: "",
                                negative_marks: "",
                              }));
                            }}
                          >
                            <option value="">All Programs</option>
                            {programs.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.title}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-400 uppercase ml-1">
                            2. Batch (Optional)
                          </label>
                          <select
                            className="glass-select bg-slate-50"
                            value={resultSearch.batch_id}
                            onChange={(e) => {
                              setResultSearch((prev) => ({
                                ...prev,
                                batch_id: e.target.value,
                              }));
                              setNewResult((prev) => ({
                                ...prev,
                                exam_id: "", // Reset exam when batch changes
                                highest_marks: "",
                                negative_marks: "",
                              }));
                            }}
                          >
                            <option value="">All Batches</option>
                            {getFilteredBatches(resultSearch.program_id).map(
                              (b) => (
                                <option key={b.id} value={b.id}>
                                  {b.name}
                                </option>
                              ),
                            )}
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-orange-600 ml-4">
                            3. Select Exam
                          </label>
                          <select
                            className="glass-select border-2 border-orange-100 focus:border-orange-500"
                            value={newResult.exam_id}
                            onChange={(e) => {
                              const examId = e.target.value;
                              const exam = exams.find((ex) => ex.id == examId);
                              if (exam) {
                                setNewResult((prev) => ({
                                  ...prev,
                                  exam_id: examId,
                                  highest_marks: exam?.highest_marks?.toString() || exam?.total_marks?.toString() || "",
                                  negative_marks: exam?.negative_marks?.toString() || "",
                                }));
                                // Also auto-fill program/batch if not already selected and exam has them
                                if (
                                  !resultSearch.batch_id &&
                                  exam.batch_id !== "all"
                                ) {
                                  setResultSearch((prev) => ({
                                    ...prev,
                                    batch_id: exam.batch_id?.toString() || "",
                                    program_id:
                                      exam.program_id?.toString() || "",
                                  }));
                                }
                              } else {
                                setNewResult((prev) => ({
                                  ...prev,
                                  exam_id: examId,
                                  highest_marks: "",
                                  negative_marks: "",
                                }));
                              }
                            }}
                          >
                            <option value="">Select Exam</option>
                            {exams
                              .filter((exam) => {
                                // Filter by selected program
                                if (
                                  resultSearch.program_id &&
                                  exam.program_id !== "all" &&
                                  String(exam.program_id) !== String(resultSearch.program_id) &&
                                  !String(exam.program_id).includes(String(resultSearch.program_id))
                                ) {
                                  return false;
                                }
                                // Filter by selected batch
                                if (
                                  resultSearch.batch_id &&
                                  exam.batch_id !== "all" &&
                                  String(exam.batch_id) !== String(resultSearch.batch_id) &&
                                  !String(exam.batch_id).includes(String(resultSearch.batch_id))
                                ) {
                                  return false;
                                }
                                return true;
                              })
                              .sort(
                                (a, b) =>
                                  new Date(b.exam_date).getTime() -
                                  new Date(a.exam_date).getTime(),
                              )
                              .map((exam) => (
                                <option key={exam.id} value={exam.id}>
                                  {exam.exam_name} ({exam.batch_name})
                                </option>
                              ))}
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-orange-600 uppercase ml-1">
                            Phone Number
                          </label>
                          <div className="flex gap-2">
                            <DebouncedInput
                              type="text"
                              placeholder="Enter Phone Number or Roll"
                              debounce={0}
                              className="glass-input"
                              value={resultSearch.roll_number}
                              onChange={(value: string) =>
                                setResultSearch((prev) => ({
                                  ...prev,
                                  roll_number: value,
                                }))
                              }
                              onEnter={(val: string) => searchResultStudent(val)}
                            />
                            <button
                              onClick={() => searchResultStudent()}
                              disabled={!newResult.exam_id}
                              className="glass-btn px-6 whitespace-nowrap"
                            >
                              <Search className="h-5 w-5" />
                            </button>
                          </div>
                        </div>
                      </div>

                      {newResult.exam_id && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 bg-white/30 backdrop-blur-sm p-6 rounded-2xl border border-white/40 relative z-10">
                          <div className="space-y-1">
                            <label className="block text-sm font-bold text-slate-700 mb-1 ml-1">
                              Highest Marks
                            </label>
                            <input
                              type="number"
                              className="glass-input"
                              value={newResult.highest_marks || ""}
                              onChange={(e) =>
                                setNewResult({
                                  ...newResult,
                                  highest_marks: e.target.value,
                                })
                              }
                              placeholder="e.g. 100"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="block text-sm font-bold text-slate-700 mb-1 ml-1">
                              Negative Marks
                            </label>
                            <input
                              type="number"
                              className="glass-input"
                              value={newResult.negative_marks || ""}
                              onChange={(e) =>
                                setNewResult({
                                  ...newResult,
                                  negative_marks: e.target.value,
                                })
                              }
                              placeholder="e.g. 0.25"
                              step="0.01"
                            />
                          </div>
                        </div>
                      )}

                      {resultStudent && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.98 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="space-y-8 relative z-10"
                        >
                          <div className="bg-gradient-to-r from-orange-500/10 to-orange-600/10 p-6 rounded-2xl border border-white/40 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
                            <div className="flex items-center gap-4">
                              <div className="w-16 h-16 rounded-full bg-orange-600 flex items-center justify-center text-white text-2xl font-black shadow-lg">
                                {resultStudent.name.charAt(0)}
                              </div>
                              <div>
                                <h3 className="text-2xl font-black text-slate-900 leading-tight">
                                  {resultStudent.name}
                                </h3>
                                <p className="text-slate-600 font-medium">
                                  Roll:{" "}
                                  <span className="text-orange-600 font-bold">
                                    {resultStudent.roll_number}
                                  </span>{" "}
                                  | Class:{" "}
                                  {resultStudent.current_class || "N/A"}
                                </p>
                              </div>
                            </div>
                            <div className="text-left sm:text-right w-full sm:w-auto bg-white/50 backdrop-blur-sm p-4 rounded-xl border border-white/40 shadow-sm">
                              <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                                Active Exam
                              </div>
                              <div className="font-bold text-orange-600 text-lg">
                                {
                                  exams.find((e) => e.id == newResult.exam_id)
                                    ?.exam_name
                                }
                              </div>
                            </div>
                          </div>

                          <form
                            onSubmit={handleAddResult}
                            className="space-y-6 bg-white/40 backdrop-blur-md p-8 rounded-3xl border border-white/60 shadow-inner"
                          >
                            <div className="flex items-center justify-between mb-4">
                              <h4 className="text-sm font-black text-slate-500 uppercase tracking-widest">
                                Result Entry
                              </h4>
                              <button
                                type="button"
                                onClick={() => {
                                  const exam = exams.find(
                                    (e) => e.id == newResult.exam_id,
                                  );
                                  const qCount = 100; // Default or from exam if available
                                  const initialQuestions = Array.from(
                                    { length: qCount },
                                    (_, i) => ({
                                      id: i + 1,
                                      status: "none" as const,
                                    }),
                                  );
                                  setNewResult({
                                    ...newResult,
                                    marking_mode: !newResult.marking_mode,
                                    questions: initialQuestions,
                                  });
                                }}
                                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${newResult.marking_mode ? "bg-orange-600 text-white shadow-lg" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
                              >
                                <CheckSquare className="h-4 w-4" />{" "}
                                {newResult.marking_mode
                                  ? "Manual Mode"
                                  : "PDF Marking Mode"}
                              </button>
                            </div>

                            {newResult.marking_mode ? (
                              <div className="space-y-6 animate-in zoom-in-95 duration-300">
                                <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 max-h-[400px] overflow-y-auto p-4 bg-white/50 rounded-2xl border border-white/40 shadow-inner custom-scrollbar">
                                  {newResult.questions.map((q, idx) => (
                                    <button
                                      key={q.id}
                                      type="button"
                                      onClick={() => {
                                        const updated = [
                                          ...newResult.questions,
                                        ];
                                        if (q.status === "none")
                                          updated[idx].status = "correct";
                                        else if (q.status === "correct")
                                          updated[idx].status = "wrong";
                                        else updated[idx].status = "none";

                                        const correct = updated.filter(
                                          (x) => x.status === "correct",
                                        ).length;
                                        const wrong = updated.filter(
                                          (x) => x.status === "wrong",
                                        ).length;

                                        setNewResult({
                                          ...newResult,
                                          questions: updated,
                                          correct_answers: correct.toString(),
                                          wrong_answers: wrong.toString(),
                                        });
                                      }}
                                      className={`aspect-square rounded-lg flex items-center justify-center text-xs font-black transition-all border-2 ${
                                        q.status === "correct"
                                          ? "bg-green-500 border-green-600 text-white shadow-md scale-105"
                                          : q.status === "wrong"
                                            ? "bg-red-500 border-red-600 text-white shadow-md scale-105"
                                            : "bg-white border-slate-200 text-slate-400 hover:border-orange-400"
                                      }`}
                                    >
                                      {q.id}
                                    </button>
                                  ))}
                                </div>
                                <div className="grid grid-cols-2 gap-4 p-4 bg-orange-50 rounded-2xl border border-orange-100">
                                  <div className="text-center">
                                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                                      Correct
                                    </div>
                                    <div className="text-2xl font-black text-green-600">
                                      {newResult.correct_answers || "0"}
                                    </div>
                                  </div>
                                  <div className="text-center">
                                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                                      Wrong
                                    </div>
                                    <div className="text-2xl font-black text-red-600">
                                      {newResult.wrong_answers || "0"}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                <div className="space-y-1">
                                  <label className="text-xs font-black text-slate-500 uppercase tracking-wider ml-1">
                                    Correct Answers
                                  </label>
                                  <input
                                    type="number"
                                    placeholder="0"
                                    className="glass-input text-center text-2xl font-black text-green-600"
                                    value={newResult.correct_answers || ""}
                                    onChange={(e) =>
                                      setNewResult({
                                        ...newResult,
                                        correct_answers: e.target.value,
                                      })
                                    }
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-xs font-black text-slate-500 uppercase tracking-wider ml-1">
                                    Wrong Answers
                                  </label>
                                  <input
                                    type="number"
                                    placeholder="0"
                                    className="glass-input text-center text-2xl font-black text-orange-600"
                                    value={newResult.wrong_answers || ""}
                                    onChange={(e) =>
                                      setNewResult({
                                        ...newResult,
                                        wrong_answers: e.target.value,
                                      })
                                    }
                                  />
                                </div>
                              </div>
                            )}
                            <button
                              type="submit"
                              className="glass-btn w-full text-xl py-4"
                            >
                              <CheckCircle2 className="h-6 w-6" /> Save Result
                            </button>
                          </form>

                          {/* Previous Results */}
                          <div className="bg-slate-50 p-4 md:p-6 rounded-xl border border-slate-200">
                            <h4 className="font-bold text-slate-800 mb-4">
                              Previous Results
                            </h4>
                            <div className="space-y-2">
                              {resultStudent.results &&
                              resultStudent.results.length > 0 ? (
                                resultStudent.results.map((res: any) => {
                                  let calculatedMerit = res.merit_position;
                                  if (!calculatedMerit) {
                                    const key = res.exam_id || res.exam_name;
                                    if (key && meritPositions[key]) {
                                      calculatedMerit =
                                        meritPositions[key][resultStudent.id];
                                    }
                                  }
                                  return (
                                    <div
                                      key={res.id || Math.random()}
                                      className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 sm:p-4 glass bg-white/30 backdrop-blur-xl border border-white/60 rounded-2xl shadow-sm gap-2 sm:gap-0"
                                    >
                                      <span className="font-medium text-slate-800 text-sm sm:text-base break-words w-full sm:w-auto">
                                        {res.exam_name}
                                      </span>
                                      <div className="flex items-center justify-between w-full sm:w-auto sm:justify-end gap-4">
                                        {calculatedMerit && (
                                          <span className="text-xs sm:text-sm font-semibold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md">
                                            Merit: {calculatedMerit}
                                          </span>
                                        )}
                                        <span className="font-bold text-orange-600 text-sm sm:text-base">
                                          {res.marks} / {res.total_marks}
                                        </span>
                                      </div>
                                    </div>
                                  );
                                })
                              ) : (
                                <p className="text-slate-500 text-sm text-center py-4">
                                  No results found.
                                </p>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </div>

                    {/* All Results Cards (Batch-wise) */}
                    <div className="space-y-8 mt-8">
                      {batches.map((batch) => {
                        const batchResults = allResults.filter(
                          (r) =>
                            String(r.batch_id) === String(batch.id) &&
                            (r.student_name
                              ?.toLowerCase()
                              .includes(debouncedSearchTerm.toLowerCase()) ||
                              r.roll_number
                                ?.toString()
                                .includes(debouncedSearchTerm)),
                        );

                        if (batchResults.length === 0) return null;

                        return (
                          <div
                            key={batch.id}
                            className="glass rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl overflow-hidden"
                          >
                            <div className="bg-gradient-to-r from-orange-600 to-orange-700 px-8 py-4 flex justify-between items-center">
                              <h4 className="text-xl font-black text-white">
                                {batch.name}
                              </h4>
                              <span className="glass bg-white/20 text-white px-4 py-1 rounded-full text-sm font-bold backdrop-blur-sm">
                                {batchResults.length} Results
                              </span>
                            </div>
                            <div className="overflow-x-auto p-8">
                              <table className="w-full text-left border-collapse">
                                <thead>
                                  <tr className="border-b border-slate-100/50 bg-slate-50/30">
                                    <th className="p-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                      Merit
                                    </th>
                                    <th className="p-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                      Student
                                    </th>
                                    <th className="p-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                      Exam
                                    </th>
                                    <th className="p-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                      Obtained
                                    </th>
                                    <th className="p-4 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                      Highest
                                    </th>
                                    <th className="p-4 font-black text-slate-400 text-[10px] uppercase tracking-widest text-right">
                                      Actions
                                    </th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-50">
                                  {batchResults
                                    .sort((a, b) => b.marks - a.marks)
                                    .map((result, idx) => (
                                      <tr
                                        key={result.id}
                                        className="hover:bg-orange-50/50 transition-colors group"
                                      >
                                        <td className="p-4">
                                          <span className="text-sm font-black text-slate-400 group-hover:text-orange-600">
                                            #{result.merit_position || idx + 1}
                                          </span>
                                        </td>
                                        <td className="p-4">
                                          <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-black text-xs">
                                              {result.student_name?.charAt(0)}
                                            </div>
                                            <div>
                                              <div className="font-black text-slate-900 uppercase text-xs leading-tight">
                                                {result.student_name}
                                              </div>
                                              <div className="text-[10px] text-slate-400 font-bold">
                                                ROLL: {result.roll_number}
                                              </div>
                                            </div>
                                          </div>
                                        </td>
                                        <td className="p-4">
                                          <div className="text-xs font-bold text-slate-600">
                                            {result.exam_name}
                                          </div>
                                        </td>
                                        <td className="p-4">
                                          <div className="text-sm font-black text-orange-600">
                                            {Number(result.marks ?? 0).toFixed(
                                              2,
                                            )}
                                          </div>
                                        </td>
                                        <td className="p-4">
                                          <div className="text-sm font-black text-emerald-600">
                                            {Number(
                                              result.highest_marks ??
                                                result.total_marks ??
                                                0,
                                            ).toFixed(2)}
                                          </div>
                                        </td>
                                        <td className="p-4 text-right">
                                          <button
                                            onClick={() =>
                                              handleDeleteResult(result.id)
                                            }
                                            className="p-2 rounded-lg text-slate-400 hover:text-orange-600 hover:bg-orange-50 transition-all active:scale-90"
                                          >
                                            <Trash2 className="h-4 w-4" />
                                          </button>
                                        </td>
                                      </tr>
                                    ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        );
                      })}

                      {allResults.length === 0 && (
                        <div className="p-20 text-center glass rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl">
                          <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Search className="h-10 w-10 text-slate-300" />
                          </div>
                          <p className="text-slate-500 font-bold">
                            No exam results found.
                          </p>
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Programs Management Tab */}
            {activeTab === "programs" && (
              <div className="space-y-10 w-full">
                {authLoading ? (
                  <TableSkeleton />
                ) : (
                  <>
                    <div className="flex justify-between items-center">
                      <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                        <GraduationCap className="h-8 w-8 text-orange-600" />{" "}
                        Programs Management
                      </h2>
                      <div className="flex gap-4">
                        <div className="glass px-6 py-3 rounded-2xl border border-white/40 shadow-lg">
                          <span className="text-[10px] font-black text-orange-600 uppercase tracking-widest block mb-1">
                            Total Programs
                          </span>
                          <div className="text-2xl font-black text-slate-900">
                            {programs.length}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Program Stats Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                      {programStats.map((prog) => (
                        <motion.div
                          key={prog.id}
                          whileHover={{ y: -8, scale: 1.02 }}
                          className="glass p-8 rounded-[32px] shadow-xl border border-white/40 relative overflow-hidden group transition-all duration-500"
                        >
                          <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full -mr-16 -mt-16 opacity-50 group-hover:scale-150 transition-transform duration-700"></div>
                          <div className="relative z-10">
                            <h3 className="font-black text-slate-900 mb-2 truncate text-lg group-hover:text-orange-600 transition-colors">
                              {prog.title}
                            </h3>
                            <p className="text-[10px] font-black text-orange-600 uppercase tracking-[0.2em] mb-6">
                              {prog.target_audience}
                            </p>

                            <div className="grid grid-cols-2 gap-6">
                              <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100/50">
                                <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">
                                  Students
                                </div>
                                <div className="text-xl font-black text-slate-800">
                                  {prog.studentCount}
                                </div>
                              </div>
                              <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100/50">
                                <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">
                                  Batches
                                </div>
                                <div className="text-xl font-black text-slate-800">
                                  {prog.batchCount}
                                </div>
                              </div>
                              <div className="col-span-2 bg-emerald-50/30 p-4 rounded-2xl border border-emerald-100/50">
                                <div className="text-[9px] font-black text-emerald-600/60 uppercase tracking-widest mb-1">
                                  Total Revenue
                                </div>
                                <div className="text-2xl font-black text-emerald-600">
                                  ৳{prog.totalRevenue.toLocaleString()}
                                </div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>

                    <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
                      <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -ml-48 -mb-48"></div>

                      <h3 className="text-2xl font-black text-slate-800 mb-10 relative z-10 flex items-center gap-3">
                        <Plus className="h-8 w-8 text-orange-600" /> Add New
                        Program
                      </h3>

                      <form
                        onSubmit={handleAddProgram}
                        className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10"
                      >
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Program Title
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. HSC Math Full Course"
                            className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                            value={newProgram.title}
                            onChange={(e) =>
                              setNewProgram({
                                ...newProgram,
                                title: e.target.value,
                              })
                            }
                            required
                          />
                        </div>
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Target Audience
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Class 11-12"
                            className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                            value={newProgram.target_audience}
                            onChange={(e) =>
                              setNewProgram({
                                ...newProgram,
                                target_audience: e.target.value,
                              })
                            }
                            required
                          />
                        </div>
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Admission Fee
                          </label>
                          <input
                            type="text"
                            placeholder="৳"
                            className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                            value={newProgram.admission_fee}
                            onChange={(e) =>
                              setNewProgram({
                                ...newProgram,
                                admission_fee: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Monthly Fee
                          </label>
                          <input
                            type="text"
                            placeholder="৳"
                            className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                            value={newProgram.monthly_fee}
                            onChange={(e) =>
                              setNewProgram({
                                ...newProgram,
                                monthly_fee: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="space-y-3 md:col-span-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Image URL
                          </label>
                          <div className="flex flex-col gap-2">
                            <input
                              type="text"
                              placeholder="https://..."
                              className={`glass-input w-full border-2 border-orange-100 focus:border-orange-500 ${newProgram.image_url?.startsWith("data:image") ? "opacity-50" : ""}`}
                              value={
                                newProgram.image_url?.startsWith("data:image")
                                  ? "Linked via File Upload"
                                  : newProgram.image_url
                              }
                              onChange={(e) =>
                                setNewProgram({
                                  ...newProgram,
                                  image_url: e.target.value,
                                })
                              }
                              disabled={newProgram.image_url?.startsWith(
                                "data:image",
                              )}
                            />
                            <div className="flex items-center gap-2">
                              <input
                                type="file"
                                id="program-image-upload"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    processImage(file, (dataUrl) =>
                                      setNewProgram({
                                        ...newProgram,
                                        image_url: dataUrl,
                                      }),
                                    );
                                    e.target.value = "";
                                  }
                                }}
                              />
                              <label
                                htmlFor="program-image-upload"
                                className="cursor-pointer bg-orange-50 text-orange-600 px-4 py-2 rounded-xl font-bold text-xs hover:bg-orange-100 transition-all border border-orange-200 flex items-center gap-2"
                              >
                                <Upload className="h-4 w-4" /> Choose File
                              </label>
                              {newProgram.image_url?.startsWith(
                                "data:image",
                              ) && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    setNewProgram({
                                      ...newProgram,
                                      image_url: "",
                                    })
                                  }
                                  className="bg-red-50 text-red-600 px-4 py-2 rounded-xl font-bold text-xs hover:bg-red-100 transition-all border border-red-200"
                                >
                                  Clear Image
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                        {newProgram.image_url && (
                          <div className="md:col-span-2 relative w-full h-48 rounded-2xl overflow-hidden border border-slate-200">
                            <img
                              src={newProgram.image_url}
                              alt="Preview"
                              className="w-full h-full object-cover"
                              onError={handleImageError}
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        )}
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">
                            Description
                          </label>
                          <textarea
                            placeholder="Describe the program..."
                            className="input-field h-32"
                            value={newProgram.description}
                            onChange={(e) =>
                              setNewProgram({
                                ...newProgram,
                                description: e.target.value,
                              })
                            }
                            required
                          />
                        </div>
                        <div className="space-y-3 md:col-span-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Features (comma separated)
                          </label>
                          <input
                            type="text"
                            placeholder="Live Classes, PDF Notes, Weekly Exams..."
                            className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                            value={newProgram.features}
                            onChange={(e) =>
                              setNewProgram({
                                ...newProgram,
                                features: e.target.value,
                              })
                            }
                          />
                        </div>
                        <button
                          type="submit"
                          className="md:col-span-2 bg-orange-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-100 active:scale-[0.98] flex items-center justify-center gap-3"
                        >
                          <Plus className="h-6 w-6" /> Create Program
                        </button>
                      </form>
                    </div>

                    <div className="glass p-8 md:p-10 rounded-[40px] shadow-2xl border border-white/40 overflow-hidden relative">
                      <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                      <div className="p-8 border-b border-slate-100 flex justify-between items-center relative z-10">
                        <h3 className="text-xl font-black text-slate-800 uppercase tracking-widest">
                          Existing Programs
                        </h3>
                        <span className="bg-orange-50 text-orange-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-orange-100">
                          {programStats.length} Total
                        </span>
                      </div>
                      <div className="overflow-x-auto relative z-10">
                        <table className="w-full text-left min-w-[1000px]">
                          <thead>
                            <tr className="bg-slate-50/50 border-b border-slate-100">
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Program
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Audience
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Fees
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest text-center">
                                Stats
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest text-right">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50">
                            {programStats.map((prog) => (
                              <tr
                                key={prog.id}
                                className="hover:bg-orange-50/50 transition-colors group"
                              >
                                <td className="p-6">
                                  <div className="flex items-center gap-4">
                                    <div className="w-16 h-16 rounded-2xl overflow-hidden border border-white shadow-md flex-shrink-0">
                                      <img
                                        src={
                                          prog.image_url ||
                                          "https://picsum.photos/seed/prog/100/100"
                                        }
                                        alt={prog.title}
                                        className="w-full h-full object-cover"
                                        onError={handleImageError}
                                        referrerPolicy="no-referrer"
                                      />
                                    </div>
                                    <div>
                                      <div className="font-black text-slate-900 text-lg group-hover:text-orange-600 transition-colors">
                                        {prog.title}
                                      </div>
                                      <div className="text-xs text-slate-400 font-medium line-clamp-1 max-w-xs">
                                        {prog.description}
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td className="p-6">
                                  <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border border-slate-200">
                                    {prog.target_audience || prog.class || "N/A"}
                                  </span>
                                </td>
                                <td className="p-6">
                                  <div className="space-y-1">
                                    <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                      Adm:{" "}
                                      <span className="text-slate-800">
                                        ৳{prog.admission_fee || 0}
                                      </span>
                                    </div>
                                    <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                      Mon:{" "}
                                      <span className="text-slate-800">
                                        ৳{prog.monthly_fee || 0}
                                      </span>
                                    </div>
                                  </div>
                                </td>
                                <td className="p-6">
                                  <div className="flex items-center justify-center gap-4">
                                    <div className="text-center">
                                      <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                        Students
                                      </div>
                                      <div className="text-sm font-black text-slate-800">
                                        {prog.studentCount}
                                      </div>
                                    </div>
                                    <div className="text-center">
                                      <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                        Batches
                                      </div>
                                      <div className="text-sm font-black text-slate-800">
                                        {prog.batchCount}
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td className="p-6 text-right">
                                  <div className="flex justify-end gap-2">
                                    <button
                                      onClick={() => setEditingProgram(prog)}
                                      className="text-blue-500 hover:text-white p-3 rounded-xl hover:bg-blue-600 transition-all active:scale-90 shadow-sm hover:shadow-blue-200"
                                    >
                                      <Edit2 className="h-4 w-4" />
                                    </button>
                                    <button
                                      onClick={() =>
                                        handleDeleteProgram(prog.id)
                                      }
                                      className="text-orange-500 hover:text-white p-3 rounded-xl hover:bg-orange-600 transition-all active:scale-90 shadow-sm hover:shadow-orange-200"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                            {programs.length === 0 && (
                              <tr>
                                <td
                                  colSpan={5}
                                  className="p-20 text-center text-slate-400 italic"
                                >
                                  No programs found.
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Edit Program Modal */}
                    <AnimatePresence>
                      {editingProgram && (
                        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                          <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="bg-white rounded-[2.5rem] shadow-2xl border border-white w-full max-w-4xl max-h-[90vh] overflow-y-auto p-8 md:p-12 relative"
                          >
                            <button
                              onClick={() => setEditingProgram(null)}
                              className="absolute top-8 right-8 p-2 hover:bg-slate-100 rounded-full transition-colors"
                            >
                              <X className="h-6 w-6 text-slate-400" />
                            </button>

                            <h3 className="text-3xl font-black text-slate-800 mb-10 flex items-center gap-3">
                              <Edit2 className="h-8 w-8 text-orange-600" /> Edit
                              Program
                            </h3>

                            <form
                              onSubmit={handleUpdateProgram}
                              className="grid grid-cols-1 md:grid-cols-2 gap-8"
                            >
                              <div className="space-y-3">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                                  Program Title
                                </label>
                                <input
                                  type="text"
                                  className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                                  value={editingProgram.title}
                                  onChange={(e) =>
                                    setEditingProgram({
                                      ...editingProgram,
                                      title: e.target.value,
                                    })
                                  }
                                  required
                                />
                              </div>
                              <div className="space-y-3">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                                  Target Audience
                                </label>
                                <input
                                  type="text"
                                  className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                                  value={editingProgram.target_audience}
                                  onChange={(e) =>
                                    setEditingProgram({
                                      ...editingProgram,
                                      target_audience: e.target.value,
                                    })
                                  }
                                  required
                                />
                              </div>
                              <div className="space-y-3">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                                  Admission Fee
                                </label>
                                <input
                                  type="text"
                                  className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                                  value={editingProgram.admission_fee}
                                  onChange={(e) =>
                                    setEditingProgram({
                                      ...editingProgram,
                                      admission_fee: e.target.value,
                                    })
                                  }
                                />
                              </div>
                              <div className="space-y-3">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                                  Monthly Fee
                                </label>
                                <input
                                  type="text"
                                  className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                                  value={editingProgram.monthly_fee}
                                  onChange={(e) =>
                                    setEditingProgram({
                                      ...editingProgram,
                                      monthly_fee: e.target.value,
                                    })
                                  }
                                />
                              </div>
                              <div className="space-y-3 md:col-span-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                                  Image URL
                                </label>
                                <input
                                  type="text"
                                  className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                                  value={editingProgram.image_url}
                                  onChange={(e) =>
                                    setEditingProgram({
                                      ...editingProgram,
                                      image_url: e.target.value,
                                    })
                                  }
                                />
                              </div>
                              <div className="space-y-2 md:col-span-2">
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">
                                  Description
                                </label>
                                <textarea
                                  className="input-field h-32"
                                  value={editingProgram.description}
                                  onChange={(e) =>
                                    setEditingProgram({
                                      ...editingProgram,
                                      description: e.target.value,
                                    })
                                  }
                                  required
                                />
                              </div>
                              <div className="space-y-3 md:col-span-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                                  Features (comma separated)
                                </label>
                                <input
                                  type="text"
                                  className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                                  value={editingProgram.features}
                                  onChange={(e) =>
                                    setEditingProgram({
                                      ...editingProgram,
                                      features: e.target.value,
                                    })
                                  }
                                />
                              </div>
                              <div className="flex gap-4 md:col-span-2">
                                <button
                                  type="button"
                                  onClick={() => setEditingProgram(null)}
                                  className="flex-1 bg-slate-100 text-slate-600 py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-200 transition-all"
                                >
                                  Cancel
                                </button>
                                <button
                                  type="submit"
                                  className="flex-2 bg-orange-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-100 active:scale-[0.98] flex items-center justify-center gap-3"
                                >
                                  <Save className="h-6 w-6" /> Update Program
                                </button>
                              </div>
                            </form>
                          </motion.div>
                        </div>
                      )}
                    </AnimatePresence>
                  </>
                )}
              </div>
            )}

            {/* Program Details Tab */}
            {activeTab === "program_details" && (
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-slate-800">
                  Program Details
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {programs.map((prog) => (
                    <div
                      key={prog.id}
                      className="glass p-8 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl space-y-6"
                    >
                      <div className="flex justify-between items-start">
                        <h3 className="text-2xl font-bold text-slate-900">
                          {prog.title}
                        </h3>
                        <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-xs font-bold uppercase">
                          {prog.target_audience}
                        </span>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center justify-between py-2 border-b border-slate-50">
                          <span className="text-slate-500 font-medium">
                            Admission Fee
                          </span>
                          <span className="text-orange-600 font-bold">
                            ৳{prog.admission_fee || 0}
                          </span>
                        </div>
                        <div className="flex items-center justify-between py-2 border-b border-slate-50">
                          <span className="text-slate-500 font-medium">
                            Monthly Fee
                          </span>
                          <span className="text-orange-600 font-bold">
                            ৳{prog.monthly_fee || 0}
                          </span>
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">
                          Description
                        </h4>
                        <p className="text-slate-600 leading-relaxed">
                          {prog.description}
                        </p>
                      </div>

                      <div>
                        <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">
                          Key Features
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {prog.features
                            ?.split(",")
                            .map((f: string, i: number) => (
                              <div
                                key={i}
                                className="flex items-center gap-2 bg-slate-50 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-100 text-sm"
                              >
                                <CheckCircle className="h-4 w-4 text-green-500" />
                                {f.trim()}
                              </div>
                            ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Enrollments Tab */}
            {activeTab === "enrollments" && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                {authLoading ? (
                  <TableSkeleton />
                ) : (
                  <>
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div className="relative">
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                          <UserPlus className="h-10 w-10 text-orange-600" />
                          Enrollment{" "}
                          <span className="text-orange-600">Applications</span>
                        </h2>
                        <div className="absolute -bottom-2 left-0 w-24 h-1 bg-gradient-to-r from-orange-600 to-orange-400 rounded-full"></div>
                      </div>
                      <div className="flex items-center gap-4 w-full md:w-auto">
                        <div className="relative flex-1 md:flex-none">
                          <select
                            className="glass-select w-full md:w-72 pl-10 appearance-none font-bold text-slate-700"
                            value={enrollmentProgramFilter}
                            onChange={(e) =>
                              setEnrollmentProgramFilter(e.target.value)
                            }
                          >
                            <option value="">All Programs</option>
                            {programs.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.title}
                              </option>
                            ))}
                          </select>
                          <Filter className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                          <ChevronDown className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                        </div>
                      </div>
                    </div>

                    <div className="glass rounded-[2.5rem] border border-white shadow-2xl overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="border-b border-slate-100/50 bg-slate-50/30">
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Date
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Student
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Contact
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Type
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Program
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Fee
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Status
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest text-right">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50">
                            {enrollments
                              .filter((enroll) => {
                                if (!enrollmentProgramFilter) return true;
                                const program = programs.find(
                                  (p) => p.id == enrollmentProgramFilter,
                                );
                                return enroll.program_title === program?.title;
                              })
                              .map((enroll) => (
                                <tr
                                  key={enroll.id}
                                  className="hover:bg-orange-50/50 transition-colors group"
                                >
                                  <td className="p-6">
                                    <div className="text-xs font-black text-slate-400 uppercase tracking-widest">
                                      {new Date(
                                        enroll.created_at,
                                      ).toLocaleDateString()}
                                    </div>
                                  </td>
                                  <td className="p-6">
                                    <div className="font-black text-slate-900 group-hover:text-orange-600 transition-colors">
                                      {enroll.name}
                                    </div>
                                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                      Class: {enroll.current_class}
                                    </div>
                                  </td>
                                  <td className="p-6">
                                    <div className="text-sm font-bold text-slate-600">
                                      {enroll.phone}
                                    </div>
                                  </td>
                                  <td className="p-6">
                                    <span
                                      className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border ${
                                        enroll.course_title
                                          ? "bg-blue-50 text-blue-600 border-blue-100"
                                          : "bg-purple-50 text-purple-600 border-purple-100"
                                      }`}
                                    >
                                      {enroll.course_title
                                        ? "Online"
                                        : "Program"}
                                    </span>
                                  </td>
                                  <td className="p-6">
                                    <div className="text-sm font-black text-slate-800 line-clamp-1 max-w-[200px]">
                                      {enroll.program_title ||
                                        enroll.course_title}
                                    </div>
                                  </td>
                                  <td className="p-6">
                                    <div className="text-sm font-black text-orange-600">
                                      ৳{enroll.fee}
                                    </div>
                                  </td>
                                  <td className="p-6">
                                    <span
                                      className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border ${
                                        enroll.status === "pending"
                                          ? "bg-amber-50 text-amber-600 border-amber-100"
                                          : "bg-emerald-50 text-emerald-600 border-emerald-100"
                                      }`}
                                    >
                                      {enroll.status}
                                    </span>
                                  </td>
                                  <td className="p-6 text-right">
                                    <div className="flex justify-end gap-2">
                                      <button
                                        onClick={() =>
                                          setSelectedEnrollment(enroll)
                                        }
                                        className="p-2.5 rounded-xl bg-slate-100 text-slate-600 hover:bg-orange-600 hover:text-white transition-all active:scale-90 shadow-sm"
                                        title="View Details"
                                      >
                                        <Eye className="h-4 w-4" />
                                      </button>
                                      <button
                                        onClick={() =>
                                          handleCancelEnrollment(enroll.id)
                                        }
                                        className="p-2.5 rounded-xl bg-slate-100 text-orange-600 hover:bg-orange-600 hover:text-white transition-all active:scale-90 shadow-sm"
                                        title="Cancel Enrollment"
                                      >
                                        <X className="h-4 w-4" />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            {enrollments.length === 0 && (
                              <tr>
                                <td
                                  colSpan={8}
                                  className="p-20 text-center text-slate-400 italic font-medium"
                                >
                                  No enrollment applications found.
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Enrollment Details Modal */}
                    {selectedEnrollment && (
                      <div
                        className="fixed inset-0 bg-slate-900/80 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-in fade-in duration-300"
                        onClick={() => setSelectedEnrollment(null)}
                      >
                        <div
                          className="bg-white rounded-[2.5rem] shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-10 border border-slate-200 relative animate-in zoom-in-95 duration-300"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <button
                            onClick={() => setSelectedEnrollment(null)}
                            className="absolute top-6 right-6 p-2 rounded-full bg-slate-100 text-slate-400 hover:bg-orange-600 hover:text-white transition-all active:scale-90"
                          >
                            <X className="h-6 w-6" />
                          </button>

                          <div className="mb-10">
                            <h3 className="text-3xl font-black text-slate-900 tracking-tight">
                              Enrollment{" "}
                              <span className="text-orange-600">Details</span>
                            </h3>
                            <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mt-1">
                              Application Information
                            </p>
                          </div>

                          <div className="space-y-8">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Full Name
                                </p>
                                <p className="text-lg font-black text-slate-900">
                                  {selectedEnrollment.name}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Phone Number
                                </p>
                                <p className="text-lg font-black text-slate-900">
                                  {selectedEnrollment.phone}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Email Address
                                </p>
                                <p className="text-lg font-black text-slate-900">
                                  {selectedEnrollment.email}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Application Type
                                </p>
                                <p className="text-lg font-black text-slate-700">
                                  {selectedEnrollment.course_title
                                    ? "Online Course"
                                    : "Program"}
                                </p>
                              </div>
                              <div className="space-y-1 md:col-span-2">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Program/Course Title
                                </p>
                                <p className="text-xl font-black text-orange-600">
                                  {selectedEnrollment.program_title ||
                                    selectedEnrollment.course_title}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Current Class
                                </p>
                                <p className="text-lg font-black text-slate-900">
                                  {selectedEnrollment.current_class}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Guardian Phone
                                </p>
                                <p className="text-lg font-black text-slate-900">
                                  {selectedEnrollment.guardian_phone || "N/A"}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Admission Month
                                </p>
                                <p className="text-lg font-black text-orange-600">
                                  {selectedEnrollment.admission_month || "N/A"}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  {selectedEnrollment.course_title
                                    ? "Course Fee"
                                    : "Admission Fee"}
                                </p>
                                <p className="text-lg font-black text-emerald-600">
                                  ৳
                                  {selectedEnrollment.fee ||
                                    selectedEnrollment.admission_fee ||
                                    0}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Payment Method
                                </p>
                                <p className="text-lg font-black text-orange-600">
                                  {selectedEnrollment.payment_method || "N/A"}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  Payment Number
                                </p>
                                <p className="text-lg font-black text-slate-900">
                                  {selectedEnrollment.payment_number || "N/A"}
                                </p>
                              </div>
                            </div>

                            <div className="bg-slate-50/50 p-6 rounded-3xl border border-slate-100">
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">
                                Transaction ID / Additional Info
                              </p>
                              <p className="font-mono text-sm text-slate-700 break-all font-bold">
                                {selectedEnrollment.transaction_id || "N/A"}
                              </p>
                            </div>

                            <div className="flex flex-col gap-4 pt-4">
                              {selectedEnrollment.status === "pending" && (
                                <>
                                  {/* For offline students: Show Transfer to Form */}
                                  {!selectedEnrollment.course_id && (
                                    <button
                                      onClick={() => {
                                        setActiveTab("students");
                                        const program = programs.find((p: any) => String(p.id) === String(selectedEnrollment.program_id));
                                        const batch = program?.batches_info?.find((b: any) => String(b.batch_id || b.id) === String(selectedEnrollment.batch_id)) || batches.find((b: any) => String(b.id) === String(selectedEnrollment.batch_id));
                                        setNewStudent((prev: any) => ({
                                          ...prev,
                                          name: selectedEnrollment.name || "",
                                          email: selectedEnrollment.email || selectedEnrollment.gmail || "",
                                          phone: selectedEnrollment.phone || "",
                                          guardian_phone: selectedEnrollment.guardian_phone || "",
                                          address: selectedEnrollment.address || "",
                                          current_class: selectedEnrollment.current_class || program?.target_audience || "",
                                          class: selectedEnrollment.current_class || program?.target_audience || "",
                                          school_name: selectedEnrollment.school_name || "",
                                          college_name: selectedEnrollment.college_name || "",
                                          program_id: selectedEnrollment.program_id || "",
                                          program_title: selectedEnrollment.program_title || program?.title || "",
                                          batch_id: selectedEnrollment.batch_id || "",
                                          batch_days: batch?.batch_days || batch?.days || "",
                                          batch_time: batch?.batch_time || batch?.time || "",
                                          admission_fee: program?.admission_fee || "",
                                          monthly_fee: program?.monthly_fee || "",
                                          admission_month: selectedEnrollment.admission_month || "",
                                          blood_group: selectedEnrollment.blood_group || "",
                                          enrollment_id: selectedEnrollment.id || "",
                                          student_type: "offline"
                                        }));
                                        showAlert("Enrollment info transferred to Offline Registration form.", "success");
                                        setSelectedEnrollment(null);
                                        window.scrollTo({ top: 0, behavior: 'smooth' });
                                      }}
                                      className="w-full bg-blue-600 text-white py-4 rounded-xl font-black uppercase tracking-widest shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-all active:scale-95 flex items-center justify-center gap-2 h-[56px]"
                                    >
                                      <UserPlus className="h-5 w-5" /> Transfer to Form
                                    </button>
                                  )}

                                  {/* For online students: Show Approve Student Form */}
                                  {selectedEnrollment.course_id && (
                                    <button
                                      onClick={async () => {
                                        await handleUpdateEnrollmentStatus(
                                          selectedEnrollment.id,
                                          "approved"
                                        );
                                        setSelectedEnrollment(null);
                                      }}
                                      className="w-full bg-emerald-600 text-white py-4 rounded-xl font-black uppercase tracking-widest shadow-lg shadow-emerald-600/20 hover:bg-emerald-700 transition-all active:scale-95 flex items-center justify-center gap-2 h-[50px]"
                                    >
                                      <CheckCircle className="h-5 w-5" /> Approve Student
                                    </button>
                                  )}
                                </>
                              )}
                              <button
                                onClick={() => {
                                  const text = `Name: ${selectedEnrollment.name}\nPhone: ${selectedEnrollment.phone}\nEmail: ${selectedEnrollment.email}\nProgram/Course: ${selectedEnrollment.program_title || selectedEnrollment.course_title}\nClass: ${selectedEnrollment.current_class}\nFee: ${selectedEnrollment.fee}\nPayment Method: ${selectedEnrollment.payment_method || "N/A"}\nPayment Number: ${selectedEnrollment.payment_number || "N/A"}\nTransaction ID: ${selectedEnrollment.transaction_id || "N/A"}`;
                                  navigator.clipboard.writeText(text);
                                  showAlert("Copied to clipboard!");
                                }}
                                className="w-full bg-slate-800 text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-900 transition-all active:scale-95 flex items-center justify-center gap-3"
                              >
                                <Copy className="h-5 w-5" /> Copy Info
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            {/* Live Classes Tab */}
            {activeTab === "live_classes" && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                {authLoading ? (
                  <TableSkeleton />
                ) : (
                  <>
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div className="relative">
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                          <Video className="h-10 w-10 text-orange-600" />
                          Live <span className="text-orange-600">Classes</span>
                        </h2>
                        <div className="absolute -bottom-2 left-0 w-24 h-1 bg-gradient-to-r from-orange-600 to-orange-400 rounded-full"></div>
                      </div>
                      <button
                        onClick={() => clearForm("live_class")}
                        className="p-3 rounded-2xl bg-white/50 text-slate-400 hover:text-orange-600 hover:bg-white transition-all active:scale-95 shadow-sm border border-white flex items-center gap-2 text-xs font-black uppercase tracking-widest"
                      >
                        <RefreshCw className="h-4 w-4" /> Reset Form
                      </button>
                    </div>

                    <div className="glass p-10 rounded-[2.5rem] border border-white shadow-2xl relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-40 h-40 bg-orange-500/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
                      <h3 className="text-2xl font-black mb-8 text-slate-900 tracking-tight flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-orange-100 text-orange-600">
                          <Video className="h-5 w-5" />
                        </div>
                        Schedule New Session
                      </h3>
                      <form
                        onSubmit={handleAddLiveClass}
                        className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10"
                      >
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Class Title
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Math Batch A - Chapter 5"
                            className="glass-input"
                            value={newLiveClass.title}
                            onChange={(e) =>
                              setNewLiveClass({
                                ...newLiveClass,
                                title: e.target.value,
                              })
                            }
                            required
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Meeting Type
                          </label>
                          <div className="flex gap-4 p-2 bg-slate-50 rounded-xl">
                            <button
                              type="button"
                              onClick={() =>
                                setNewLiveClass({
                                  ...newLiveClass,
                                  is_jitsi: false,
                                })
                              }
                              className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${!newLiveClass.is_jitsi ? "bg-orange-600 text-white shadow-lg" : "text-slate-400 hover:bg-slate-100"}`}
                            >
                              Zoom/Meet
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setNewLiveClass({
                                  ...newLiveClass,
                                  is_jitsi: true,
                                })
                              }
                              className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${newLiveClass.is_jitsi ? "bg-orange-600 text-white shadow-lg" : "text-slate-400 hover:bg-slate-100"}`}
                            >
                              Custom Portal
                            </button>
                          </div>
                        </div>
                        {!newLiveClass.is_jitsi && (
                          <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                              Meeting Link
                            </label>
                            <input
                              type="text"
                              placeholder="Zoom / Google Meet URL"
                              className="glass-input"
                              value={newLiveClass.zoom_link}
                              onChange={(e) =>
                                setNewLiveClass({
                                  ...newLiveClass,
                                  zoom_link: e.target.value,
                                })
                              }
                              required
                            />
                          </div>
                        )}
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Program
                          </label>
                          <select
                            className="glass-select"
                            value={newLiveClass.program_id}
                            onChange={(e) =>
                              setNewLiveClass({
                                ...newLiveClass,
                                program_id: e.target.value,
                                batch_id: "",
                                course_id: "",
                              })
                            }
                          >
                            <option value="">Select Program</option>
                            {programs.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.title}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Target Course (Online)
                          </label>
                          <select
                            className="glass-select"
                            value={newLiveClass.course_id}
                            onChange={(e) =>
                              setNewLiveClass({
                                ...newLiveClass,
                                course_id: e.target.value,
                                batch_id: "",
                              })
                            }
                          >
                            <option value="">
                              Select Course (All Online Students)
                            </option>
                            {courses
                              .filter(
                                (c) =>
                                  !newLiveClass.program_id ||
                                  c.program_id == newLiveClass.program_id,
                              )
                              .map((c) => (
                                <option key={c.id} value={c.id}>
                                  {c.title}
                                </option>
                              ))}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Target Batch (Offline)
                          </label>
                          <select
                            className="glass-select disabled:opacity-50 disabled:cursor-not-allowed"
                            value={newLiveClass.batch_id}
                            onChange={(e) =>
                              setNewLiveClass({
                                ...newLiveClass,
                                batch_id: e.target.value,
                                course_id: "",
                              })
                            }
                            disabled={!newLiveClass.program_id}
                          >
                            <option value="">
                              {newLiveClass.program_id
                                ? "Select Batch (Offline Students)"
                                : "Select Program First"}
                            </option>
                            {newLiveClass.program_id && (
                              <option
                                value="ALL"
                                className="font-black text-orange-600"
                              >
                                ALL BATCHES
                              </option>
                            )}
                            {getFilteredBatches(newLiveClass.program_id).map(
                              (b) => (
                                <option key={b.id} value={b.id}>
                                  {b.name}
                                </option>
                              ),
                            )}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Meeting ID
                          </label>
                          <input
                            type="text"
                            placeholder="Optional ID"
                            className="glass-input"
                            value={newLiveClass.zoom_id}
                            onChange={(e) =>
                              setNewLiveClass({
                                ...newLiveClass,
                                zoom_id: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Meeting Password
                          </label>
                          <input
                            type="text"
                            placeholder="Optional Password"
                            className="glass-input"
                            value={newLiveClass.zoom_password}
                            onChange={(e) =>
                              setNewLiveClass({
                                ...newLiveClass,
                                zoom_password: e.target.value,
                              })
                            }
                          />
                        </div>
                        <button
                          type="submit"
                          className="md:col-span-2 bg-gradient-to-r from-orange-600 to-orange-500 text-white py-5 rounded-2xl font-black uppercase tracking-widest hover:shadow-xl hover:shadow-orange-200 transition-all active:scale-95 flex items-center justify-center gap-3 mt-4"
                        >
                          <Video className="h-6 w-6" /> Create Live Session
                        </button>
                      </form>
                    </div>

                    <div className="glass rounded-[2.5rem] border border-white shadow-2xl overflow-hidden">
                      <div className="hidden md:block overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="border-b border-slate-100/50 bg-slate-50/30">
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Session Title
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Target Audience
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Access Info
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                                Status
                              </th>
                              <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest text-right">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50">
                            {liveClasses.map((lc) => (
                              <tr
                                key={lc.id}
                                className="hover:bg-orange-50/50 transition-colors group"
                              >
                                <td className="p-6">
                                  <div className="font-black text-slate-900 group-hover:text-orange-600 transition-colors">
                                    {lc.title}
                                  </div>
                                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    ID: {lc.id.slice(0, 8)}
                                  </div>
                                </td>
                                <td className="p-6">
                                  <div className="text-sm font-bold text-slate-600">
                                    {lc.batch_id
                                      ? batches.find((b) => b.id == lc.batch_id)
                                          ?.name
                                      : lc.course_id
                                        ? courses.find(
                                            (c) => c.id == lc.course_id,
                                          )?.title
                                        : "All Online Students"}
                                  </div>
                                </td>
                                <td className="p-6">
                                  <div className="space-y-1">
                                    {lc.zoom_id && (
                                      <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                        ID:{" "}
                                        <span className="text-slate-800">
                                          {lc.zoom_id}
                                        </span>
                                      </div>
                                    )}
                                    {lc.zoom_password && (
                                      <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                        Pass:{" "}
                                        <span className="text-slate-800">
                                          {lc.zoom_password}
                                        </span>
                                      </div>
                                    )}
                                    <a
                                      href={lc.zoom_link}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:text-blue-800 flex items-center gap-1 mt-1"
                                    >
                                      Join Link{" "}
                                      <ExternalLink className="h-3 w-3" />
                                    </a>
                                  </div>
                                </td>
                                <td className="p-6">
                                  <span className="px-3 py-1 bg-emerald-50 text-emerald-600 border border-emerald-100 rounded-lg text-[9px] font-black uppercase tracking-widest">
                                    {lc.status}
                                  </span>
                                </td>
                                <td className="p-6 text-right">
                                  <div className="flex justify-end gap-2">
                                    <button
                                      onClick={() =>
                                        navigate(
                                          `/admin/live-class-login?classId=${lc.id}`,
                                        )
                                      }
                                      className="p-2.5 rounded-xl bg-slate-100 text-slate-600 hover:bg-orange-600 hover:text-white transition-all active:scale-90 shadow-sm flex items-center gap-2 text-[10px] font-black uppercase tracking-widest px-4"
                                    >
                                      <Video className="h-4 w-4" /> Studio
                                    </button>
                                    <button
                                      onClick={() =>
                                        handleDeleteLiveClass(lc.id)
                                      }
                                      className="p-2.5 rounded-xl bg-slate-100 text-orange-600 hover:bg-orange-600 hover:text-white transition-all active:scale-90 shadow-sm"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                            {liveClasses.length === 0 && (
                              <tr>
                                <td
                                  colSpan={5}
                                  className="p-20 text-center text-slate-400 italic font-medium"
                                >
                                  No live classes scheduled.
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>

                      {/* Mobile Cards */}
                      <div className="md:hidden divide-y divide-slate-100/50">
                        {liveClasses.map((lc) => (
                          <div
                            key={lc.id}
                            className="p-6 space-y-4 hover:bg-orange-50/50 transition-colors"
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-black text-slate-900">
                                  {lc.title}
                                </h4>
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                                  {lc.batch_id
                                    ? batches.find((b) => b.id == lc.batch_id)
                                        ?.name
                                    : lc.course_id
                                      ? courses.find(
                                          (c) => c.id == lc.course_id,
                                        )?.title
                                      : "All Online Students"}
                                </p>
                              </div>
                              <span className="px-3 py-1 bg-emerald-50 text-emerald-600 border border-emerald-100 rounded-lg text-[9px] font-black uppercase tracking-widest">
                                {lc.status}
                              </span>
                            </div>
                            <div className="flex flex-wrap gap-4">
                              {lc.zoom_id && (
                                <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                  ID:{" "}
                                  <span className="text-slate-800">
                                    {lc.zoom_id}
                                  </span>
                                </div>
                              )}
                              {lc.zoom_password && (
                                <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                  Pass:{" "}
                                  <span className="text-slate-800">
                                    {lc.zoom_password}
                                  </span>
                                </div>
                              )}
                            </div>
                            <div className="flex items-center justify-between pt-2">
                              <a
                                href={lc.zoom_link}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:text-blue-800 flex items-center gap-1"
                              >
                                Join Link <ExternalLink className="h-3 w-3" />
                              </a>
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() =>
                                    navigate(
                                      `/admin/live-class-login?classId=${lc.id}`,
                                    )
                                  }
                                  className="p-2 rounded-xl bg-slate-100 text-slate-600 hover:bg-orange-600 hover:text-white transition-all active:scale-90 shadow-sm"
                                >
                                  <Video className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => handleDeleteLiveClass(lc.id)}
                                  className="p-2 rounded-xl bg-slate-100 text-orange-600 hover:bg-orange-600 hover:text-white transition-all active:scale-90 shadow-sm"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Chapters Tab */}
            {activeTab === "chapters" && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                {authLoading ? (
                  <TableSkeleton />
                ) : (
                  <>
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div className="relative">
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                          <BookOpen className="h-10 w-10 text-orange-600" />
                          Chapters{" "}
                          <span className="text-orange-600">Management</span>
                        </h2>
                        <div className="absolute -bottom-2 left-0 w-24 h-1 bg-gradient-to-r from-orange-600 to-orange-400 rounded-full"></div>
                      </div>
                      <button
                        onClick={() => clearForm("chapter")}
                        className="p-3 rounded-2xl bg-white/50 text-slate-400 hover:text-orange-600 hover:bg-white transition-all active:scale-95 shadow-sm border border-white flex items-center gap-2 text-xs font-black uppercase tracking-widest"
                      >
                        <RefreshCw className="h-4 w-4" /> Reset Form
                      </button>
                    </div>

                    <div className="glass p-10 rounded-[2.5rem] border border-white shadow-2xl relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-40 h-40 bg-orange-500/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
                      <h3 className="text-2xl font-black mb-8 text-slate-900 tracking-tight flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-orange-100 text-orange-600">
                          <BookOpen className="h-5 w-5" />
                        </div>
                        Add New Chapter
                      </h3>
                      <form
                        onSubmit={handleAddChapter}
                        className="grid grid-cols-1 md:grid-cols-4 gap-6 relative z-10"
                      >
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Program (Offline)
                          </label>
                          <select
                            className="glass-select"
                            value={newChapter.program_id}
                            onChange={(e) =>
                              setNewChapter({
                                ...newChapter,
                                program_id: e.target.value,
                                batch_id: "",
                                course_id: "",
                              })
                            }
                          >
                            <option value="">Select Program</option>
                            {programs.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.title}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Batch (Offline)
                          </label>
                          <select
                            className="glass-select disabled:opacity-50 disabled:cursor-not-allowed"
                            value={newChapter.batch_id}
                            onChange={(e) =>
                              setNewChapter({
                                ...newChapter,
                                batch_id: e.target.value,
                              })
                            }
                            disabled={!newChapter.program_id}
                          >
                            <option value="">
                              {newChapter.program_id
                                ? "Select Batch"
                                : "Select Program First"}
                            </option>
                            {newChapter.program_id && (
                              <option
                                value="all"
                                className="font-bold text-orange-600"
                              >
                                All Batches in Program
                              </option>
                            )}
                            {getFilteredBatches(newChapter.program_id).map(
                              (b) => (
                                <option key={b.id} value={b.id}>
                                  {b.name}
                                </option>
                              ),
                            )}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Online Course
                          </label>
                          <select
                            className="glass-select"
                            value={newChapter.course_id}
                            onChange={(e) =>
                              setNewChapter({
                                ...newChapter,
                                course_id: e.target.value,
                                program_id: "",
                                batch_id: "",
                              })
                            }
                          >
                            <option value="">Select Online Course</option>
                            {courses.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.title}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Chapter Title
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Chapter 1: Introduction"
                            className="glass-input"
                            value={newChapter.title}
                            onChange={(e) =>
                              setNewChapter({
                                ...newChapter,
                                title: e.target.value,
                              })
                            }
                            required
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Content/Topic
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Basics of Motion"
                            className="glass-input"
                            value={newChapter.content}
                            onChange={(e) =>
                              setNewChapter({
                                ...newChapter,
                                content: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="md:col-span-2 space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Description
                          </label>
                          <textarea
                            placeholder="Brief overview of the chapter..."
                            className="glass-input h-24 resize-none"
                            value={newChapter.description}
                            onChange={(e) =>
                              setNewChapter({
                                ...newChapter,
                                description: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Status
                          </label>
                          <select
                            className="glass-select"
                            value={newChapter.status}
                            onChange={(e) =>
                              setNewChapter({
                                ...newChapter,
                                status: e.target.value,
                              })
                            }
                          >
                            <option value="active">Active</option>
                            <option value="complete">Complete</option>
                            <option value="coming_soon">Coming Soon</option>
                          </select>
                        </div>
                        <button
                          type="submit"
                          className="md:col-span-4 bg-gradient-to-r from-orange-600 to-orange-500 text-white py-5 rounded-2xl font-black uppercase tracking-widest hover:shadow-xl hover:shadow-orange-200 transition-all active:scale-95 flex items-center justify-center gap-3 mt-4"
                        >
                          <PlusCircle className="h-6 w-6" /> Add Chapter
                        </button>
                      </form>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {chapters.map((chapter) => (
                        <div
                          key={chapter.id}
                          className="glass p-8 rounded-[2rem] border border-white shadow-xl hover:shadow-2xl transition-all group relative overflow-hidden"
                        >
                          <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/5 rounded-full -mr-12 -mt-12 blur-2xl group-hover:bg-orange-500/10 transition-colors"></div>
                          <div className="flex justify-between items-start relative z-10">
                            <div className="space-y-3">
                              <div className="flex items-center gap-3">
                                <h4 className="font-black text-xl text-slate-900 group-hover:text-orange-600 transition-colors">
                                  {chapter.title}
                                </h4>
                                {chapter.status === "coming_soon" && (
                                  <span className="bg-orange-100 text-orange-600 text-[9px] px-2 py-1 rounded-lg font-black uppercase tracking-wider border border-orange-200">
                                    Coming Soon
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-slate-500 font-medium line-clamp-2">
                                {chapter.content}
                              </p>
                              <div className="flex flex-wrap items-center gap-2 pt-2">
                                {chapter.program_id && (
                                  <span className="bg-slate-100 text-slate-600 text-[10px] px-3 py-1 rounded-full font-black uppercase tracking-widest border border-slate-200">
                                    Offline (
                                    {batches.find((b) => b.id == chapter.batch_id)
                                      ?.name || "All Batches"}
                                    )
                                  </span>
                                )}
                                {chapter.course_id && (
                                  <span className="bg-blue-50 text-blue-600 text-[10px] px-3 py-1 rounded-full font-black uppercase tracking-widest border border-blue-200">
                                    Online:{" "}
                                    {courses.find((c) => c.id == chapter.course_id)
                                      ?.title || "Unknown"}
                                  </span>
                                )}
                                {!chapter.program_id && !chapter.course_id && (
                                  <span className="bg-green-50 text-green-600 text-[10px] px-3 py-1 rounded-full font-black uppercase tracking-widest border border-green-200">
                                    Visible to All
                                  </span>
                                )}
                                <select
                                  value={chapter.status}
                                  onChange={async (e) => {
                                    const newStatus = e.target.value;
                                    try {
                                      const res = await fetch(
                                        `/api/chapters/${chapter.id}`,
                                        {
                                          method: "PUT",
                                          headers: {
                                            "Content-Type": "application/json",
                                            Authorization: `Bearer ${token}`,
                                          },
                                          body: JSON.stringify({
                                            ...chapter,
                                            status: newStatus,
                                          }),
                                        },
                                      );
                                      if (res.ok) {
                                        fetchChapters();
                                        showAlert("Status updated");
                                      }
                                    } catch (e) {
                                      console.error(e);
                                    }
                                  }}
                                  className={`text-[9px] font-black uppercase tracking-widest px-2 py-1 rounded-lg border transition-all cursor-pointer ${
                                    chapter.status === "complete"
                                      ? "bg-green-100 text-green-600 border-green-200"
                                      : chapter.status === "active"
                                        ? "bg-blue-100 text-blue-600 border-blue-200"
                                        : "bg-orange-100 text-orange-600 border-orange-200"
                                  }`}
                                >
                                  <option value="coming_soon">
                                    Coming Soon
                                  </option>
                                  <option value="active">Active</option>
                                  <option value="complete">Complete</option>
                                </select>
                              </div>
                            </div>
                            <button
                              onClick={() => handleDeleteChapter(chapter.id)}
                              className="p-3 rounded-xl bg-slate-100 text-orange-600 hover:bg-orange-600 hover:text-white transition-all active:scale-90 shadow-sm"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                      {chapters.length === 0 && (
                        <div className="md:col-span-3 p-20 text-center glass rounded-[2.5rem] border border-white text-slate-400 italic font-medium">
                          No chapters added yet.
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Exam History Tab */}
            {activeTab === "exam_history" && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                {authLoading ? (
                  <TableSkeleton />
                ) : (
                  <>
                    <div className="relative mb-6">
                      <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                        <Archive className="h-10 w-10 text-orange-600" />
                        Exam <span className="text-orange-600">History</span>
                      </h2>
                      <div className="absolute -bottom-2 left-0 w-24 h-1 bg-gradient-to-r from-orange-600 to-orange-400 rounded-full"></div>
                    </div>

                    {resultHistories.length === 0 ? (
                      <div className="text-center p-20 glass rounded-[2.5rem] border border-slate-100 text-slate-400 font-bold uppercase tracking-widest text-sm">
                        No published histories found.
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {resultHistories.map((history) => (
                          <div key={history.id} className="glass p-8 rounded-[2rem] border border-white shadow-xl relative overflow-hidden group">
                            <div className="flex justify-between items-start relative z-10 mb-6">
                              <div>
                                <h4 className="font-black text-xl text-slate-900 leading-tight">
                                  {history.exam_name}
                                </h4>
                                <div className="text-xs font-bold text-slate-500 mt-1 uppercase tracking-widest">
                                  Batch: {batches.find(b => b.id === history.batch_id)?.name || "Unknown"}
                                </div>
                              </div>
                              <button
                                onClick={() => handleDeleteResultHistory(history.id)}
                                className="p-2 rounded-xl bg-slate-100 text-red-500 hover:bg-red-500 hover:text-white transition-all active:scale-90"
                                title="Delete History (does not affect actual exam or results)"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                            
                            <div className="space-y-3 relative z-10 text-sm font-medium">
                              <div className="flex justify-between border-b border-slate-100 pb-2">
                                <span className="text-slate-500">Highest Marks</span>
                                <span className="font-black text-orange-600">{history.highest_marks}</span>
                              </div>
                              <div className="flex justify-between border-b border-slate-100 pb-2">
                                <span className="text-slate-500">Students Evaluated</span>
                                <span className="font-black text-slate-700">{history.total_students}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-500">Published On</span>
                                <span className="font-bold text-slate-700">
                                  {history.published_at ? new Date(history.published_at).toLocaleDateString() : 'N/A'}
                                </span>
                              </div>
                            </div>

                            <div className="mt-6 pt-4 border-t border-slate-100 relative z-10">
                              <div className="flex justify-between items-center mb-2">
                                <div className="text-[10px] uppercase font-black tracking-widest text-slate-400">
                                  {expandedHistoryId === history.id ? "Full Results" : "Top 3 Students"}
                                </div>
                                <button
                                  onClick={() => setExpandedHistoryId(expandedHistoryId === history.id ? null : history.id)}
                                  className="text-[10px] uppercase font-black tracking-widest text-orange-600 hover:text-orange-700"
                                >
                                  {expandedHistoryId === history.id ? "Show Less" : "View All"}
                                </button>
                              </div>
                              <div className={`space-y-2 ${expandedHistoryId === history.id ? "max-h-60 overflow-y-auto pr-2 custom-scrollbar" : ""}`}>
                                {(() => {
                                  try {
                                    const parsedContent = JSON.parse(history.content);
                                    const studentsToShow = expandedHistoryId === history.id ? parsedContent : parsedContent.slice(0, 3);
                                    return studentsToShow.map((student: any) => (
                                      <div key={student.roll_number} className="flex justify-between items-center text-xs p-2 hover:bg-slate-50 rounded-lg transition-colors">
                                        <div className="font-bold text-slate-700 mr-2 flex items-center gap-2">
                                          <span className="w-5 h-5 flex items-center justify-center bg-slate-100 rounded text-[10px] text-slate-500">#{student.merit_position}</span>
                                          <span className="truncate max-w-[120px]" title={student.student_name}>{student.student_name}</span>
                                          <span className="text-[10px] text-slate-400">({student.roll_number})</span>
                                        </div>
                                        <div className="font-black text-indigo-600 tabular-nums">
                                          {student.marks}
                                        </div>
                                      </div>
                                    ));
                                  } catch (e) {
                                    return <div className="text-xs text-slate-400 italic">Data corrupt</div>;
                                  }
                                })()}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            {/* Exams Tab */}
            {activeTab === "exams" && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                {authLoading ? (
                  <TableSkeleton />
                ) : (
                  <>
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div className="relative">
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                          <FileText className="h-10 w-10 text-orange-600" />
                          Upcoming{" "}
                          <span className="text-orange-600">Exams</span>
                        </h2>
                        <div className="absolute -bottom-2 left-0 w-24 h-1 bg-gradient-to-r from-orange-600 to-orange-400 rounded-full"></div>
                      </div>
                      <button
                        onClick={() => clearForm("exam")}
                        className="p-3 rounded-2xl bg-white/50 text-slate-400 hover:text-orange-600 hover:bg-white transition-all active:scale-95 shadow-sm border border-white flex items-center gap-2 text-xs font-black uppercase tracking-widest"
                      >
                        <RefreshCw className="h-4 w-4" /> Reset Form
                      </button>
                    </div>

                    {/* Manage Categories Section */}
                    <div className="glass p-10 rounded-[2.5rem] border border-white shadow-2xl relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-40 h-40 bg-teal-500/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
                      <h3 className="text-2xl font-black mb-8 text-slate-900 tracking-tight flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-teal-100 text-teal-600">
                          <Tag className="h-5 w-5" />
                        </div>
                        Manage Categories
                      </h3>
                      <form onSubmit={handleAddExamCategory} className="flex flex-col md:flex-row gap-4 items-end relative z-10">
                        <div className="flex-1 w-full space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Category Name</label>
                          <input 
                            type="text"
                            placeholder="e.g. Model Test, Final, Weekly"
                            className="glass-input"
                            value={newExamCategory}
                            onChange={(e) => setNewExamCategory(e.target.value)}
                            required
                          />
                        </div>
                        <button 
                          type="submit"
                          className="w-full md:w-auto bg-teal-600 text-white px-10 py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-teal-700 transition-all active:scale-95 shadow-lg shadow-teal-100 flex items-center justify-center gap-2"
                        >
                          <PlusCircle className="h-6 w-6" /> Add Category
                        </button>
                      </form>
                      
                      <div className="flex flex-wrap gap-3 mt-8 relative z-10">
                        {examCategories.length === 0 && (
                          <p className="text-slate-400 italic text-sm font-medium">No categories added yet.</p>
                        )}
                        {examCategories.map(cat => (
                          <div key={cat.id} className="flex items-center gap-2 bg-teal-50 text-teal-600 px-4 py-2 rounded-xl border border-teal-100 group transition-all hover:bg-teal-100">
                            <span className="text-xs font-black uppercase tracking-widest">{cat.name}</span>
                            <button 
                              onClick={() => handleDeleteExamCategory(cat.id)}
                              className="p-1 hover:bg-teal-200 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                            >
                              <X className="h-3.5 w-3.5 text-teal-400 group-hover:text-teal-600" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="glass p-10 rounded-[2.5rem] border border-white shadow-2xl relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-40 h-40 bg-orange-500/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
                      <h3 className="text-2xl font-black mb-8 text-slate-900 tracking-tight flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-orange-100 text-orange-600">
                          <FileText className="h-5 w-5" />
                        </div>
                        Schedule New Exam
                      </h3>
                      <form
                        onSubmit={handleAddExam}
                        className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6 relative z-10"
                      >
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Program
                          </label>
                          <select
                            className="glass-select"
                            value={newExam.program_id}
                            onChange={(e) =>
                              setNewExam((prev) => ({
                                ...prev,
                                program_id: e.target.value,
                                batch_id: "",
                              }))
                            }
                            required
                          >
                            <option value="">Select Program</option>
                            {programs.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.title}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Batch
                          </label>
                          <select
                            className="glass-select"
                            value={newExam.batch_id}
                            onChange={(e) =>
                              setNewExam((prev) => ({
                                ...prev,
                                batch_id: e.target.value,
                              }))
                            }
                            disabled={!newExam.program_id}
                            required
                          >
                            <option value="">
                              {newExam.program_id
                                ? "Select Batch"
                                : "Select Program First"}
                            </option>
                            {newExam.program_id && (
                              <option
                                value="all"
                                className="font-black text-orange-600"
                              >
                                ALL BATCHES
                              </option>
                            )}
                            {getFilteredBatches(newExam.program_id).map((b) => (
                              <option key={b.id} value={b.id}>
                                {b.name}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Exam Name
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Midterm Math"
                            className="glass-input"
                            value={newExam.exam_name}
                            onChange={(e) =>
                              setNewExam((prev) => ({
                                ...prev,
                                exam_name: e.target.value,
                              }))
                            }
                            required
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Exam Date
                          </label>
                          <input
                            type="date"
                            className="glass-input"
                            value={newExam.exam_date}
                            onChange={(e) =>
                              setNewExam((prev) => ({
                                ...prev,
                                exam_date: e.target.value,
                              }))
                            }
                            required
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Category
                          </label>
                          <select
                            className="glass-select"
                            value={newExam.category}
                            onChange={(e) =>
                              setNewExam((prev) => ({
                                ...prev,
                                category: e.target.value,
                              }))
                            }
                            required
                          >
                            <option value="">Select Category</option>
                            {examCategories.map((cat) => (
                              <option key={cat.id} value={cat.name}>
                                {cat.name}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Question PDF URL
                          </label>
                          <input
                            type="text"
                            placeholder="https://..."
                            className="glass-input"
                            value={newExam.question_pdf}
                            onChange={(e) =>
                              setNewExam((prev) => ({
                                ...prev,
                                question_pdf: e.target.value,
                              }))
                            }
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Answer PDF URL
                          </label>
                          <input
                            type="text"
                            placeholder="https://..."
                            className="glass-input"
                            value={newExam.answer_pdf}
                            onChange={(e) =>
                              setNewExam((prev) => ({
                                ...prev,
                                answer_pdf: e.target.value,
                              }))
                            }
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                            Total Marks
                          </label>
                          <input
                            type="number"
                            placeholder="100"
                            className="glass-input"
                            value={newExam.total_marks || ""}
                            onChange={(e) =>
                              setNewExam((prev) => ({
                                ...prev,
                                total_marks: e.target.value,
                              }))
                            }
                            required
                          />
                        </div>
                        <button
                          type="submit"
                          className="lg:mt-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:shadow-xl hover:shadow-orange-200 transition-all active:scale-95 flex items-center justify-center gap-3"
                        >
                          <PlusCircle className="h-6 w-6" /> Schedule
                        </button>
                      </form>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {exams.map((exam) => (
                        <div
                          key={exam.id}
                          className="glass p-8 rounded-[2rem] border border-white shadow-xl hover:shadow-2xl transition-all group relative overflow-hidden"
                        >
                          <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/5 rounded-full -mr-12 -mt-12 blur-2xl group-hover:bg-orange-500/10 transition-colors"></div>
                          <div className="flex justify-between items-start relative z-10 mb-6">
                            <div>
                              <h4 className="font-black text-xl text-slate-900 group-hover:text-orange-600 transition-colors">
                                {exam.exam_name}
                              </h4>
                              <div className="flex items-center gap-2 mt-2">
                                <Calendar className="h-3 w-3 text-orange-600" />
                                <span className="text-sm font-bold text-slate-500">
                                  {exam.exam_date}
                                </span>
                              </div>
                              <div className="flex flex-wrap gap-2 mt-3">
                                {exam.question_pdf && (
                                  <a
                                    href={exam.question_pdf}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-[10px] font-black uppercase tracking-widest bg-slate-100 text-slate-600 px-2 py-1 rounded-lg hover:bg-slate-200 transition-colors"
                                  >
                                    Question PDF
                                  </a>
                                )}
                                {exam.answer_pdf && (
                                  <a
                                    href={exam.answer_pdf}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-[10px] font-black uppercase tracking-widest bg-green-100 text-green-600 px-2 py-1 rounded-lg hover:bg-green-200 transition-colors"
                                  >
                                    Answer PDF
                                  </a>
                                )}
                              </div>
                            </div>
                            <button
                              onClick={() => handleDeleteExam(exam.id)}
                              className="p-3 rounded-xl bg-slate-100 text-orange-600 hover:bg-orange-600 hover:text-white transition-all active:scale-90 shadow-sm"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>

                          <div className="flex flex-wrap gap-2 mb-6 relative z-10">
                            <span className="bg-slate-100 text-slate-600 text-[10px] px-3 py-1 rounded-full font-black uppercase tracking-widest border border-slate-200">
                              Batch:{" "}
                              {exam.batch_id === "all"
                                ? "All Batches"
                                : batchMap.get(String(exam.batch_id))?.name || "Unknown"}
                            </span>
                            {exam.category && (
                              <span className="bg-orange-100 text-orange-600 text-[10px] px-3 py-1 rounded-full font-black uppercase tracking-widest border border-orange-200">
                                {exam.category}
                              </span>
                            )}
                          </div>

                          <div className="pt-6 border-t border-slate-100/50 flex justify-between items-center relative z-10">
                            <div className="flex items-center gap-2">
                              {exam.published ? (
                                <span className="flex items-center gap-1.5 text-green-600 text-[10px] font-black uppercase tracking-widest">
                                  <CheckCircle2 className="h-3.5 w-3.5" />{" "}
                                  Published
                                </span>
                              ) : (
                                <span className="flex items-center gap-1.5 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                                  <Clock className="h-3.5 w-3.5" /> Draft
                                </span>
                              )}
                            </div>
                            {!exam.published && (
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleMarkAttendance(exam)}
                                  className="p-2.5 rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200 transition-all active:scale-90 shadow-sm flex items-center gap-2 text-[10px] font-black uppercase tracking-widest px-4"
                                >
                                  <UserCheck className="h-3.5 w-3.5" />{" "}
                                  Attendance
                                </button>
                                <button
                                  onClick={() => handlePublishResults(exam.id)}
                                  className="p-2.5 rounded-xl bg-orange-600 text-white hover:bg-orange-700 transition-all active:scale-90 shadow-sm text-[10px] font-black uppercase tracking-widest px-4"
                                >
                                  Publish
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                      {exams.length === 0 && (
                        <div className="md:col-span-3 p-20 text-center glass rounded-[2.5rem] border border-white text-slate-400 italic font-medium">
                          No exams scheduled yet.
                        </div>
                      )}
                    </div>

                    {/* Attendance Modal */}
                    <AnimatePresence>
                      {markingAttendance && (
                        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                          <motion.div
                            initial={{ opacity: 0, scale: 0.95, y: 20 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95, y: 20 }}
                            className="glass rounded-[2.5rem] border border-white shadow-2xl w-full max-w-2xl overflow-hidden relative"
                          >
                            <div className="absolute top-0 right-0 w-40 h-40 bg-orange-500/10 rounded-full -mr-20 -mt-20 blur-3xl"></div>

                            <div className="bg-gradient-to-r from-orange-600 to-orange-500 p-8 text-white flex justify-between items-center relative z-10">
                              <div>
                                <h3 className="text-2xl font-black tracking-tight">
                                  Exam Attendance
                                </h3>
                                <p className="text-orange-100 text-sm font-bold mt-1 opacity-90">
                                  {markingAttendance.exam_name}{" "}
                                  <span className="mx-2 opacity-50">|</span>{" "}
                                  {markingAttendance.batch_name}
                                </p>
                              </div>
                              <button
                                onClick={() => setMarkingAttendance(null)}
                                className="p-3 bg-white/20 hover:bg-white/30 rounded-2xl transition-all active:scale-90"
                              >
                                <XCircle className="h-6 w-6" />
                              </button>
                            </div>

                            <div className="p-8 max-h-[60vh] overflow-y-auto relative z-10 custom-scrollbar">
                              <div className="space-y-4">
                                {attendanceList.length === 0 ? (
                                  <div className="text-center py-12">
                                    <div className="p-4 bg-slate-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-slate-400">
                                      <Users className="h-8 w-8" />
                                    </div>
                                    <p className="text-slate-400 font-black uppercase tracking-widest text-xs">
                                      No students found in this batch
                                    </p>
                                  </div>
                                ) : (
                                  attendanceList.map((student) => (
                                    <div
                                      key={student.id}
                                      className="flex items-center justify-between p-4 sm:p-5 bg-white/40 rounded-2xl border border-white/60 hover:bg-white/60 transition-all group gap-2 sm:gap-4"
                                    >
                                      <div className="flex items-center gap-3 sm:gap-4">
                                        <div
                                          className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center text-white font-black text-base sm:text-lg shadow-lg transition-all group-hover:scale-110 shrink-0 ${student.attended ? "bg-gradient-to-br from-green-500 to-emerald-600 shadow-green-100" : "bg-gradient-to-br from-slate-300 to-slate-400 shadow-slate-100"}`}
                                        >
                                          {student.name.charAt(0)}
                                        </div>
                                        <div className="min-w-0">
                                          <div className="font-black text-slate-900 group-hover:text-orange-600 transition-colors truncate text-sm sm:text-base">
                                            {student.name}
                                          </div>
                                          <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-0.5 truncate">
                                            ROLL: {student.roll_number}
                                          </div>
                                        </div>
                                      </div>
                                      <div className="flex items-center shrink-0">
                                        <button
                                          onClick={() => {
                                            setAttendanceList((prev) =>
                                              prev.map((s) =>
                                                s.id === student.id
                                                  ? {
                                                      ...s,
                                                      attended: !s.attended,
                                                    }
                                                  : s,
                                              ),
                                            );
                                          }}
                                          className={`p-2 sm:p-3 rounded-xl sm:rounded-2xl transition-all border-2 flex items-center justify-center gap-1 sm:gap-2 ${
                                            student.attended
                                              ? "bg-green-500 border-green-500 text-white shadow-lg shadow-green-200"
                                              : "bg-rose-600 border-rose-600 text-white shadow-lg shadow-rose-200"
                                          }`}
                                        >
                                          {student.attended ? (
                                            <CheckCircle2 className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                                          ) : (
                                            <XCircle className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                                          )}
                                          <span className="hidden sm:inline-block font-black uppercase tracking-widest text-xs">
                                            {student.attended
                                              ? "Present"
                                              : "Absent"}
                                          </span>
                                        </button>
                                      </div>
                                    </div>
                                  ))
                                )}
                              </div>
                            </div>

                            <div className="p-8 bg-slate-50/50 border-t border-white/60 flex justify-end relative z-10">
                              <button
                                onClick={handleSaveAttendance}
                                className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-800 transition-all active:scale-95 shadow-xl shadow-slate-200"
                              >
                                Close Portal
                              </button>
                            </div>
                          </motion.div>
                        </div>
                      )}
                    </AnimatePresence>
                  </>
                )}
              </div>
            )}

            {/* Student Search Tab */}
            {activeTab === "studentSearch" && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div className="relative">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                      <Search className="h-10 w-10 text-orange-600" />
                      Student <span className="text-orange-600">Search</span>
                    </h2>
                    <div className="absolute -bottom-2 left-0 w-24 h-1 bg-gradient-to-r from-orange-600 to-orange-400 rounded-full"></div>
                  </div>
                  <button
                    onClick={() => clearForm("search")}
                    className="p-3 rounded-2xl bg-white/50 text-slate-400 hover:text-orange-600 hover:bg-white transition-all active:scale-95 shadow-sm border border-white flex items-center gap-2 text-xs font-black uppercase tracking-widest"
                  >
                    <RefreshCw className="h-4 w-4" /> Reset Search
                  </button>
                </div>

                <div className="glass p-10 rounded-[2.5rem] border border-white shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-40 h-40 bg-orange-500/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
                  <h3 className="text-2xl font-black mb-8 text-slate-900 tracking-tight flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-orange-100 text-orange-600">
                      <Search className="h-5 w-5" />
                    </div>
                    Find Student Record
                  </h3>
                  <form
                    onSubmit={handleStudentSearch}
                    className="grid grid-cols-1 md:grid-cols-5 gap-6 relative z-10"
                  >
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                        Program
                      </label>
                      <select
                        className="glass-select"
                        value={searchQuery.program_id}
                        onChange={(e) =>
                          setSearchQuery({
                            ...searchQuery,
                            program_id: e.target.value,
                            batch_id: "",
                          })
                        }
                      >
                        <option value="">Select Program</option>
                        {programs.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.title}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                        Class
                      </label>
                      <select
                        className="glass-select"
                        value={searchQuery.class}
                        onChange={(e) =>
                          setSearchQuery({
                            ...searchQuery,
                            class: e.target.value,
                          })
                        }
                      >
                        <option value="">Select Class</option>
                        {Array.from(
                          new Set(
                            batches
                              .filter(
                                (b) =>
                                  !searchQuery.program_id ||
                                  String(b.program_id) === String(searchQuery.program_id),
                              )
                              .map(
                                (b) => b.class || b.class_name || b.batch_class,
                              )
                              .filter(Boolean),
                          ),
                        ).map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                        Batch
                      </label>
                      <select
                        className="glass-select"
                        value={searchQuery.batch_id}
                        onChange={(e) =>
                          setSearchQuery({
                            ...searchQuery,
                            batch_id: e.target.value,
                          })
                        }
                        disabled={!searchQuery.program_id}
                      >
                        <option value="">
                          {searchQuery.program_id
                            ? "Select Batch"
                            : "Select Program First"}
                        </option>
                        {getFilteredBatches(searchQuery.program_id)
                          .filter(
                            (b) =>
                              !searchQuery.class ||
                              b.class === searchQuery.class ||
                              b.class_name === searchQuery.class ||
                              b.batch_class === searchQuery.class,
                          )
                          .map((b) => (
                            <option key={b.id} value={b.id}>
                              {b.name}
                            </option>
                          ))}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">
                        Roll Number
                      </label>
                      <input
                        type="text"
                        placeholder="Enter Roll Number"
                        className="glass-input"
                        value={searchQuery.roll_number}
                        onChange={(e) =>
                          setSearchQuery({
                            ...searchQuery,
                            roll_number: e.target.value,
                          })
                        }
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            handleStudentSearch();
                          }
                        }}
                        required
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => handleStudentSearch()}
                      disabled={isSearching}
                      className="lg:mt-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:shadow-xl hover:shadow-orange-200 transition-all active:scale-95 flex items-center justify-center gap-3 disabled:opacity-50"
                    >
                      {isSearching ? (
                        "Searching..."
                      ) : (
                        <>
                          <Search className="h-6 w-6" /> Search
                        </>
                      )}
                    </button>
                  </form>
                </div>

                {searchResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass p-10 rounded-[2.5rem] border border-white shadow-2xl relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-80 h-80 bg-orange-500/5 rounded-full blur-3xl -mr-40 -mt-40"></div>
                    <div className="absolute bottom-0 left-0 w-80 h-80 bg-orange-500/5 rounded-full blur-3xl -ml-40 -mb-40"></div>

                    <div className="flex flex-col lg:flex-row justify-between items-start mb-10 gap-10 relative z-10">
                      <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
                        <div className="w-32 h-32 rounded-[2rem] overflow-hidden border-4 border-white shadow-xl flex-shrink-0 bg-gradient-to-br from-orange-100 to-orange-50 flex items-center justify-center text-4xl font-black text-orange-600 relative group">
                          {searchResult.profile_pic ? (
                            <img
                              src={searchResult.profile_pic}
                              alt={searchResult.name}
                              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            searchResult.name.charAt(0)
                          )}
                          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors"></div>
                        </div>
                        <div className="text-center md:text-left">
                          <h2 className="text-4xl font-black text-slate-900 tracking-tight">
                            {searchResult.name}
                          </h2>
                          <p className="text-slate-500 font-bold mt-1">
                            {searchResult.email}
                          </p>

                          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-x-12 gap-y-6">
                            <div className="space-y-1">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                                Contact Information
                              </span>
                              <div className="flex flex-col gap-2">
                                <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                  <Phone className="h-3.5 w-3.5 text-orange-600" />{" "}
                                  {searchResult.phone}
                                </div>
                                <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                  <ShieldCheck className="h-3.5 w-3.5 text-orange-600" />{" "}
                                  Guardian:{" "}
                                  {searchResult.guardian_phone || "N/A"}
                                </div>
                              </div>
                            </div>
                            <div className="space-y-1">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                                Academic Details
                              </span>
                              <div className="flex flex-col gap-2">
                                <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                  <BookOpen className="h-3.5 w-3.5 text-orange-600" />{" "}
                                  Class: {searchResult.current_class || "N/A"}
                                </div>
                                <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                  <Clock className="h-3.5 w-3.5 text-orange-600" />{" "}
                                  {searchResult.student_type === "online" ? "Online Student/App Based" : (
                                    <>
                                      {searchResult.batch_days || "N/A"} •{" "}
                                      {searchResult.batch_time || "N/A"}
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="space-y-1">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                                Registration Info
                              </span>
                              <div className="flex flex-col gap-2">
                                <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                  <Calendar className="h-3.5 w-3.5 text-orange-600" />{" "}
                                  Registered:{" "}
                                  {searchResult.created_at
                                    ? format(
                                        parseISO(searchResult.created_at),
                                        "dd MMM yyyy",
                                      )
                                    : "N/A"}
                                </div>
                                <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                  <User className="h-3.5 w-3.5 text-orange-600" />{" "}
                                  Added By:{" "}
                                  <span className="text-orange-600">
                                    {searchResult.added_by || "Admin"}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="space-y-1">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                                Financial Status
                              </span>
                              <div className="flex flex-col gap-2">
                                <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                  <CreditCard className="h-3.5 w-3.5 text-orange-600" />{" "}
                                  {searchResult.student_type === "online" ? "Course Fee" : "Monthly"}: ৳{searchResult.student_type === "online" ? (searchResult.fee || 0) : (searchResult.monthly_fee || 0)}
                                </div>
                                <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                  <CheckCircle2 className="h-3.5 w-3.5 text-green-600" />{" "}
                                  Total Paid: ৳{searchResult.student_type === "online" 
                                      ? (((searchResult.payments || [])?.reduce((acc: number, p: any) => acc + (Number(p.amount) || 0), 0) || 0) + ((searchResult.enrollments || [])?.filter((e: any) => e.status === "approved" || e.status === "contacted").reduce((acc: number, e: any) => acc + (Number(e.fee) || 0), 0) || 0))
                                      : (searchResult.paid_amount || 0)}
                                </div>
                              </div>
                            </div>
                          </div>

                          {searchResult.initial_password && (
                            <div className="mt-8 p-4 bg-orange-50 rounded-2xl border border-orange-100 inline-flex items-center gap-3">
                              <span className="text-[10px] font-black text-orange-600 uppercase tracking-widest">
                                Initial Password
                              </span>
                              <span className="font-mono font-black text-orange-600 bg-white px-3 py-1 rounded-lg border border-orange-200">
                                {searchResult.initial_password}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="w-full lg:w-auto flex flex-col gap-4 relative z-10">
                        {searchResult.student_type !== "online" && (
                          <div className="glass p-6 rounded-3xl border border-white shadow-lg text-center min-w-[200px] bg-white/40">
                            <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                              Roll Number
                            </div>
                            <div className="text-5xl font-black text-orange-600 tracking-tighter">
                              {searchResult.roll_number || "N/A"}
                            </div>
                            <div className="mt-4 pt-4 border-t border-slate-100/50">
                              <select
                                className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-600 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                                value={searchResult.status || "active"}
                                onChange={(e) =>
                                  handleUpdateStudentStatus(
                                    searchResult.id,
                                    e.target.value,
                                  )
                                }
                              >
                                <option value="active">Active Status</option>
                                <option value="dropped">Dropped Out</option>
                              </select>
                            </div>
                          </div>
                        )}
                        {searchResult.student_type === "online" && (
                          <div className="glass p-6 rounded-3xl border border-white shadow-lg text-center min-w-[200px] bg-white/40 flex justify-center items-center h-full">
                              <select
                                className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-600 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                                value={searchResult.status || "active"}
                                onChange={(e) =>
                                  handleUpdateStudentStatus(
                                    searchResult.id,
                                    e.target.value,
                                  )
                                }
                              >
                                <option value="active">Active Status</option>
                                <option value="dropped">Dropped Out</option>
                              </select>
                          </div>
                        )}

                        <div className="flex flex-col gap-3">
                          <button
                            onClick={() => {
                              setEditStudentData({
                                id: searchResult.id,
                                name: searchResult.name,
                                email: searchResult.email,
                                phone: searchResult.phone,
                                guardian_phone:
                                  searchResult.guardian_phone || "",
                                current_class: searchResult.current_class || "",
                                program_title: searchResult.program_title || "",
                                admission_month:
                                  searchResult.admission_month || "",
                                batch_days: searchResult.batch_days || "",
                                batch_time: searchResult.batch_time || "",
                                admission_fee: searchResult.admission_fee || 0,
                                monthly_fee: searchResult.monthly_fee || 0,
                                paid_amount: searchResult.paid_amount || 0,
                                roll_number: searchResult.roll_number || "",
                                status: searchResult.status || "active",
                                student_type:
                                  searchResult.student_type || "offline",
                                profile_pic: searchResult.profile_pic || "",
                              });
                              setIsEditingStudent(true);
                              setSelectedStudent(searchResult);
                            }}
                            className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-slate-800 transition-all active:scale-95 shadow-xl shadow-slate-200 flex items-center justify-center gap-3 text-xs"
                          >
                            <Edit className="h-4 w-4" /> Edit Details
                          </button>
                          <button
                            onClick={() =>
                              handleCancelRegistration(searchResult.id)
                            }
                            className="w-full py-4 bg-white text-orange-600 border border-orange-100 rounded-2xl font-black uppercase tracking-widest hover:bg-orange-50 transition-all active:scale-95 shadow-lg shadow-orange-50 flex items-center justify-center gap-3 text-xs"
                          >
                            <XCircle className="h-4 w-4" /> Cancel Registration
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="mb-10 bg-white/40 p-8 rounded-[2rem] border border-white/60 relative z-10">
                      <h3 className="text-lg font-black mb-6 text-slate-900 tracking-tight flex items-center gap-2">
                        <CreditCard className="h-5 w-5 text-orange-600" />
                        Payment History{" "}
                        {searchResult.student_type !== "online" && (
                          <span className="text-slate-400 font-bold text-sm ml-2">
                            (12 Months)
                          </span>
                        )}
                      </h3>
                      {searchResult.student_type === "online" ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {(() => {
                            const onlinePayments = [
                              ...(searchResult.payments || []),
                              ...(searchResult.enrollments || [])
                                .filter((e: any) => (e.status === "approved" || e.status === "contacted") && e.fee)
                                .map((e: any) => ({
                                  id: e.id,
                                  date: e.created_at || new Date().toISOString(),
                                  type: e.course_title || e.program_title || "Course Enrollment",
                                  amount: e.fee
                                }))
                            ].sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());

                            if (onlinePayments.length === 0) {
                              return (
                                <div className="col-span-full text-center py-6 text-slate-500 font-bold text-sm">
                                  No payment history found
                                </div>
                              );
                            }

                            return onlinePayments.map((p: any) => (
                              <div key={p.id} className="p-5 rounded-3xl bg-green-50 text-green-700 border border-green-200 shadow-sm flex flex-col justify-between">
                                  <div className="mb-2">
                                    <div className="text-[10px] font-black uppercase tracking-widest text-green-600/70">{format(new Date(p.date), "dd MMM yyyy")}</div>
                                    <div className="font-extrabold text-sm line-clamp-1">{p.type}</div>
                                  </div>
                                  <div className="flex items-center justify-between">
                                    <span className="text-xl font-black tracking-tighter">৳{p.amount}</span>
                                    <CheckCircle2 className="h-6 w-6" />
                                  </div>
                              </div>
                            ));
                          })()}
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                          {[
                            "January",
                            "February",
                            "March",
                            "April",
                            "May",
                            "June",
                            "July",
                            "August",
                            "September",
                            "October",
                            "November",
                            "December",
                          ].map((month) => {
                            const isPaid = searchResult.payments?.some(
                              (p: any) =>
                                p.month === month && p.type === "monthly",
                            );
                            return (
                              <div
                                key={month}
                                className={`p-5 rounded-3xl text-center transition-all border shadow-lg ${
                                  isPaid
                                    ? "bg-green-500 text-white border-green-400 shadow-green-100"
                                    : "bg-red-500 text-white border-red-400 shadow-red-100"
                                }`}
                              >
                                <div className="text-[10px] font-black uppercase tracking-[0.2em] mb-2">
                                  {month.substring(0, 3)}
                                </div>
                                <div className="flex justify-center">
                                  {isPaid ? (
                                    <div className="bg-white/20 p-1.5 rounded-full">
                                      <CheckCircle2 className="h-4 w-4" />
                                    </div>
                                  ) : (
                                    <div className="bg-black/10 p-1.5 rounded-full">
                                      <XCircle className="h-4 w-4 opacity-50" />
                                    </div>
                                  )}
                                </div>
                                <div className="mt-2 text-[8px] font-black uppercase tracking-tighter opacity-80">
                                  {isPaid ? "Paid" : "Unpaid"}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
                      <div className="glass p-8 rounded-[2rem] border border-white/60 shadow-xl bg-white/40">
                        <h3 className="text-lg font-black mb-6 flex items-center gap-3 text-slate-900 tracking-tight">
                          <div className="p-2 rounded-xl bg-green-100 text-green-600">
                            <CheckCircle className="h-5 w-5" />
                          </div>
                          Attendance
                        </h3>
                        <div className="space-y-3 max-h-80 overflow-y-auto custom-scrollbar pr-2">
                          {searchResult.attendance?.map((r: any) => {
                            const dateObj = parseISO(r.date);
                            const dayName = format(dateObj, "EEEE");
                            const isExam = r.type === "exam";
                            const examName = isExam
                              ? exams.find(
                                  (e) => String(e.id) === String(r.exam_id),
                                )?.exam_name
                              : null;

                            return (
                              <div
                                key={r.id}
                                className={`flex justify-between items-center bg-white/60 p-4 rounded-2xl border ${isExam ? "border-purple-200 bg-purple-50/50 hover:border-purple-300" : "border-white hover:border-orange-200"} shadow-sm transition-all group`}
                              >
                                <div className="flex flex-col">
                                  <span
                                    className={`font-black text-sm transition-colors ${isExam ? "text-purple-800 group-hover:text-purple-600" : "text-slate-800 group-hover:text-orange-600"}`}
                                  >
                                    {isExam
                                      ? `Exam: ${examName || "Unknown Exam"}`
                                      : r.date}
                                  </span>
                                  <span
                                    className={`text-[10px] font-black uppercase tracking-widest mt-0.5 ${isExam ? "text-purple-400" : "text-slate-400"}`}
                                  >
                                    {isExam
                                      ? r.date
                                      : `${dayName} • ${r.time && r.time !== "N/A" ? r.time : "No time"}`}
                                  </span>
                                </div>
                                <div className="flex flex-col items-end gap-1.5">
                                  <span
                                    className={`px-3 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm border ${
                                      r.status === "present"
                                        ? isExam
                                          ? "bg-purple-100 text-purple-600 border-purple-200"
                                          : "bg-green-100 text-green-600 border-green-200"
                                        : "bg-orange-100 text-orange-600 border-orange-200"
                                    }`}
                                  >
                                    {r.status}
                                  </span>
                                  {r.isAuto && (
                                    <span className="text-[8px] text-slate-400 font-black uppercase tracking-tighter bg-slate-100/50 px-1.5 py-0.5 rounded-md">
                                      Auto
                                    </span>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                          {(!searchResult.attendance ||
                            searchResult.attendance.length === 0) && (
                            <div className="text-center py-10 text-slate-400 font-black uppercase tracking-widest text-[10px]">
                              No attendance records
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="glass p-8 rounded-[2rem] border border-white/60 shadow-xl bg-white/40">
                        <h3 className="text-lg font-black mb-6 flex items-center gap-3 text-slate-900 tracking-tight">
                          <div className="p-2 rounded-xl bg-orange-100 text-orange-600">
                            <CreditCard className="h-5 w-5" />
                          </div>
                          Payments
                        </h3>
                        <div className="space-y-3 max-h-80 overflow-y-auto custom-scrollbar pr-2">
                          {searchResult.payments?.map((p: any) => (
                            <div
                              key={p.id}
                              className="flex justify-between items-center bg-white/60 p-4 rounded-2xl border border-white shadow-sm hover:border-orange-200 transition-all group"
                            >
                              <div className="flex flex-col">
                                <span className="font-black text-slate-800 group-hover:text-orange-600 transition-colors text-sm">
                                  {p.month || "N/A"}
                                </span>
                                <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest mt-0.5">
                                  {p.date}
                                </span>
                              </div>
                              <span className="font-black text-orange-600 text-sm">
                                ৳{p.amount}
                              </span>
                            </div>
                          ))}
                          {(!searchResult.payments ||
                            searchResult.payments.length === 0) && (
                            <div className="text-center py-10 text-slate-400 font-black uppercase tracking-widest text-[10px]">
                              No payment records
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="glass p-8 rounded-[2rem] border border-white/60 shadow-xl bg-white/40">
                        <h3 className="text-lg font-black mb-6 flex items-center gap-3 text-slate-900 tracking-tight">
                          <div className="p-2 rounded-xl bg-blue-100 text-blue-600">
                            <FileText className="h-5 w-5" />
                          </div>
                          Exam Results
                        </h3>
                        <div className="space-y-3 max-h-80 overflow-y-auto custom-scrollbar pr-2">
                          {searchResult.results?.map((r: any) => (
                            <div
                              key={r.id}
                              className="flex justify-between items-center bg-white/60 p-4 rounded-2xl border border-white shadow-sm hover:border-orange-200 transition-all group"
                            >
                              <div className="flex flex-col">
                                <span className="font-black text-slate-800 group-hover:text-orange-600 transition-colors text-sm truncate max-w-[120px]">
                                  {r.exam_name}
                                </span>
                                <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest mt-0.5">
                                  Pos:{" "}
                                  {meritPositions[r.exam_id || r.exam_name]?.[
                                    searchResult.id
                                  ] || "-"}
                                </span>
                              </div>
                              <div className="text-right">
                                <div className="font-black text-orange-600 text-sm">
                                  {r.marks}/
                                  {r.highest_marks || r.total_marks || "N/A"}
                                </div>
                              </div>
                            </div>
                          ))}
                          {(!searchResult.results ||
                            searchResult.results.length === 0) && (
                            <div className="text-center py-10 text-slate-400 font-black uppercase tracking-widest text-[10px]">
                              No result records
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>
            )}

            {/* Courses Tab */}
            {activeTab === "courses" && (
              <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div className="relative">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                      <div className="p-3 rounded-2xl bg-orange-500 text-white shadow-lg shadow-orange-200">
                        <BookOpen className="h-8 w-8" />
                      </div>
                      Online Courses
                    </h2>
                    <div className="absolute -bottom-2 left-16 w-24 h-1.5 bg-orange-500 rounded-full"></div>
                  </div>
                  <button
                    onClick={() => clearForm("course")}
                    className="px-6 py-3 bg-white/60 backdrop-blur-md border border-white/60 text-slate-500 hover:text-orange-600 rounded-2xl text-sm font-black uppercase tracking-widest transition-all hover:shadow-lg active:scale-95 flex items-center gap-2"
                  >
                    <XCircle className="h-4 w-4" /> Clear Form
                  </button>
                </div>

                <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 overflow-hidden relative group">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/10 rounded-full blur-[100px] -mr-48 -mt-48 group-hover:bg-orange-500/15 transition-colors duration-700"></div>
                  <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-500/10 rounded-full blur-[100px] -ml-48 -mb-48 group-hover:bg-orange-500/15 transition-colors duration-700"></div>

                  <div className="flex items-center gap-4 mb-10 relative z-10">
                    <div className="h-12 w-1.5 bg-orange-500 rounded-full"></div>
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                      Create New Course
                    </h3>
                  </div>

                  <form
                    onSubmit={handleAddCourse}
                    className="space-y-6 relative z-10"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                          Course Title
                        </label>
                        <input
                          type="text"
                          placeholder="Enter course title..."
                          className="glass-input"
                          value={newCourse.title}
                          onChange={(e) =>
                            setNewCourse((prev) => ({
                              ...prev,
                              title: e.target.value,
                            }))
                          }
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                          Price (BDT)
                        </label>
                        <input
                          type="number"
                          placeholder="0.00"
                          className="glass-input"
                          value={newCourse.price}
                          onChange={(e) =>
                            setNewCourse((prev) => ({
                              ...prev,
                              price: e.target.value,
                            }))
                          }
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                        Course Description
                      </label>
                      <textarea
                        placeholder="Write a detailed description of the course..."
                        className="glass-input h-32 resize-none py-4"
                        value={newCourse.description}
                        onChange={(e) =>
                          setNewCourse((prev) => ({
                            ...prev,
                            description: e.target.value,
                          }))
                        }
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="md:col-span-2 space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                          Thumbnail Image URL
                        </label>
                        <div className="flex flex-col gap-2">
                          <div className="flex items-center gap-3">
                            {newCourse.image_url && (
                              <div className="w-12 h-12 rounded-xl overflow-hidden border border-slate-200 shrink-0 relative group">
                                <img
                                  src={newCourse.image_url}
                                  className="w-full h-full object-cover"
                                  alt="Preview"
                                  referrerPolicy="no-referrer"
                                />
                                <div
                                  className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center cursor-pointer"
                                  onClick={() =>
                                    setNewCourse((prev) => ({
                                      ...prev,
                                      image_url: "",
                                    }))
                                  }
                                >
                                  <X className="h-4 w-4 text-white" />
                                </div>
                              </div>
                            )}
                            <input
                              type="text"
                              placeholder="https://example.com/image.jpg"
                              className={`glass-input flex-1 ${newCourse.image_url?.startsWith("data:image") ? "opacity-50" : ""}`}
                              value={
                                newCourse.image_url?.startsWith("data:image")
                                  ? "Linked via File Upload"
                                  : newCourse.image_url
                              }
                              onChange={(e) =>
                                setNewCourse((prev) => ({
                                  ...prev,
                                  image_url: e.target.value,
                                }))
                              }
                              disabled={newCourse.image_url?.startsWith(
                                "data:image",
                              )}
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="file"
                              id="course-image-upload"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  processImage(file, (dataUrl) =>
                                    setNewCourse((prev) => ({
                                      ...prev,
                                      image_url: dataUrl,
                                    })),
                                  );
                                  e.target.value = ""; // clear input
                                }
                              }}
                            />
                            <label
                              htmlFor="course-image-upload"
                              className="cursor-pointer bg-orange-50 text-orange-600 px-4 py-2 rounded-xl font-bold text-xs hover:bg-orange-100 transition-all border border-orange-200 flex items-center gap-2"
                            >
                              <Upload className="h-4 w-4" /> Choose File
                            </label>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                          Duration
                        </label>
                        <input
                          type="text"
                          placeholder="e.g., 3 Months"
                          className="glass-input"
                          value={newCourse.duration}
                          onChange={(e) =>
                            setNewCourse((prev) => ({
                              ...prev,
                              duration: e.target.value,
                            }))
                          }
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                          Lecture Count
                        </label>
                        <input
                          type="text"
                          placeholder="e.g., 24 Lectures"
                          className="glass-input"
                          value={newCourse.lecture_count}
                          onChange={(e) =>
                            setNewCourse((prev) => ({
                              ...prev,
                              lecture_count: e.target.value,
                            }))
                          }
                        />
                      </div>
                      <div className="flex items-end">
                        <button
                          type="submit"
                          className="w-full py-4 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-2xl font-black uppercase tracking-widest hover:from-orange-700 hover:to-orange-600 transition-all shadow-xl shadow-orange-200 flex items-center justify-center gap-3 active:scale-95"
                        >
                          <Plus className="h-5 w-5" /> Publish Course
                        </button>
                      </div>
                    </div>

                    {newCourse.image_url && (
                      <div className="mt-6 p-2 glass rounded-3xl border border-white/60 inline-block group/preview">
                        <div className="relative w-64 h-36 rounded-2xl overflow-hidden shadow-inner">
                          <img
                            src={newCourse.image_url}
                            alt="Preview"
                            className="w-full h-full object-cover group-hover/preview:scale-110 transition-transform duration-700"
                            onError={handleImageError}
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                          <div className="absolute bottom-3 left-3 text-[10px] font-black text-white uppercase tracking-widest">
                            Live Preview
                          </div>
                        </div>
                      </div>
                    )}
                  </form>
                </div>

                <div className="glass rounded-[2.5rem] shadow-2xl border border-white/60 overflow-hidden bg-white/30 backdrop-blur-xl">
                  <div className="overflow-x-auto custom-scrollbar">
                    <table className="w-full text-left min-w-[800px]">
                      <thead>
                        <tr className="border-b border-white/40">
                          <th className="p-8 text-[10px] font-black uppercase tracking-widest text-slate-400">
                            Course Info
                          </th>
                          <th className="p-8 text-[10px] font-black uppercase tracking-widest text-slate-400">
                            Duration & Lectures
                          </th>
                          <th className="p-8 text-[10px] font-black uppercase tracking-widest text-slate-400">
                            Price
                          </th>
                          <th className="p-8 text-[10px] font-black uppercase tracking-widest text-slate-400 text-right">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/20">
                        {courses.map((course, index) => (
                          <tr
                            key={course.id}
                            className="hover:bg-white/40 transition-all group"
                          >
                            <td className="p-8">
                              <div className="flex items-center gap-6">
                                <div className="relative w-20 h-20 rounded-2xl overflow-hidden shadow-lg border-2 border-white group-hover:scale-105 transition-transform duration-500">
                                  <img
                                    src={
                                      course.image_url ||
                                      "https://picsum.photos/seed/course/200/200"
                                    }
                                    alt={course.title}
                                    className="w-full h-full object-cover"
                                    onError={handleImageError}
                                    referrerPolicy="no-referrer"
                                  />
                                </div>
                                <div>
                                  <div className="font-black text-slate-900 text-lg tracking-tight group-hover:text-orange-600 transition-colors">
                                    {course.title}
                                  </div>
                                  <div className="text-xs text-slate-400 font-bold mt-1 line-clamp-1 max-w-xs">
                                    {course.description}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className="p-8">
                              <div className="flex flex-col gap-2">
                                <div className="flex items-center gap-2 text-slate-600">
                                  <Clock className="h-4 w-4 text-orange-500" />
                                  <span className="text-xs font-black uppercase tracking-widest">
                                    {course.duration || "N/A"}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2 text-slate-600">
                                  <PlayCircle className="h-4 w-4 text-orange-500" />
                                  <span className="text-xs font-black uppercase tracking-widest">
                                    {course.lecture_count || "N/A"}
                                  </span>
                                </div>
                              </div>
                            </td>
                            <td className="p-8">
                              <div className="inline-flex items-center px-4 py-2 rounded-xl bg-green-100 text-green-600 font-black text-lg shadow-sm border border-green-200">
                                ৳{course.price}
                              </div>
                            </td>
                            <td className="p-8 text-right">
                              <button
                                onClick={() => handleDeleteCourse(course.id)}
                                className="p-4 bg-orange-50 text-orange-400 hover:bg-orange-500 hover:text-white rounded-2xl transition-all active:scale-90 shadow-sm"
                                title="Delete Course"
                              >
                                <Trash2 className="h-5 w-5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                        {courses.length === 0 && (
                          <tr>
                            <td colSpan={4} className="p-20 text-center">
                              <div className="flex flex-col items-center gap-4">
                                <div className="p-6 rounded-full bg-slate-100 text-slate-300">
                                  <BookOpen className="h-12 w-12" />
                                </div>
                                <div className="text-slate-400 font-black uppercase tracking-widest text-sm">
                                  No courses published yet
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Students Tab */}
            {["students", "online_students"].includes(activeTab) &&
              !selectedStudent && (
                <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
                  {authLoading ? (
                    <TableSkeleton />
                  ) : (
                    <>
                      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                        <div className="relative">
                          <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                            <div className="p-3 rounded-2xl bg-orange-500 text-white shadow-lg shadow-orange-200">
                              <Users className="h-8 w-8" />
                            </div>
                            {activeTab === "online_students"
                              ? "Online Students"
                              : "Offline Students"}
                          </h2>
                          <div className="absolute -bottom-2 left-16 w-24 h-1.5 bg-orange-500 rounded-full"></div>
                        </div>

                        <div className="flex flex-wrap items-center gap-4">
                          <button
                            onClick={() => setActiveTab("sms_center")}
                            className="px-4 py-2 bg-orange-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-md flex items-center gap-2"
                          >
                            <MessageSquare className="h-4 w-4" /> Broadcast SMS
                          </button>
                          {selectedBatch && (
                            <button
                              onClick={() => setSelectedBatch(null)}
                              className="px-4 py-2 bg-slate-100 text-slate-600 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-slate-200 transition-all flex items-center gap-2 border border-slate-200"
                            >
                              <XCircle className="h-4 w-4 text-orange-500" />{" "}
                              Clear Batch Filter
                            </button>
                          )}
                          <button
                            onClick={() => clearForm("student")}
                            className="px-4 py-2 bg-white/60 backdrop-blur-md border border-white/60 text-slate-500 hover:text-orange-600 rounded-xl text-xs font-black uppercase tracking-widest transition-all hover:shadow-lg active:scale-95 flex items-center gap-2"
                          >
                            <XCircle className="h-4 w-4" /> Clear Form
                          </button>
                          <div className="relative group">
                            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 h-5 w-5 group-focus-within:text-orange-500 transition-colors" />
                            <DebouncedInput
                              type="text"
                              placeholder="Search student..."
                              className="pl-12 pr-6 py-3 bg-white/60 backdrop-blur-md border border-white/60 rounded-2xl focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 shadow-sm w-64 transition-all"
                              value={searchTerm}
                              onChange={(value: string) => setSearchTerm(value)}
                            />
                          </div>
                          <select
                            className="glass-select h-[48px] w-auto text-sm"
                            value={studentStatusFilter}
                            onChange={(e) => setStudentStatusFilter(e.target.value)}
                          >
                            <option value="all">All Status</option>
                            <option value="approved">Approved</option>
                            <option value="pending">Pending</option>
                            <option value="upcoming">Upcoming</option>
                            <option value="passed">Passed</option>
                          </select>
                        </div>
                      </div>

                      {/* Add Student Form */}
                      {!selectedStudent && activeTab === "students" && (
                        <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 overflow-hidden relative group mb-12">
                          <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/10 rounded-full blur-[100px] -mr-48 -mt-48 group-hover:bg-orange-500/15 transition-colors duration-700"></div>
                          <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-500/10 rounded-full blur-[100px] -ml-48 -mb-48 group-hover:bg-orange-500/15 transition-colors duration-700"></div>

                          <div className="flex items-center gap-4 mb-10 relative z-10">
                            <div className="h-12 w-1.5 bg-orange-500 rounded-full"></div>
                            <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                              Register New {activeTab === "students" ? "Offline" : "Online"} Student
                            </h3>
                          </div>

                          <form
                            onSubmit={(e) => handleAddStudent(e, activeTab === "students" ? "offline" : "online")}
                            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10"
                          >
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Full Name
                              </label>
                              <DebouncedInput
                                type="text"
                                placeholder="John Doe"
                                className="glass-input"
                                value={newStudent.name || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    name: val,
                                  }))
                                }
                                required
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Email Address
                              </label>
                              <DebouncedInput
                                type="email"
                                placeholder="john@example.com"
                                className="glass-input"
                                value={newStudent.email || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    email: val,
                                  }))
                                }
                                required
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Password
                              </label>
                              <DebouncedInput
                                type="password"
                                placeholder="••••••••"
                                className="glass-input"
                                value={newStudent.password || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    password: val,
                                  }))
                                }
                                required
                              />
                            </div>
                            {(activeTab as string) !== "online_students" && (
                              <div className="space-y-2">
                                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                  Roll Number
                                </label>
                                <DebouncedInput
                                  type="number"
                                  placeholder="1001"
                                  className="glass-input"
                                  value={newStudent.roll_number || ""}
                                  onChange={(val: string) =>
                                    setNewStudent((prev) => ({
                                      ...prev,
                                      roll_number: val,
                                    }))
                                  }
                                  required={(activeTab as string) !== "online_students"}
                                />
                              </div>
                            )}
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Student Phone
                              </label>
                              <DebouncedInput
                                type="text"
                                placeholder="017XXXXXXXX"
                                className="glass-input"
                                value={newStudent.phone || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    phone: val,
                                  }))
                                }
                                required
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Class
                              </label>
                              <DebouncedInput
                                type="text"
                                placeholder="e.target. HSC / Class 10"
                                className="glass-input"
                                value={newStudent.current_class || newStudent.class || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    current_class: val,
                                    class: val,
                                  }))
                                }
                                required
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Guardian Phone
                              </label>
                              <DebouncedInput
                                type="text"
                                placeholder="018XXXXXXXX"
                                className="glass-input"
                                value={newStudent.guardian_phone || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    guardian_phone: val,
                                  }))
                                }
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                School Name
                              </label>
                              <DebouncedInput
                                type="text"
                                placeholder="Your School"
                                className="glass-input"
                                value={newStudent.school_name || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    school_name: val,
                                  }))
                                }
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                College Name
                              </label>
                              <DebouncedInput
                                type="text"
                                placeholder="Your College (Optional)"
                                className="glass-input"
                                value={newStudent.college_name || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    college_name: val,
                                  }))
                                }
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Program
                              </label>
                              <select
                                className="glass-select"
                                value={newStudent.program_id || ""}
                                required
                                onChange={(e) => {
                                  const program = programs.find(
                                    (p) =>
                                      String(p.id) === String(e.target.value),
                                  );
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    program_id: e.target.value,
                                    program_title: program?.title || "",
                                    current_class: program?.target_audience || prev.current_class || "",
                                    class: program?.target_audience || prev.class || "",
                                    admission_fee: program?.admission_fee ?? 0,
                                    monthly_fee: program?.monthly_fee ?? 0,
                                  }));
                                }}
                              >
                                <option value="">Select Program</option>
                                {programs.map((p) => (
                                  <option key={p.id} value={p.id}>
                                    {p.title}
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Class
                              </label>
                              <select
                                className="glass-select"
                                value={newStudent.class || ""}
                                onChange={(e) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    class: e.target.value,
                                    current_class: e.target.value,
                                    batch_id: "",
                                  }))
                                }
                              >
                                <option value="">Select Class</option>
                                <option value="all">All Classes / Default</option>
                                {Array.from(
                                  new Set(
                                    batches
                                      .filter((b) => String(b.program_id) === String(newStudent.program_id))
                                      .map((b) => b.class || b.class_name || b.batch_class)
                                      .filter(Boolean)
                                  )
                                ).map((c: any) => (
                                  <option key={c} value={c}>
                                    {c}
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Admission Fee
                              </label>
                              <DebouncedInput
                                type="number"
                                placeholder="Admission Fee"
                                className="glass-input"
                                value={newStudent.admission_fee || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    admission_fee: val,
                                  }))
                                }
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Monthly Fee
                              </label>
                              <DebouncedInput
                                type="number"
                                placeholder="Monthly Fee"
                                className="glass-input"
                                value={newStudent.monthly_fee || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    monthly_fee: val,
                                  }))
                                }
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Address
                              </label>
                              <DebouncedInput
                                type="text"
                                placeholder="Dhaka, Bangladesh"
                                className="glass-input"
                                value={newStudent.address || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    address: val,
                                  }))
                                }
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Admission Month
                              </label>
                              <select
                                className="glass-select"
                                value={newStudent.admission_month || ""}
                                onChange={(e) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    admission_month: e.target.value,
                                  }))
                                }
                              >
                                <option value="">Select Month</option>
                                {MONTHS.map((m) => (
                                  <option key={m} value={m}>
                                    {m}
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Paid Amount
                              </label>
                              <DebouncedInput
                                type="number"
                                placeholder="0.00"
                                className="glass-input"
                                value={newStudent.paid_amount || ""}
                                onChange={(val: string) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    paid_amount: val,
                                  }))
                                }
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Blood Group
                              </label>
                              <select
                                className="glass-select"
                                value={newStudent.blood_group || ""}
                                onChange={(e) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    blood_group: e.target.value,
                                  }))
                                }
                              >
                                <option value="">Select Blood Group</option>
                                {["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"].map((bg) => (
                                  <option key={bg} value={bg}>
                                    {bg}
                                  </option>
                                ))}
                              </select>
                            </div>
                             <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                 Batch
                               </label>
                               <select
                                 className="glass-select"
                                 value={newStudent.batch_id || ""}
                                 disabled={!newStudent.program_id}
                                 required
                                 onChange={(e) => {
                                   const batch = batches.find(
                                     (b) =>
                                       String(b.id) === String(e.target.value),
                                   );
                                   setNewStudent((prev) => ({
                                     ...prev,
                                     batch_id: e.target.value,
                                     batch_days: batch?.batch_days || "",
                                     batch_time: batch?.batch_time || "",
                                   }));
                                 }}
                               >
                                 <option value="">
                                   {newStudent.program_id
                                     ? "Select Batch"
                                     : "Select Program First"}
                                 </option>
                                 {getFilteredBatches(
                                   newStudent.program_id || "",
                                   newStudent.class
                                 ).map((b) => (
                                   <option key={b.id} value={b.id}>
                                     {b.name}
                                   </option>
                                 ))}
                               </select>
                             </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Profile Picture URL
                              </label>
                              <div className="flex flex-col gap-2">
                                <div className="flex items-center gap-3">
                                  {newStudent.profile_pic && (
                                    <div className="w-12 h-12 rounded-xl overflow-hidden border border-slate-200 shrink-0 relative group">
                                      <img
                                        src={newStudent.profile_pic}
                                        className="w-full h-full object-cover"
                                        alt="Preview"
                                        referrerPolicy="no-referrer"
                                      />
                                      <div
                                        className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center cursor-pointer"
                                        onClick={() =>
                                          setNewStudent((prev) => ({
                                            ...prev,
                                            profile_pic: "",
                                          }))
                                        }
                                      >
                                        <X className="h-4 w-4 text-white" />
                                      </div>
                                    </div>
                                  )}
                                  <input
                                    type="text"
                                    placeholder="https://example.com/photo.jpg"
                                    className={`glass-input flex-1 ${newStudent.profile_pic?.startsWith("data:image") ? "opacity-50" : ""}`}
                                    value={
                                      newStudent.profile_pic?.startsWith(
                                        "data:image",
                                      )
                                        ? "Linked via File Upload"
                                        : newStudent.profile_pic || ""
                                    }
                                    onChange={(e) =>
                                      setNewStudent((prev) => ({
                                        ...prev,
                                        profile_pic: e.target.value,
                                      }))
                                    }
                                    disabled={newStudent.profile_pic?.startsWith(
                                      "data:image",
                                    )}
                                  />
                                </div>
                                <div className="flex items-center gap-2">
                                  <input
                                    type="file"
                                    id="student-profile-upload"
                                    accept="image/*"
                                    className="hidden"
                                    onChange={(e) => {
                                      const file = e.target.files?.[0];
                                      if (file) {
                                        processImage(file, (dataUrl) =>
                                          setNewStudent((prev) => ({
                                            ...prev,
                                            profile_pic: dataUrl,
                                          })),
                                        );
                                        e.target.value = ""; // clear input so the same file could be selected again
                                      }
                                    }}
                                  />
                                  <label
                                    htmlFor="student-profile-upload"
                                    className="cursor-pointer bg-orange-50 text-orange-600 px-4 py-2 rounded-xl font-bold text-xs hover:bg-orange-100 transition-all border border-orange-200 flex items-center gap-2"
                                  >
                                    <Upload className="h-4 w-4" /> Choose File
                                  </label>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-end">
                              <button
                                type="submit"
                                className="w-full py-4 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-2xl font-black uppercase tracking-widest hover:from-orange-700 hover:to-orange-600 transition-all shadow-xl shadow-orange-200 flex items-center justify-center gap-3 active:scale-95"
                              >
                                <UserPlus className="h-5 w-5" /> Register
                                Student
                              </button>
                            </div>
                          </form>
                        </div>
                      )}

                      {/* Online History Header */}
                      <div className="mt-12 pt-10 border-t border-white/40">
                        <div className="flex items-center gap-4 mb-8">
                          <div className="p-2 rounded-xl bg-orange-100 text-orange-600">
                            <History className="h-5 w-5" />
                          </div>
                          <h4 className="text-xl font-black text-slate-900 tracking-tight">
                            Recently Added Students
                          </h4>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                          {[...filteredStudents]
                            .sort(
                              (a, b) =>
                                new Date(b.created_at || 0).getTime() -
                                new Date(a.created_at || 0).getTime(),
                            )
                            .slice(0, 3)
                            .map((student) => (
                              <motion.div
                                key={student.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                whileHover={{ y: -5 }}
                                className="glass p-6 rounded-3xl border border-white/60 flex items-center gap-5 hover:shadow-xl transition-all group cursor-pointer"
                                onClick={() => handleViewStudent(student.id)}
                              >
                                <div className="relative">
                                  <div className="w-16 h-16 rounded-2xl bg-white flex items-center justify-center text-orange-600 font-black text-2xl border-2 border-white shadow-lg group-hover:scale-110 transition-transform duration-500 overflow-hidden">
                                    {student.profile_pic ? (
                                      <img
                                        src={student.profile_pic}
                                        alt={student.name}
                                        className="w-full h-full object-cover"
                                        referrerPolicy="no-referrer"
                                      />
                                    ) : (
                                      student.name.charAt(0)
                                    )}
                                  </div>
                                  <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 border-2 border-white rounded-full shadow-sm"></div>
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h5 className="font-black text-slate-900 truncate group-hover:text-orange-600 transition-colors">
                                    {student.name}
                                  </h5>
                                  <div className="flex items-center gap-2 mt-1">
                                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                      Roll:
                                    </span>
                                    <span className="text-xs font-black text-orange-600">
                                      {student.roll_number}
                                    </span>
                                  </div>
                                  <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest truncate mt-1">
                                    {student.batch_name ||
                                      student.program_title ||
                                      "No Batch"}
                                  </p>
                                </div>
                                <div className="p-2 rounded-xl bg-slate-50 text-slate-300 group-hover:bg-orange-500 group-hover:text-white transition-all">
                                  <ChevronRight className="h-5 w-5" />
                                </div>
                              </motion.div>
                            ))}
                        </div>
                      </div>

                      {activeTab === "online_students" ? (
                        <>
                          {/* Online Students grouped by Course */}
                          {courses.map((course) => {
                            const courseStudents =
                              studentsByCourse[course.id] || [];
                            if (courseStudents.length === 0) return null;

                            return (
                              <div
                                key={course.id}
                                className="glass rounded-[2.5rem] shadow-2xl border border-white/60 overflow-hidden bg-white"
                              >
                                <div className="bg-gradient-to-r from-blue-600/10 to-transparent px-10 py-6 border-b border-white/40 flex justify-between items-center">
                                  <div className="flex items-center gap-4">
                                    <div className="p-2 rounded-xl bg-blue-100 text-blue-600">
                                      <Video className="h-5 w-5" />
                                    </div>
                                    <h3 className="text-xl font-black text-slate-900 tracking-tight">
                                      {course.title}
                                    </h3>
                                  </div>
                                  <span className="px-4 py-1.5 bg-blue-100 text-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-200">
                                    {courseStudents.length} Students
                                  </span>
                                </div>
                                <div className="divide-y divide-white/20">
                                  {courseStudents.slice(0, 50).map((student) => (
                                    <div
                                      key={student.id}
                                      className="p-8 hover:bg-white/40 flex items-center justify-between transition-all group"
                                    >
                                      <div className="flex items-center gap-6">
                                        <div className="relative">
                                          <div className="w-16 h-16 rounded-2xl bg-blue-100 flex items-center justify-center text-blue-600 font-black text-2xl border-2 border-white shadow-lg group-hover:scale-110 transition-transform duration-500 overflow-hidden">
                                            {student.profile_pic ? (
                                              <img
                                                src={student.profile_pic}
                                                alt={student.name}
                                                className="w-full h-full object-cover"
                                                referrerPolicy="no-referrer"
                                              />
                                            ) : (
                                              student.name.charAt(0)
                                            )}
                                          </div>
                                          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-500 border-2 border-white rounded-full shadow-sm"></div>
                                        </div>
                                        <div>
                                          <h4 className="text-lg font-black text-slate-900 flex items-center gap-3 group-hover:text-blue-600 transition-colors">
                                            {student.name}
                                            {student.status && (
                                              <span
                                                className={`px-3 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm border ${
                                                  student.status === "approved"
                                                    ? "bg-green-100 text-green-600 border-green-200"
                                                    : student.status ===
                                                        "pending"
                                                      ? "bg-yellow-100 text-yellow-600 border-yellow-200"
                                                      : "bg-slate-100 text-slate-600 border-slate-200"
                                                }`}
                                              >
                                                {student.status}
                                              </span>
                                            )}
                                          </h4>
                                          <div className="text-xs text-slate-400 font-black uppercase tracking-widest mt-1 flex items-center gap-4">
                                            <span className="flex items-center gap-1.5">
                                              <Hash className="h-3 w-3 text-blue-500" />{" "}
                                              Roll:{" "}
                                              <span className="text-slate-600">
                                                {student.roll_number || "-"}
                                              </span>
                                            </span>
                                            <span className="flex items-center gap-1.5">
                                              <Phone className="h-3 w-3 text-blue-500" />{" "}
                                              {student.phone}
                                            </span>
                                            <span className="flex items-center gap-1.5">
                                              <BookOpen className="h-3 w-3 text-blue-500" />{" "}
                                              {student.course_title || "-"}
                                            </span>
                                          </div>
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-3">
                                        <button
                                          onClick={() =>
                                            handleViewStudent(student.id)
                                          }
                                          className="px-6 py-3 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-90 shadow-sm flex items-center gap-2"
                                        >
                                          View Profile{" "}
                                          <ChevronRight className="h-4 w-4" />
                                        </button>
                                        <button
                                          onClick={() =>
                                            handleDeleteStudent(student.id)
                                          }
                                          className="p-3 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white rounded-2xl transition-all active:scale-90 shadow-sm"
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            );
                          })}

                          {/* Online Students without valid Course */}
                          {(() => {
                            const unassignedStudents = filteredStudents.filter(
                              (s) => !s.course_id || !courses.find(c => c.id === s.course_id),
                            );
                            if (unassignedStudents.length === 0) return null;
                            return (
                              <div className="glass rounded-[2.5rem] shadow-2xl border border-white/60 overflow-hidden bg-white">
                                <div className="bg-gradient-to-r from-slate-600/10 to-transparent px-10 py-6 border-b border-white/40 flex justify-between items-center">
                                  <div className="flex items-center gap-4">
                                    <div className="p-2 rounded-xl bg-slate-100 text-slate-600">
                                      <Users className="h-5 w-5" />
                                    </div>
                                    <h3 className="text-xl font-black text-slate-900 tracking-tight">
                                      Unassigned Online Students
                                    </h3>
                                  </div>
                                  <span className="px-4 py-1.5 bg-slate-100 text-slate-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-slate-200">
                                    {unassignedStudents.length} Students
                                  </span>
                                </div>
                                <div className="divide-y divide-white/20">
                                  {unassignedStudents.slice(0, 50).map((student) => (
                                    <div
                                      key={student.id}
                                      className="p-8 hover:bg-white/40 flex items-center justify-between transition-all group"
                                    >
                                      <div className="flex items-center gap-6">
                                        <div className="relative">
                                          <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-600 font-black text-2xl border-2 border-white shadow-lg group-hover:scale-110 transition-transform duration-500 overflow-hidden">
                                            {student.profile_pic ? (
                                              <img
                                                src={student.profile_pic}
                                                alt={student.name}
                                                className="w-full h-full object-cover"
                                                referrerPolicy="no-referrer"
                                              />
                                            ) : (
                                              student.name.charAt(0)
                                            )}
                                          </div>
                                          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-500 border-2 border-white rounded-full shadow-sm"></div>
                                        </div>
                                        <div>
                                          <h4 className="text-lg font-black text-slate-900 flex items-center gap-3 group-hover:text-blue-600 transition-colors">
                                            {student.name}
                                          </h4>
                                          <div className="text-xs text-slate-400 font-black uppercase tracking-widest mt-1 flex items-center gap-4">
                                            <span className="flex items-center gap-1.5">
                                              <Hash className="h-3 w-3 text-blue-500" />{" "}
                                              Roll:{" "}
                                              <span className="text-slate-600">
                                                {student.roll_number || "-"}
                                              </span>
                                            </span>
                                            <span className="flex items-center gap-1.5">
                                              <Phone className="h-3 w-3 text-blue-500" />{" "}
                                              {student.phone}
                                            </span>
                                          </div>
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-3">
                                        <button
                                          onClick={() =>
                                            handleViewStudent(student.id)
                                          }
                                          className="px-6 py-3 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-90 shadow-sm flex items-center gap-2"
                                        >
                                          View Profile{" "}
                                          <ChevronRight className="h-4 w-4" />
                                        </button>
                                        <button
                                          onClick={() =>
                                            handleDeleteStudent(student.id)
                                          }
                                          className="p-3 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white rounded-2xl transition-all active:scale-90 shadow-sm"
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            );
                          })()}

                          {filteredStudents.length === 0 && (
                            <div className="p-32 text-center glass rounded-[3rem] border-2 border-dashed border-slate-200 bg-white/50">
                              <div className="flex flex-col items-center gap-6">
                                <div className="p-8 rounded-full bg-orange-50 text-orange-200">
                                  <Users className="h-16 w-16" />
                                </div>
                                <div className="space-y-2">
                                  <h3 className="text-2xl font-black text-slate-800 tracking-tight uppercase">No Online Students Found</h3>
                                  <p className="text-slate-400 font-bold text-sm max-w-xs mx-auto">Try changing the status filter or search for a specific student name.</p>
                                </div>
                              </div>
                            </div>
                          )}
                        </>
                      ) : (
                        <>
                          {/* Students without Batch */}
                          {(() => {
                            const unassignedStudents = filteredStudents.filter(
                              (s) => !s.batch_id,
                            );
                            if (unassignedStudents.length === 0) return null;
                            return (
                              <div className="glass rounded-[2.5rem] shadow-2xl border border-white/60 overflow-hidden bg-white/30 backdrop-blur-xl">
                                <div className="bg-gradient-to-r from-orange-600/10 to-transparent px-10 py-6 border-b border-white/40 flex justify-between items-center">
                                  <div className="flex items-center gap-4">
                                    <div className="p-2 rounded-xl bg-orange-100 text-orange-600">
                                      <Users className="h-5 w-5" />
                                    </div>
                                    <h3 className="text-xl font-black text-slate-900 tracking-tight">
                                      Unassigned / Program Students
                                    </h3>
                                  </div>
                                  <span className="px-4 py-1.5 bg-orange-100 text-orange-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-orange-200">
                                    {unassignedStudents.length} Students
                                  </span>
                                </div>
                                <div className="divide-y divide-white/20">
                                  {unassignedStudents.slice(0, 50).map((student, index) => (
                                    <div
                                      key={student.id}
                                      className="p-8 hover:bg-white/40 flex items-center justify-between transition-all group"
                                    >
                                      <div className="flex items-center gap-6">
                                        <div className="relative">
                                          <div className="w-16 h-16 rounded-2xl bg-orange-100 flex items-center justify-center text-orange-600 font-black text-2xl border-2 border-white shadow-lg group-hover:scale-110 transition-transform duration-500 overflow-hidden">
                                            {student.profile_pic ? (
                                              <img
                                                src={student.profile_pic}
                                                alt={student.name}
                                                className="w-full h-full object-cover"
                                                referrerPolicy="no-referrer"
                                              />
                                            ) : (
                                              student.name.charAt(0)
                                            )}
                                          </div>
                                          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 border-2 border-white rounded-full shadow-sm"></div>
                                        </div>
                                        <div>
                                          <h4 className="text-lg font-black text-slate-900 flex items-center gap-3 group-hover:text-orange-600 transition-colors">
                                            {student.name}
                                          </h4>
                                          <div className="text-xs text-slate-400 font-black uppercase tracking-widest mt-1 flex items-center gap-4">
                                            <span className="flex items-center gap-1.5">
                                              <Hash className="h-3 w-3 text-orange-500" />{" "}
                                              Roll:{" "}
                                              <span className="text-slate-600">
                                                {student.roll_number || "-"}
                                              </span>
                                            </span>
                                            <span className="flex items-center gap-1.5">
                                              <Phone className="h-3 w-3 text-orange-500" />{" "}
                                              {student.phone}
                                            </span>
                                          </div>
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-6">
                                        <span
                                          className={`px-3 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm border ${
                                            student.status === "approved"
                                              ? "bg-green-100 text-green-600 border-green-200"
                                              : student.status === "pending"
                                                ? "bg-yellow-100 text-yellow-600 border-yellow-200"
                                                : "bg-slate-100 text-slate-600 border-slate-200"
                                          }`}
                                        >
                                          {student.status}
                                        </span>
                                        <button
                                          onClick={() =>
                                            handleViewStudent(student.id)
                                          }
                                          className="p-4 bg-orange-50 text-orange-400 hover:bg-orange-500 hover:text-white rounded-2xl transition-all active:scale-90 shadow-sm"
                                        >
                                          <ChevronRight className="h-5 w-5" />
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            );
                          })()}

                          {batches
                            .filter((batch) => !selectedBatch || selectedBatch === "all" || String(batch.id) === String(selectedBatch))
                            .map((batch) => {
                            const batchStudents =
                              studentsByBatch[batch.id] || [];
                            if (batchStudents.length === 0) return null;

                            return (
                              <div
                                key={batch.id}
                                className="glass rounded-[2.5rem] shadow-2xl border border-white/60 overflow-hidden bg-white/30 backdrop-blur-xl"
                              >
                                <div className="bg-gradient-to-r from-slate-600/10 to-transparent px-10 py-6 border-b border-white/40 flex justify-between items-center">
                                  <div className="flex items-center gap-4">
                                    <div className="p-2 rounded-xl bg-slate-100 text-slate-600">
                                      <Layers className="h-5 w-5" />
                                    </div>
                                    <h3 className="text-xl font-black text-slate-900 tracking-tight">
                                      {batch.name}
                                    </h3>
                                  </div>
                                  <div className="flex items-center gap-4 border border-white/60 p-1 rounded-full bg-white/50 backdrop-blur-xl shrink-0">
                                    <button 
                                      onClick={() => {
                                        setActiveTab("sms_center");
                                        // A user would then select this batch in the SMS center
                                      }}
                                      className="px-4 py-1.5 bg-orange-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest border border-white shadow-sm hover:bg-orange-700 transition"
                                    >
                                      SMS Batch
                                    </button>
                                    <span className="px-4 py-1.5 bg-white text-slate-500 rounded-full text-[10px] font-black uppercase tracking-widest border border-white shadow-sm">
                                      {batchStudents.length} Students
                                    </span>
                                  </div>
                                </div>
                                <div className="overflow-x-auto custom-scrollbar">
                                  <table className="w-full text-left border-collapse">
                                    <thead>
                                      <tr className="border-b border-white/20">
                                        <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                          Student Info
                                        </th>
                                        <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">
                                          Roll
                                        </th>
                                        <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                          Contact
                                        </th>
                                        <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">
                                          Status
                                        </th>
                                        <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">
                                          Action
                                        </th>
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-white/20">
                                      {batchStudents.slice(0, 50).map((student) => (
                                        <tr
                                          key={student.id}
                                          className="hover:bg-white/40 transition-all group"
                                        >
                                          <td className="px-10 py-6">
                                            <div className="flex items-center gap-5">
                                              <div className="relative">
                                                <div className="w-14 h-14 rounded-2xl bg-orange-100 flex items-center justify-center text-orange-600 font-black text-xl border-2 border-white shadow-lg group-hover:scale-110 transition-transform duration-500 overflow-hidden">
                                                  {student.profile_pic ? (
                                                    <img
                                                      src={student.profile_pic}
                                                      alt={student.name}
                                                      className="w-full h-full object-cover"
                                                      referrerPolicy="no-referrer"
                                                    />
                                                  ) : (
                                                    student.name.charAt(0)
                                                  )}
                                                </div>
                                                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full shadow-sm"></div>
                                              </div>
                                              <div>
                                                <div className="font-black text-slate-900 group-hover:text-orange-600 transition-colors text-base">
                                                  {student.name}
                                                </div>
                                                <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-0.5">
                                                  {student.program_title ||
                                                    "No Program"}
                                                </div>
                                              </div>
                                            </div>
                                          </td>
                                          <td className="px-10 py-6 text-center">
                                            <span className="font-black text-orange-600 bg-orange-50 px-3 py-1.5 rounded-xl text-xs border border-orange-100 shadow-sm">
                                              {student.roll_number || "-"}
                                            </span>
                                          </td>
                                          <td className="px-10 py-6">
                                            <div className="flex flex-col gap-1">
                                              <div className="text-xs font-black text-slate-600 flex items-center gap-2">
                                                <Phone className="h-3 w-3 text-orange-500" />{" "}
                                                {student.phone}
                                              </div>
                                              {student.guardian_phone && (
                                                <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest flex items-center gap-2">
                                                  <Shield className="h-3 w-3 text-slate-300" />{" "}
                                                  G: {student.guardian_phone}
                                                </div>
                                              )}
                                            </div>
                                          </td>
                                          <td className="px-10 py-6 text-center">
                                            <span
                                              className={`px-3 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm border ${
                                                student.status === "approved"
                                                  ? "bg-green-100 text-green-700 border-green-200"
                                                  : student.status === "pending"
                                                    ? "bg-yellow-100 text-yellow-700 border-yellow-200"
                                                    : student.status ===
                                                        "upcoming"
                                                      ? "bg-blue-100 text-blue-700 border-blue-200"
                                                      : student.status ===
                                                          "passed"
                                                        ? "bg-purple-100 text-purple-700 border-purple-200"
                                                        : "bg-slate-100 text-slate-700 border-slate-200"
                                              }`}
                                            >
                                              {student.status}
                                            </span>
                                          </td>
                                          <td className="px-10 py-6 text-right">
                                            <button
                                              onClick={() =>
                                                handleViewStudent(student.id)
                                              }
                                              className="px-5 py-2.5 bg-orange-50 text-orange-600 hover:bg-orange-500 hover:text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-90 shadow-sm flex items-center gap-2 ml-auto"
                                            >
                                              View{" "}
                                              <ChevronRight className="h-4 w-4" />
                                            </button>
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            );
                          })}
                        </>
                      )}
                    </>
                  )}
                </div>
              )}

            {/* Student Details View */}
            {(activeTab === "students" ||
              activeTab === "online_students" ||
              activeTab === "studentSearch") &&
              selectedStudent && (
                <div className="space-y-10">
                  <div className="flex justify-between items-center mb-8">
                    <button
                      onClick={() => {
                        setSelectedStudent(null);
                        setIsEditingStudent(false);
                      }}
                      className="px-6 py-3 bg-white/50 backdrop-blur-md border border-white/60 rounded-2xl text-slate-500 hover:text-orange-600 flex items-center gap-2 font-black uppercase tracking-widest text-[10px] transition-all active:scale-95 shadow-sm"
                    >
                      <ArrowLeft className="h-4 w-4" /> Back to List
                    </button>
                    {!isEditingStudent && (
                      <button
                        onClick={() => {
                          setEditStudentData({ ...selectedStudent });
                          setIsEditingStudent(true);
                        }}
                        className="px-8 py-3 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] hover:from-orange-700 hover:to-orange-600 transition-all shadow-xl shadow-orange-200 flex items-center gap-3 active:scale-95"
                      >
                        <Settings className="h-4 w-4" /> Edit Details
                      </button>
                    )}
                  </div>

                  {isEditingStudent ? (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl"
                    >
                      <div className="flex items-center gap-4 mb-10">
                        <div className="p-3 rounded-2xl bg-orange-100 text-orange-600">
                          <UserCog className="h-6 w-6" />
                        </div>
                        <h3 className="text-3xl font-black text-slate-900 tracking-tight">
                          Edit Student Details
                        </h3>
                      </div>
                      <form
                        onSubmit={handleUpdateStudent}
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
                      >
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Full Name
                          </label>
                          <DebouncedInput
                            type="text"
                            className="glass-input"
                            value={editStudentData.name || ""}
                            onChange={(val: string) =>
                              setEditStudentData({
                                ...editStudentData,
                                name: val,
                              })
                            }
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Email
                          </label>
                          <DebouncedInput
                            type="email"
                            className="glass-input"
                            value={editStudentData.email || ""}
                            onChange={(val: string) =>
                              setEditStudentData({
                                ...editStudentData,
                                email: val,
                              })
                            }
                            required
                          />
                        </div>
                        {editStudentData.student_type !== "online" && (
                          <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                              Roll Number
                            </label>
                            <DebouncedInput
                              type="number"
                              className="glass-input font-mono"
                              value={editStudentData.roll_number || ""}
                              onChange={(val: string) =>
                                setEditStudentData({
                                  ...editStudentData,
                                  roll_number: val,
                                })
                              }
                              required={editStudentData.student_type !== "online"}
                            />
                          </div>
                        )}
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Phone
                          </label>
                          <DebouncedInput
                            type="text"
                            className="glass-input"
                            value={editStudentData.phone || ""}
                            onChange={(val: string) =>
                              setEditStudentData({
                                ...editStudentData,
                                phone: val,
                              })
                            }
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Guardian Phone
                          </label>
                          <DebouncedInput
                            type="text"
                            className="glass-input"
                            value={editStudentData.guardian_phone || ""}
                            onChange={(val: string) =>
                              setEditStudentData({
                                ...editStudentData,
                                guardian_phone: val,
                              })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Address
                          </label>
                          <DebouncedInput
                            type="text"
                            className="glass-input"
                            value={editStudentData.address || ""}
                            onChange={(val: string) =>
                              setEditStudentData({
                                ...editStudentData,
                                address: val,
                              })
                            }
                          />
                        </div>
                        {editStudentData.student_type !== "online" && (
                          <>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Program
                              </label>
                              <select
                                className="glass-select"
                                value={editStudentData.program_id || ""}
                                onChange={(e) => {
                                  const p = programs.find((pr) => pr.id === e.target.value);
                                  setEditStudentData({
                                    ...editStudentData,
                                    program_id: e.target.value,
                                    program_title: p ? p.title : "",
                                    batch_id: "",
                                    class: "",
                                  });
                                }}
                              >
                                <option value="">Select Program</option>
                                {programs.map((p) => (
                                  <option key={p.id} value={p.id}>
                                    {p.title}
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Class
                              </label>
                              <select
                                className="glass-select"
                                value={editStudentData.class || ""}
                                onChange={(e) =>
                                  setEditStudentData({
                                    ...editStudentData,
                                    class: e.target.value,
                                    batch_id: "",
                                  })
                                }
                              >
                                <option value="">Select Class</option>
                                <option value="all">All Classes / Default</option>
                                {Array.from(
                                      new Set(
                                        batches
                                          .filter((b) => String(b.program_id) === String(editStudentData.program_id))
                                          .map((b) => b.class || b.class_name || b.batch_class)
                                          .filter(Boolean)
                                      )
                                    ).map((c: any) => (
                                      <option key={c} value={c}>
                                        {c}
                                      </option>
                                ))}
                              </select>
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Admission Month
                              </label>
                              <select
                                className="glass-select"
                                value={editStudentData.admission_month || ""}
                                onChange={(e) =>
                                  setEditStudentData({
                                    ...editStudentData,
                                    admission_month: e.target.value,
                                  })
                                }
                              >
                                <option value="">Select Month</option>
                                {MONTHS.map((m) => (
                                  <option key={m} value={m}>
                                    {m}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </>
                        )}
                        {editStudentData.student_type !== "online" && (
                          <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                              Batch
                            </label>
                            <select
                              className="glass-select"
                              value={editStudentData.batch_id || ""}
                              onChange={(e) => {
                                const batch = batches.find(
                                  (b) => b.id == e.target.value,
                                );
                                setEditStudentData({
                                  ...editStudentData,
                                  batch_id: e.target.value,
                                  batch_days: batch?.batch_days || "",
                                  batch_time: batch?.batch_time || "",
                                });
                              }}
                            >
                              <option value="">Select Batch</option>
                              {getFilteredBatches(
                                editStudentData.program_id,
                                editStudentData.class
                              ).map((b) => (
                                <option key={b.id} value={b.id}>
                                  {b.name}
                                </option>
                              ))}
                            </select>
                          </div>
                        )}
                        {editStudentData.student_type === "online" && (
                          <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                              Course
                            </label>
                            <select
                              className="glass-select"
                              value={editStudentData.course_id || ""}
                              onChange={(e) => {
                                const course = courses.find(
                                  (c) =>
                                    String(c.id) === String(e.target.value),
                                );
                                setEditStudentData({
                                  ...editStudentData,
                                  course_id: e.target.value,
                                  course_title: course?.title || "",
                                });
                              }}
                            >
                              <option value="">Select Course</option>
                              {courses.map((c) => (
                                <option key={c.id} value={c.id}>
                                  {c.title}
                                </option>
                              ))}
                            </select>
                          </div>
                        )}
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Admission Fee
                          </label>
                          <DebouncedInput
                            type="number"
                            className="glass-input"
                            value={editStudentData.admission_fee || ""}
                            onChange={(val: string) =>
                              setEditStudentData({
                                ...editStudentData,
                                admission_fee: val,
                              })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Monthly Fee
                          </label>
                          <DebouncedInput
                            type="number"
                            className="glass-input"
                            value={editStudentData.monthly_fee || ""}
                            onChange={(val: string) =>
                              setEditStudentData({
                                ...editStudentData,
                                monthly_fee: val,
                              })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Paid Amount
                          </label>
                          <DebouncedInput
                            type="number"
                            className="glass-input"
                            value={editStudentData.paid_amount || ""}
                            onChange={(val: string) =>
                              setEditStudentData({
                                ...editStudentData,
                                paid_amount: val,
                              })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Status
                          </label>
                          <select
                            className="glass-select"
                            value={editStudentData.status || ""}
                            onChange={(e) =>
                              setEditStudentData({
                                ...editStudentData,
                                status: e.target.value,
                              })
                            }
                          >
                            <option value="pending">Pending</option>
                            <option value="approved">Approved</option>
                            <option value="active">Active</option>
                            <option value="upcoming">Upcoming</option>
                            <option value="passed">Passed</option>
                          </select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Student Type
                          </label>
                          <select
                            className="glass-select"
                            value={editStudentData.student_type || ""}
                            onChange={(e) =>
                              setEditStudentData({
                                ...editStudentData,
                                student_type: e.target.value,
                              })
                            }
                          >
                            <option value="offline">Offline</option>
                            <option value="online">Online</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                            Profile Picture URL
                          </label>
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center gap-3">
                              {editStudentData.profile_pic && (
                                <div className="w-12 h-12 rounded-xl overflow-hidden border border-slate-200 shrink-0 relative group">
                                  <img
                                    src={editStudentData.profile_pic}
                                    className="w-full h-full object-cover"
                                    alt="Preview"
                                    referrerPolicy="no-referrer"
                                  />
                                  <div
                                    className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center cursor-pointer"
                                    onClick={() =>
                                      setEditStudentData({
                                        ...editStudentData,
                                        profile_pic: "",
                                      })
                                    }
                                  >
                                    <X className="h-4 w-4 text-white" />
                                  </div>
                                </div>
                              )}
                              <input
                                type="text"
                                className={`glass-input flex-1 ${editStudentData.profile_pic?.startsWith("data:image") ? "opacity-50" : ""}`}
                                value={
                                  editStudentData.profile_pic?.startsWith(
                                    "data:image",
                                  )
                                    ? "Linked via File Upload"
                                    : editStudentData.profile_pic || ""
                                }
                                onChange={(e) =>
                                  setEditStudentData({
                                    ...editStudentData,
                                    profile_pic: e.target.value,
                                  })
                                }
                                disabled={editStudentData.profile_pic?.startsWith(
                                  "data:image",
                                )}
                                placeholder="Paste image URL here"
                              />
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="file"
                                id="edit-student-profile-upload"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    processImage(file, (dataUrl) =>
                                      setEditStudentData({
                                        ...editStudentData,
                                        profile_pic: dataUrl,
                                      }),
                                    );
                                    e.target.value = ""; // clear input
                                  }
                                }}
                              />
                              <label
                                htmlFor="edit-student-profile-upload"
                                className="cursor-pointer bg-orange-50 text-orange-600 px-4 py-2 rounded-xl font-bold text-xs hover:bg-orange-100 transition-all border border-orange-200 flex items-center gap-2"
                              >
                                <Upload className="h-4 w-4" /> Choose File
                              </label>
                            </div>
                          </div>
                        </div>
                        <div className="col-span-1 md:col-span-2 lg:col-span-3 flex gap-6 mt-10">
                          <button
                            type="submit"
                            className="flex-1 bg-gradient-to-r from-orange-600 to-orange-500 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:from-orange-700 hover:to-orange-600 transition-all shadow-xl shadow-orange-200 active:scale-95 flex items-center justify-center gap-3"
                          >
                            <Save className="h-5 w-5" /> Save Changes
                          </button>
                          <button
                            type="button"
                            onClick={() => setIsEditingStudent(false)}
                            className="flex-1 bg-slate-100 text-slate-600 py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-slate-200 transition-all active:scale-95"
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    </motion.div>
                  ) : (
                    <div className="space-y-10">
                      <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl">
                        <div className="flex flex-col md:flex-row gap-10 items-start md:items-center">
                          <div className="relative">
                            <div className="w-40 h-40 rounded-[2rem] bg-white flex items-center justify-center text-orange-600 font-black text-6xl border-4 border-white shadow-2xl overflow-hidden">
                              {selectedStudent.profile_pic ? (
                                <img
                                  src={selectedStudent.profile_pic}
                                  alt={selectedStudent.name}
                                  className="w-full h-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                selectedStudent.name.charAt(0)
                              )}
                            </div>
                            <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-green-500 border-4 border-white rounded-full shadow-lg"></div>
                          </div>
                          <div className="flex-1 space-y-4">
                            <div className="flex flex-wrap items-center gap-4">
                              <h2 className="text-5xl font-black text-slate-900 tracking-tighter">
                                {selectedStudent.name}
                              </h2>
                              <span
                                className={`px-4 py-1.5 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-sm border ${
                                  selectedStudent.status === "approved"
                                    ? "bg-green-100 text-green-600 border-green-200"
                                    : selectedStudent.status === "pending"
                                      ? "bg-yellow-100 text-yellow-600 border-yellow-200"
                                      : "bg-slate-100 text-slate-600 border-slate-200"
                                }`}
                              >
                                {selectedStudent.status}
                              </span>
                            </div>
                            <div className="flex flex-wrap gap-6 text-slate-400 font-black uppercase tracking-widest text-xs">
                              <div className="flex items-center gap-2.5 bg-white/50 px-4 py-2 rounded-xl border border-white/60 shadow-sm">
                                <Hash className="h-4 w-4 text-orange-500" />{" "}
                                Roll:{" "}
                                <span className="text-slate-900">
                                  {selectedStudent.roll_number}
                                </span>
                              </div>
                              <div className="flex items-center gap-2.5 bg-white/50 px-4 py-2 rounded-xl border border-white/60 shadow-sm">
                                <Mail className="h-4 w-4 text-orange-500" />{" "}
                                {selectedStudent.email}
                              </div>
                              <div className="flex items-center gap-2.5 bg-white/50 px-4 py-2 rounded-xl border border-white/60 shadow-sm">
                                <Phone className="h-4 w-4 text-orange-500" />{" "}
                                {selectedStudent.phone}
                              </div>
                              <div className="flex items-center gap-2.5 bg-white/50 px-4 py-2 rounded-xl border border-white/60 shadow-sm">
                                <Users className="h-4 w-4 text-orange-500" />{" "}
                                Guardian: {selectedStudent.guardian_phone || "N/A"}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                        <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl space-y-8">
                          <div className="flex items-center gap-4 pb-6 border-b border-white/40">
                            <div className="p-2.5 rounded-xl bg-orange-100 text-orange-600">
                              <GraduationCap className="h-5 w-5" />
                            </div>
                            <h4 className="text-xl font-black text-slate-900 tracking-tight">
                              Academic Details
                            </h4>
                          </div>
                          {selectedStudent.student_type === "online" ? (
                            <div className="grid grid-cols-1 gap-8">
                              <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                  Enrolled Courses
                                </p>
                                <div className="flex flex-col gap-2 mt-2">
                                  {selectedStudent.enrollments?.filter((e: any) => e.status === "approved" || e.status === "contacted").length > 0 ? (
                                    selectedStudent.enrollments.filter((e: any) => e.status === "approved" || e.status === "contacted").map((en: any) => (
                                       <div key={en.id} className="text-sm font-black text-slate-900 bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center justify-between">
                                          <span>{courses.find((c: any) => String(c.id) === String(en.course_id))?.title || `Course ID: ${en.course_id}`}</span>
                                          <span className="text-green-600 bg-green-50 px-2 py-1 rounded text-[10px] uppercase border border-green-200">Active</span>
                                       </div>
                                    ))
                                  ) : (
                                    <p className="text-sm font-bold text-slate-400">No active course enrollments.</p>
                                  )}
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="grid grid-cols-2 gap-8">
                              <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                  Program
                                </p>
                                <p className="text-sm font-black text-slate-900">
                                  {selectedStudent.program_title || "-"}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                  Batch
                                </p>
                                <p className="text-sm font-black text-slate-900">
                                  {batches.find(
                                    (b) => String(b.id) === String(selectedStudent.batch_id),
                                  )?.name || "-"}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                  Schedule
                                </p>
                                <p className="text-sm font-black text-slate-900">
                                  {(() => {
                                    const studentBatch = batches.find((b) => b.id === selectedStudent?.batch_id);
                                    const bd = selectedStudent?.batch_days || studentBatch?.batch_days || "";
                                    const bt = selectedStudent?.batch_time || studentBatch?.batch_time || "";
                                    if (!bd && !bt) return "-";
                                    return `${bd} ${bd && bt ? "|" : ""} ${bt}`;
                                  })()}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                  Admission Month
                                </p>
                                <p className="text-sm font-black text-slate-900">
                                  {selectedStudent.admission_month || "-"}
                                </p>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl space-y-8">
                          <div className="flex items-center gap-4 pb-6 border-b border-white/40">
                            <div className="p-2.5 rounded-xl bg-orange-100 text-orange-600">
                              <CreditCard className="h-5 w-5" />
                            </div>
                            <h4 className="text-xl font-black text-slate-900 tracking-tight">
                              Financial Summary
                            </h4>
                          </div>
                          <div className="grid grid-cols-2 gap-8">
                            {selectedStudent.student_type === "online" ? (
                              <>
                                <div className="space-y-1">
                                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                    Total Course Fees
                                  </p>
                                  <p className="text-lg font-black text-orange-600">
                                    ৳{selectedStudent.enrollments?.filter((e: any) => e.status === "approved" || e.status === "contacted").reduce((acc: number, e: any) => acc + (Number(e.fee) || 0), 0) || 0}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                    Total Paid
                                  </p>
                                  <p className="text-lg font-black text-green-600">
                                    ৳{selectedStudent.payments?.reduce((acc: number, p: any) => acc + (Number(p.amount) || 0), 0) || 0}
                                  </p>
                                </div>
                                <div className="space-y-1 col-span-2">
                                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                    Balance Due
                                  </p>
                                  <p className="text-lg font-black text-red-600">
                                    ৳{Math.max(0, (selectedStudent.enrollments?.filter((e: any) => e.status === "approved" || e.status === "contacted").reduce((acc: number, e: any) => acc + (Number(e.fee) || 0), 0) || 0) - (selectedStudent.payments?.reduce((acc: number, p: any) => acc + (Number(p.amount) || 0), 0) || 0))}
                                  </p>
                                </div>
                              </>
                            ) : (
                              <>
                                <div className="space-y-1">
                                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                    Admission Fee
                                  </p>
                                  <p className="text-lg font-black text-orange-600">
                                    ৳{selectedStudent.admission_fee || 0}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                    Monthly Fee
                                  </p>
                                  <p className="text-lg font-black text-orange-600">
                                    ৳{selectedStudent.monthly_fee || 0}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                    Total Paid
                                  </p>
                                  <p className="text-lg font-black text-green-600">
                                    ৳{selectedStudent.paid_amount || 0}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                    Balance Due
                                  </p>
                                  <p className="text-lg font-black text-red-600">
                                    ৳{(Number(selectedStudent.admission_fee) || 0) +
                                      (Number(selectedStudent.monthly_fee) || 0) -
                                      (Number(selectedStudent.paid_amount) || 0)}
                                  </p>
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        {/* Attendance History */}
                        <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl space-y-8">
                          <div className="flex items-center gap-4 pb-6 border-b border-white/40">
                            <div className="p-2.5 rounded-xl bg-green-100 text-green-600">
                              <CheckCircle className="h-5 w-5" />
                            </div>
                            <h4 className="text-xl font-black text-slate-900 tracking-tight">
                              Attendance History
                            </h4>
                          </div>
                          <div className="max-h-80 overflow-y-auto space-y-4 pr-4 custom-scrollbar">
                            {(() => {
                              let allAttendance = [
                                ...(selectedStudent.attendance || []),
                              ];
                              const studentBatch = batches.find(
                                (b) => b.id == selectedStudent.batch_id,
                              );
                              const batchDays =
                                selectedStudent.batch_days ||
                                studentBatch?.batch_days ||
                                "";

                              if (batchDays) {
                                const startDateStr = selectedStudent.transfer_date || selectedStudent.created_at || selectedStudent.admission_date || selectedStudent.date_of_admission;
                                const startDate = startDateStr ? startOfDay(new Date(startDateStr)) : startOfDay(new Date());
                                const today = startOfDay(new Date());
                                const dayMapping: Record<string, string> = {
                                  Saturday: "Sat",
                                  Sunday: "Sun",
                                  Monday: "Mon",
                                  Tuesday: "Tue",
                                  Wednesday: "Wed",
                                  Thursday: "Thu",
                                  Friday: "Fri",
                                };
                                try {
                                  const intervalDays = eachDayOfInterval({
                                    start: startDate,
                                    end: today,
                                  });
                                  intervalDays.forEach((day) => {
                                    const dateStr = format(day, "yyyy-MM-dd");
                                    const dayName = format(day, "EEEE");
                                    const dayShort = dayMapping[dayName];
                                    
                                    let isClassDay = false;
                                    const normalizedBatchDays = batchDays.toLowerCase().replace(/\s/g, '');
                                    if (normalizedBatchDays === "everyday") {
                                      isClassDay = dayName !== "Friday";
                                    } else if (batchDays.includes(dayShort) || batchDays.includes(dayName)) {
                                      isClassDay = true;
                                    }

                                    if (isClassDay) {
                                      const existing = allAttendance.find(
                                        (a: any) =>
                                          a.date === dateStr &&
                                          a.type !== "exam",
                                      );
                                      if (!existing) {
                                        allAttendance.push({
                                          id: `auto-absent-${dateStr}`,
                                          date: dateStr,
                                          status: "absent",
                                          type: "class",
                                          is_auto: true,
                                        });
                                      }
                                    }
                                  });
                                } catch (e) {
                                  console.error(e);
                                }
                              }
                              
                              // Missed exams
                              const startDateStr = selectedStudent.transfer_date || selectedStudent.created_at || selectedStudent.admission_date || selectedStudent.date_of_admission;
                              const studentExams = exams.filter(e => (String(e.batch_id) === String(selectedStudent.batch_id) || String(e.batch_id) === String(selectedStudent.batch_id_2)) && e.published);
                              studentExams.forEach(exam => {
                                if (exam.date) {
                                   const examDateStr = new Date(exam.date).toISOString().split('T')[0];
                                   if (startDateStr && new Date(examDateStr) >= new Date(startDateStr)) {
                                       const examRecord = allAttendance.find((a: any) => a.date === examDateStr && a.type === "exam");
                                       if (!examRecord) {
                                           allAttendance.push({
                                              id: `auto-exam-${exam.id}`,
                                              date: examDateStr,
                                              time: "N/A",
                                              status: "absent",
                                              type: "exam",
                                              isAuto: true,
                                           });
                                       }
                                   }
                                }
                              });
                              allAttendance.sort(
                                (a: any, b: any) =>
                                  new Date(b.date).getTime() -
                                  new Date(a.date).getTime(),
                              );

                              if (allAttendance.length === 0) {
                                return (
                                  <div className="text-center py-10 text-slate-400 font-black uppercase tracking-widest text-[10px]">
                                    No attendance records
                                  </div>
                                );
                              }

                              return allAttendance.map((record: any) => {
                                const isExam = record.type === "exam";
                                const examName = isExam
                                  ? exams.find(
                                      (e) =>
                                        String(e.id) === String(record.exam_id),
                                    )?.exam_name
                                  : null;
                                return (
                                  <div
                                    key={record.id}
                                    className="flex justify-between items-center p-5 bg-white/50 border border-white/60 rounded-2xl shadow-sm group hover:bg-white transition-all"
                                  >
                                    <span
                                      className={`font-black uppercase tracking-widest text-[10px] ${isExam ? "text-purple-600" : "text-slate-600"}`}
                                    >
                                      {isExam
                                        ? `Exam: ${examName || "Unknown"} - ${record.date}`
                                        : record.date}
                                    </span>
                                    <span
                                      className={`px-3 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm border ${
                                        record.status === "present"
                                          ? isExam
                                            ? "bg-purple-100 text-purple-600 border-purple-200"
                                            : "bg-green-100 text-green-600 border-green-200"
                                          : "bg-red-100 text-red-600 border-red-200"
                                      }`}
                                    >
                                      {record.status}
                                    </span>
                                  </div>
                                );
                              });
                            })()}
                          </div>
                        </div>

                        {/* Payment History */}
                        <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl space-y-8">
                          <div className="flex items-center gap-4 pb-6 border-b border-white/40">
                            <div className="p-2.5 rounded-xl bg-orange-100 text-orange-600">
                              <CreditCard className="h-5 w-5" />
                            </div>
                            <h4 className="text-xl font-black text-slate-900 tracking-tight">
                              Payment History
                            </h4>
                          </div>
                          <div className="max-h-80 overflow-y-auto space-y-4 pr-4 custom-scrollbar">
                            {(() => {
                              if (selectedStudent?.student_type === "online") {
                                const onlinePayments = selectedStudent.payments || [];
                                if (onlinePayments.length === 0) {
                                  return (
                                    <div className="text-center py-10 text-slate-400 font-black uppercase tracking-widest text-[10px]">
                                      No payment history found
                                    </div>
                                  );
                                }
                                return onlinePayments.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((payment: any) => (
                                  <div
                                    key={payment.id}
                                    className="flex justify-between items-center p-5 bg-white/50 border border-white/60 rounded-2xl shadow-sm group hover:bg-white transition-all"
                                  >
                                    <div>
                                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                        {format(new Date(payment.date), "dd MMM yyyy")}
                                      </div>
                                      <div className="text-xs font-black text-slate-900 uppercase tracking-widest mt-1">
                                        {payment.type} Fee
                                      </div>
                                    </div>
                                    <span className="font-black text-green-600 text-xl flex items-center gap-2">
                                      <CheckCircle2 className="h-5 w-5" /> ৳{payment.amount}
                                    </span>
                                  </div>
                                ));
                              }

                              const admissionMonthStr =
                                selectedStudent?.admission_month || "January";
                              const admissionMonthIndex =
                                MONTHS.indexOf(admissionMonthStr);
                              const currentYear = new Date().getFullYear();
                              const admissionYear = selectedStudent.created_at
                                ? new Date(
                                    selectedStudent.created_at,
                                  ).getFullYear()
                                : currentYear;

                              return MONTHS.map((month, index) => {
                                if (index < admissionMonthIndex) return null;

                                const payment = selectedStudent.payments?.find(
                                  (p: any) =>
                                    p.type === "monthly" && p.month === month,
                                );
                                const isPaid = !!payment;

                                return (
                                  <div
                                    key={month}
                                    className="flex justify-between items-center p-5 bg-white/50 border border-white/60 rounded-2xl shadow-sm group hover:bg-white transition-all"
                                  >
                                    <div>
                                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                        {month} {admissionYear}
                                      </div>
                                      <div className="text-xs font-black text-slate-900 uppercase tracking-widest mt-1">
                                        Monthly Fee
                                      </div>
                                    </div>
                                    {isPaid ? (
                                      <span className="font-black text-green-600 text-xl flex items-center gap-2">
                                        <CheckCircle2 className="h-5 w-5" /> ৳
                                        {payment.amount}
                                      </span>
                                    ) : (
                                      <span className="font-black text-orange-400 text-xl flex items-center gap-2 opacity-50">
                                        <Clock className="h-5 w-5" /> Unpaid
                                      </span>
                                    )}
                                  </div>
                                );
                              });
                            })()}
                            {(!selectedStudent.payments ||
                              selectedStudent.payments.length === 0) && (
                              <div className="text-center py-10 text-slate-400 font-black uppercase tracking-widest text-[10px]">
                                No payment records
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Results History */}
                      <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl space-y-8">
                        <div className="flex items-center gap-4 pb-6 border-b border-white/40">
                          <div className="p-2.5 rounded-xl bg-indigo-100 text-indigo-600">
                            <FileText className="h-5 w-5" />
                          </div>
                          <h4 className="text-xl font-black text-slate-900 tracking-tight">
                            Results History
                          </h4>
                        </div>
                        <div className="max-h-80 overflow-y-auto space-y-4 pr-4 custom-scrollbar">
                          {selectedStudent.results &&
                          selectedStudent.results.length > 0 ? (
                            selectedStudent.results.map((res: any) => {
                              let calculatedMerit = res.merit_position;
                              if (!calculatedMerit) {
                                const key = res.exam_id || res.exam_name;
                                if (key && meritPositions[key]) {
                                  calculatedMerit =
                                    meritPositions[key][selectedStudent.id];
                                }
                              }
                              return (
                                <div
                                  key={res.id || Math.random()}
                                  className="flex justify-between items-center p-6 bg-white/50 border border-white/60 rounded-2xl shadow-sm group hover:bg-white transition-all"
                                >
                                  <div className="space-y-1">
                                    <span className="font-black text-slate-900 uppercase tracking-widest text-sm">
                                      {res.exam_name}
                                    </span>
                                    <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest">
                                      {res.date || "N/A"}
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-8">
                                    {calculatedMerit && (
                                      <div className="text-center">
                                        <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                          Merit
                                        </div>
                                        <div className="text-lg font-black text-indigo-600">
                                          #{calculatedMerit}
                                        </div>
                                      </div>
                                    )}
                                    <div className="text-center">
                                      <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                        Score
                                      </div>
                                      <div className="text-lg font-black text-orange-600">
                                        {res.marks}/{res.total_marks}
                                      </div>
                                    </div>
                                    <div className="text-center">
                                      <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                        Status
                                      </div>
                                      <div
                                        className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest ${
                                          res.status === "Pass"
                                            ? "bg-green-100 text-green-600"
                                            : "bg-red-100 text-red-600"
                                        }`}
                                      >
                                        {res.status}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })
                          ) : (
                            <div className="text-center py-10 text-slate-400 font-black uppercase tracking-widest text-[10px]">
                              No exam results found
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Course/Program Details */}
                      <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl space-y-8">
                        <div className="flex items-center gap-4 pb-6 border-b border-white/40">
                          <div className="p-2.5 rounded-xl bg-blue-100 text-blue-600">
                            <BookOpen className="h-5 w-5" />
                          </div>
                          <h4 className="text-xl font-black text-slate-900 tracking-tight">
                            {selectedStudent.student_type === "online"
                              ? "Enrolled Courses"
                              : "Program Details"}
                          </h4>
                        </div>

                        {selectedStudent.student_type === "online" ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            {selectedStudent.enrolled_courses &&
                            selectedStudent.enrolled_courses.length > 0 ? (
                              selectedStudent.enrolled_courses.map(
                                (course: any) => (
                                  <div
                                    key={course.id}
                                    className="bg-white/50 p-6 rounded-2xl border border-white/60 shadow-sm flex justify-between items-center group hover:bg-white transition-all"
                                  >
                                    <div>
                                      <div className="font-black text-slate-900 uppercase tracking-widest text-sm">
                                        {course.title}
                                      </div>
                                      <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">
                                        Enrolled:{" "}
                                        {new Date(
                                          course.enrolled_at,
                                        ).toLocaleDateString()}
                                      </div>
                                    </div>
                                    <span className="px-3 py-1 bg-blue-100 text-blue-600 border border-blue-200 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm">
                                      {course.status || "Active"}
                                    </span>
                                  </div>
                                ),
                              )
                            ) : (
                              <div className="text-center py-10 text-slate-400 font-black uppercase tracking-widest text-[10px] col-span-full">
                                No enrolled courses found
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div className="bg-white/50 p-6 rounded-2xl border border-white/60 shadow-sm flex flex-col group hover:bg-white transition-all">
                              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">
                                Program
                              </span>
                              <span className="font-black text-slate-900 text-sm">
                                {selectedStudent.program_title ||
                                  selectedStudent.program_id ||
                                  "N/A"}
                              </span>
                            </div>
                            <div className="bg-white/50 p-6 rounded-2xl border border-white/60 shadow-sm flex flex-col group hover:bg-white transition-all">
                              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">
                                Batch
                              </span>
                              <span className="font-black text-slate-900 text-sm">
                                {batches.find(
                                  (b) =>
                                    String(b.id) ===
                                    String(selectedStudent.batch_id),
                                )?.name ||
                                  selectedStudent.batch_id ||
                                  "N/A"}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex justify-center pt-10">
                        <button
                          onClick={() =>
                            handleCancelRegistration(selectedStudent.id)
                          }
                          className="px-10 py-4 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all active:scale-95 shadow-sm border border-red-100 flex items-center gap-3"
                        >
                          <UserMinus className="h-4 w-4" /> Cancel Registration
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

            {/* Batches Tab */}
            {activeTab === "batches" && (
              <div className="space-y-10">
                {authLoading ? (
                  <TableSkeleton />
                ) : (
                  <>
                    <div className="flex justify-between items-center">
                      <div className="space-y-1">
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                          <BookOpen className="h-10 w-10 text-orange-600" />{" "}
                          Batch Management
                        </h2>
                        <p className="text-slate-500 font-black uppercase tracking-widest text-[10px]">
                          Create and oversee student batches
                        </p>
                      </div>
                      <button
                        onClick={() => clearForm("batch")}
                        className="px-4 py-2 bg-white/50 hover:bg-white text-slate-400 hover:text-slate-600 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all border border-white/60 shadow-sm flex items-center gap-2"
                      >
                        <XCircle className="h-4 w-4" /> Clear Form
                      </button>
                    </div>

                    <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl">
                      <div className="flex items-center gap-4 mb-8">
                        <div className="p-2.5 rounded-xl bg-orange-100 text-orange-600">
                          <Plus className="h-5 w-5" />
                        </div>
                        <h3 className="text-xl font-black text-slate-900 tracking-tight">
                          Add New Batch
                        </h3>
                      </div>
                      <form
                        onSubmit={handleAddBatch}
                        className="grid grid-cols-1 md:grid-cols-4 gap-6"
                      >
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Batch Name
                          </label>
                          <input
                            type="text"
                            placeholder="e.g., Target A+ Batch 01"
                            className="glass-input w-full"
                            value={newBatch.name}
                            onChange={(e) =>
                              setNewBatch((prev) => ({
                                ...prev,
                                name: e.target.value,
                              }))
                            }
                            required
                          />
                        </div>
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Program
                          </label>
                          <select
                            className="glass-select w-full"
                            value={newBatch.program_id}
                            onChange={(e) =>
                              setNewBatch((prev) => ({
                                ...prev,
                                program_id: e.target.value,
                              }))
                            }
                            required
                          >
                            <option value="">Select Program</option>
                            {programs.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.title}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Batch Days
                          </label>
                          <div className="flex flex-wrap gap-2">
                            {["Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri"].map((day) => (
                              <label
                                key={day}
                                className={`cursor-pointer px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-widest border transition-all ${
                                  (newBatch.batch_days || "").includes(day)
                                    ? "bg-orange-600 text-white border-orange-600 shadow-md"
                                    : "bg-white/50 text-slate-500 border-slate-200 hover:bg-slate-100"
                                }`}
                              >
                                <input
                                  type="checkbox"
                                  className="hidden"
                                  checked={(newBatch.batch_days || "").includes(day)}
                                  onChange={(e) => {
                                    let currentDays = (newBatch.batch_days || "").split(",").filter((d) => d.trim() !== "");
                                    if (e.target.checked) {
                                      currentDays.push(day);
                                    } else {
                                      currentDays = currentDays.filter((d) => d !== day);
                                    }
                                    setNewBatch((prev) => ({
                                      ...prev,
                                      batch_days: currentDays.join(","),
                                    }));
                                  }}
                                />
                                {day}
                              </label>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Batch Time
                          </label>
                          <input
                            type="text"
                            placeholder="e.g., 4:00 PM"
                            className="glass-input w-full"
                            value={newBatch.batch_time}
                            onChange={(e) =>
                              setNewBatch((prev) => ({
                                ...prev,
                                batch_time: e.target.value,
                              }))
                            }
                            required
                            list="batch-times"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Class
                          </label>
                          <input
                            type="text"
                            placeholder="Class"
                            className="glass-input w-full"
                            value={newBatch.class}
                            onChange={(e) =>
                              setNewBatch((prev) => ({
                                ...prev,
                                class: e.target.value,
                              }))
                            }
                            required
                          />
                        </div>
                        <div className="md:col-span-3 space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Live Class Link (Optional)
                          </label>
                          <input
                            type="url"
                            placeholder="https://..."
                            className="glass-input w-full"
                            value={newBatch.live_class_link}
                            onChange={(e) =>
                              setNewBatch((prev) => ({
                                ...prev,
                                live_class_link: e.target.value,
                              }))
                            }
                          />
                        </div>
                        <div className="md:col-span-1 flex items-end">
                          <button
                            type="submit"
                            className="w-full py-4 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all active:scale-95 shadow-lg shadow-orange-200 flex items-center justify-center gap-2"
                          >
                            <Plus className="h-5 w-5" /> Add Batch
                          </button>
                        </div>
                      </form>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                      {batches.map((batch) => (
                        <div
                          key={batch.id}
                          className="glass p-8 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl relative group cursor-pointer hover:bg-white/40 transition-all"
                          onClick={() => {
                            setActiveTab("students");
                            setSelectedBatch(batch.id);
                            setSearchTerm("");
                          }}
                        >
                          <div className="flex justify-between items-start mb-6">
                            <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                              {batch.name}
                            </h3>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteBatch(batch.id);
                              }}
                              className="text-slate-400 hover:text-red-600 p-2 rounded-xl hover:bg-red-50 transition-all opacity-0 group-hover:opacity-100"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          </div>
                          <div className="space-y-4 mb-8">
                            <div className="flex items-center gap-3 bg-white/50 p-3 rounded-2xl border border-white/60 shadow-sm">
                              <div className="p-1.5 rounded-lg bg-orange-100 text-orange-600">
                                <GraduationCap className="h-4 w-4" />
                              </div>
                              <p className="text-sm font-black text-slate-900 uppercase tracking-widest">
                                Class: {batch.class || "N/A"}
                              </p>
                            </div>
                            <div className="flex items-center gap-3 bg-white/50 p-3 rounded-2xl border border-white/60 shadow-sm">
                              <div className="p-1.5 rounded-lg bg-blue-100 text-blue-600">
                                <Calendar className="h-4 w-4" />
                              </div>
                              <p className="text-sm font-black text-slate-900 uppercase tracking-widest">
                                {batch.batch_days || batch.days || "Not set"}
                              </p>
                            </div>
                            <div className="flex items-center gap-3 bg-white/50 p-3 rounded-2xl border border-white/60 shadow-sm">
                              <div className="p-1.5 rounded-lg bg-green-100 text-green-600">
                                <Clock className="h-4 w-4" />
                              </div>
                              <p className="text-sm font-black text-slate-900 uppercase tracking-widest">
                                {batch.batch_time || batch.time || "Not set"}
                              </p>
                            </div>
                          </div>
                          {batch.live_class_link && (
                            <div className="mb-6 p-3 bg-orange-50 rounded-2xl border border-orange-100">
                              <p className="text-orange-600 text-[10px] font-black uppercase tracking-widest truncate flex items-center gap-2">
                                <LinkIcon className="h-3 w-3" />{" "}
                                {batch.live_class_link}
                              </p>
                            </div>
                          )}
                          <div className="flex justify-between items-center pt-6 border-t border-white/40">
                            <span className="bg-white/60 text-slate-900 px-4 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-sm border border-white/60">
                              {(allStudentsByBatch[batch.id] || []).length}{" "}
                              Students
                            </span>
                            <div className="text-orange-600 font-black uppercase tracking-widest text-[10px] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                              View Students <ArrowRight className="h-3 w-3" />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Notices Tab */}
            {activeTab === "notices" && (
              <div className="space-y-10">
                {authLoading ? (
                  <TableSkeleton />
                ) : (
                  <>
                    <div className="flex justify-between items-center">
                      <div className="space-y-1">
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                          <Bell className="h-10 w-10 text-orange-600" /> Notices
                        </h2>
                        <p className="text-slate-500 font-black uppercase tracking-widest text-[10px]">
                          Broadcast announcements to students
                        </p>
                      </div>
                      <button
                        onClick={() => clearForm("notice")}
                        className="px-4 py-2 bg-white/50 hover:bg-white text-slate-400 hover:text-slate-600 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all border border-white/60 shadow-sm flex items-center gap-2"
                      >
                        <XCircle className="h-4 w-4" /> Clear Form
                      </button>
                    </div>

                    <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl">
                      <div className="flex items-center gap-4 mb-8">
                        <div className="p-2.5 rounded-xl bg-orange-100 text-orange-600">
                          <Plus className="h-5 w-5" />
                        </div>
                        <h3 className="text-xl font-black text-slate-900 tracking-tight">
                          Add New Notice
                        </h3>
                      </div>
                      <form onSubmit={handleAddNotice} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Program
                            </label>
                            <select
                              className="glass-select w-full"
                              value={newNotice.program_id}
                              onChange={(e) =>
                                setNewNotice((prev) => ({
                                  ...prev,
                                  program_id: e.target.value,
                                  batch_id: "",
                                }))
                              }
                            >
                              <option value="">Select Program</option>
                              {programs.map((p) => (
                                <option key={p.id} value={p.id}>
                                  {p.title}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Batch
                            </label>
                            <select
                              className="glass-select w-full"
                              value={newNotice.batch_id}
                              onChange={(e) =>
                                setNewNotice((prev) => ({
                                  ...prev,
                                  batch_id: e.target.value,
                                }))
                              }
                              disabled={!newNotice.program_id}
                            >
                              <option value="">
                                {newNotice.program_id
                                  ? "All Batches"
                                  : "Select Program First"}
                              </option>
                              {getFilteredBatches(newNotice.program_id).map(
                                (b) => (
                                  <option key={b.id} value={b.id}>
                                    {b.name}
                                  </option>
                                ),
                              )}
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Target Audience
                            </label>
                            <select
                              className="glass-select w-full"
                              value={newNotice.target_audience}
                              onChange={(e) =>
                                setNewNotice((prev) => ({
                                  ...prev,
                                  target_audience: e.target.value,
                                }))
                              }
                            >
                              <option value="all">All Students</option>
                              <option value="offline">
                                Academic Students Only
                              </option>
                              <option value="online">
                                Online Students Only
                              </option>
                            </select>
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Title
                            </label>
                            <input
                              type="text"
                              placeholder="Notice Title"
                              className="glass-input w-full"
                              value={newNotice.title}
                              onChange={(e) =>
                                setNewNotice((prev) => ({
                                  ...prev,
                                  title: e.target.value,
                                }))
                              }
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Author
                            </label>
                            <input
                              type="text"
                              placeholder="Author Name"
                              className="glass-input w-full"
                              value={newNotice.author}
                              onChange={(e) =>
                                setNewNotice((prev) => ({
                                  ...prev,
                                  author: e.target.value,
                                }))
                              }
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Attachment URL (Optional)
                          </label>
                          <input
                            type="text"
                            placeholder="https://..."
                            className="glass-input w-full"
                            value={newNotice.attachment_url}
                            onChange={(e) =>
                              setNewNotice((prev) => ({
                                ...prev,
                                attachment_url: e.target.value,
                              }))
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Notice Content
                          </label>
                          <textarea
                            placeholder="Type notice content here..."
                            className="glass-input w-full h-32 resize-none"
                            value={newNotice.content}
                            onChange={(e) =>
                              setNewNotice((prev) => ({
                                ...prev,
                                content: e.target.value,
                              }))
                            }
                            required
                          />
                        </div>
                        <div className="flex items-center gap-3 px-1">
                          <input
                            type="checkbox"
                            id="is_verified"
                            checked={newNotice.is_verified}
                            onChange={(e) =>
                              setNewNotice((prev) => ({
                                ...prev,
                                is_verified: e.target.checked,
                              }))
                            }
                            className="w-5 h-5 text-orange-600 border-white/60 rounded-lg focus:ring-orange-500 bg-white/50"
                          />
                          <label
                            htmlFor="is_verified"
                            className="text-sm font-black text-slate-700 cursor-pointer flex items-center gap-2 uppercase tracking-widest"
                          >
                            <CheckCircle2 className="h-4 w-4 text-blue-600" />
                            Show Verified Badge
                          </label>
                        </div>
                        <button
                          type="submit"
                          className="w-full py-4 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all active:scale-95 shadow-lg shadow-orange-200 flex items-center justify-center gap-2"
                        >
                          <Plus className="h-5 w-5" /> Post Notice
                        </button>
                      </form>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {notices.map((notice) => (
                        <div
                          key={notice.id}
                          className="glass p-8 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl relative group hover:bg-white/40 transition-all"
                        >
                          <div className="flex justify-between items-start mb-6">
                            <div className="space-y-1">
                              <h4 className="font-black text-xl text-slate-900 tracking-tight">
                                {notice.title}
                              </h4>
                              <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">
                                {new Date(notice.date).toLocaleDateString()}
                              </span>
                            </div>
                            <button
                              onClick={() => handleDeleteNotice(notice.id)}
                              className="text-slate-400 hover:text-red-600 p-2 rounded-xl hover:bg-red-50 transition-all opacity-0 group-hover:opacity-100"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          </div>
                          <p className="text-slate-600 text-sm line-clamp-4 leading-relaxed mb-8">
                            {notice.content}
                          </p>
                          <div className="flex justify-between items-center pt-6 border-t border-white/40">
                            <div className="flex flex-wrap gap-2">
                              <span className="inline-block bg-orange-100 text-orange-600 text-[9px] px-3 py-1 rounded-xl font-black uppercase tracking-widest shadow-sm border border-orange-200">
                                Batch:{" "}
                                {batches.find((b) => b.id == notice.batch_id)
                                  ?.name || "All Batches"}
                              </span>
                              {notice.target_audience &&
                                notice.target_audience !== "all" && (
                                  <span className="inline-block bg-blue-100 text-blue-600 text-[9px] px-3 py-1 rounded-xl font-black uppercase tracking-widest shadow-sm border border-blue-200">
                                    {notice.target_audience === "offline"
                                      ? "Academic"
                                      : notice.target_audience}{" "}
                                    Only
                                  </span>
                                )}
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">
                                By:{" "}
                                <span className="text-slate-900">
                                  {notice.admin_name ||
                                    notice.author ||
                                    "Admin"}
                                </span>
                              </span>
                              {notice.is_verified && (
                                <CheckCircle2 className="h-3 w-3 text-blue-600" />
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Gallery Tab */}
            {activeTab === "gallery" && (
              <div className="space-y-10">
                <div className="flex justify-between items-center">
                  <div className="space-y-1">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                      <ImageIcon className="h-10 w-10 text-orange-600" />{" "}
                      Gallery Management
                    </h2>
                    <p className="text-slate-500 font-black uppercase tracking-widest text-[10px]">
                      Upload and manage images for the website
                    </p>
                  </div>
                  <button
                    onClick={() => clearForm("gallery")}
                    className="px-4 py-2 bg-white/50 hover:bg-white text-slate-400 hover:text-slate-600 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all border border-white/60 shadow-sm flex items-center gap-2"
                  >
                    <XCircle className="h-4 w-4" /> Clear Form
                  </button>
                </div>

                <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="p-2.5 rounded-xl bg-orange-100 text-orange-600">
                      <Plus className="h-5 w-5" />
                    </div>
                    <h3 className="text-xl font-black text-slate-900 tracking-tight">
                      Add New Image
                    </h3>
                  </div>
                  <form
                    onSubmit={handleAddImage}
                    className="grid grid-cols-1 md:grid-cols-4 gap-6"
                  >
                    <div className="md:col-span-2 space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Image URL
                      </label>
                      <input
                        type="text"
                        placeholder="https://example.com/image.jpg"
                        value={newImage.image_url}
                        onChange={(e) =>
                          setNewImage({
                            ...newImage,
                            image_url: e.target.value,
                          })
                        }
                        className="glass-input w-full"
                        required
                      />
                    </div>
                    <div className="md:col-span-2 space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Caption
                      </label>
                      <input
                        type="text"
                        placeholder="Image Caption"
                        value={newImage.caption}
                        onChange={(e) =>
                          setNewImage({ ...newImage, caption: e.target.value })
                        }
                        className="glass-input w-full"
                      />
                    </div>
                    <div className="md:col-span-3 space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Category
                      </label>
                      <select
                        className="glass-select w-full"
                        value={newImage.category}
                        onChange={(e) =>
                          setNewImage({ ...newImage, category: e.target.value })
                        }
                      >
                        <option value="General">General</option>
                        <option value="Events">Events</option>
                        <option value="Classes">Classes</option>
                        <option value="Achievements">Achievements</option>
                      </select>
                    </div>
                    <div className="md:col-span-1 flex items-end">
                      <button
                        type="submit"
                        className="w-full py-4 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all active:scale-95 shadow-lg shadow-orange-200 flex items-center justify-center gap-2"
                      >
                        <Plus className="h-5 w-5" /> Add Image
                      </button>
                    </div>
                  </form>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-8">
                  {galleryImages.map((img) => (
                    <div
                      key={img.id}
                      className="glass p-6 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl relative group hover:bg-white/40 transition-all"
                    >
                      <img
                        src={img.image_url}
                        alt={img.caption}
                        className="w-full h-40 object-cover rounded-2xl mb-4 shadow-lg"
                        referrerPolicy="no-referrer"
                        onError={handleImageError}
                      />
                      <div className="flex justify-between items-center mb-3">
                        <p className="text-sm font-black text-slate-900 uppercase tracking-widest truncate w-full pr-4">
                          {img.caption || "No Caption"}
                        </p>
                        <button
                          onClick={() => handleDeleteImage(img.id)}
                          className="text-slate-400 hover:text-red-600 p-2 rounded-xl hover:bg-red-50 transition-all opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                      <span className="inline-block bg-blue-100 text-blue-600 text-[9px] px-3 py-1 rounded-xl font-black uppercase tracking-widest shadow-sm border border-blue-200">
                        {img.category || "General"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Reviews Tab */}
            {activeTab === "reviews" && (
              <div className="space-y-10">
                <div className="flex justify-between items-center">
                  <div className="space-y-1">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                      <MessageSquare className="h-10 w-10 text-orange-600" />{" "}
                      Student Reviews
                    </h2>
                    <p className="text-slate-500 font-black uppercase tracking-widest text-[10px]">
                      Manage and moderate student feedback
                    </p>
                  </div>
                  <button
                    onClick={() => clearForm("review")}
                    className="px-4 py-2 bg-white/50 hover:bg-white text-slate-400 hover:text-slate-600 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all border border-white/60 shadow-sm flex items-center gap-2"
                  >
                    <XCircle className="h-4 w-4" /> Clear Form
                  </button>
                </div>

                <div className="glass p-10 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/50 backdrop-blur-xl">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="p-2.5 rounded-xl bg-orange-100 text-orange-600">
                      <Plus className="h-5 w-5" />
                    </div>
                    <h3 className="text-xl font-black text-slate-900 tracking-tight">
                      Add New Review
                    </h3>
                  </div>
                  <form onSubmit={handleAddReview} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Student Name
                        </label>
                        <input
                          type="text"
                          placeholder="Student Name"
                          className="glass-input w-full bg-white"
                          value={newReview.student_name}
                          onChange={(e) =>
                            setNewReview({
                              ...newReview,
                              student_name: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Student Photo
                        </label>
                        <div className="flex items-center gap-4">
                          {newReview.student_image && (
                            <img
                              src={newReview.student_image}
                              alt="New Review"
                              className="w-12 h-12 rounded-xl object-cover border-2 border-white shadow-xl"
                            />
                          )}
                          <input
                            type="file"
                            accept="image/*"
                            className="text-[10px] text-slate-500 font-bold file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-[10px] file:font-black file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  setNewReview({
                                    ...newReview,
                                    student_image: reader.result as string,
                                  });
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Batch
                        </label>
                        <input
                          type="text"
                          placeholder="Batch (e.g., HSC 2024)"
                          className="glass-input w-full bg-white"
                          value={newReview.batch}
                          onChange={(e) =>
                            setNewReview({
                              ...newReview,
                              batch: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Rating
                        </label>
                        <select
                          className="glass-select w-full bg-white"
                          value={newReview.rating}
                          onChange={(e) =>
                            setNewReview({
                              ...newReview,
                              rating: parseInt(e.target.value),
                            })
                          }
                        >
                          {[5, 4, 3, 2, 1].map((r) => (
                            <option key={r} value={r}>
                              {r} Stars
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Review Content
                      </label>
                      <textarea
                        placeholder="Review Content"
                        className="glass-input w-full h-32 resize-none bg-white"
                        value={newReview.comment}
                        onChange={(e) =>
                          setNewReview({
                            ...newReview,
                            comment: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full py-4 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all active:scale-95 shadow-lg shadow-orange-200 flex items-center justify-center gap-2"
                    >
                      <Plus className="h-5 w-5" /> Add Review
                    </button>
                  </form>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {reviews.map((review) => (
                    <div
                      key={review.id}
                      className={`glass p-8 rounded-[2.5rem] shadow-2xl border border-white/60 bg-white/30 backdrop-blur-xl relative group hover:bg-white/40 transition-all ${review.status === "pending" ? "ring-2 ring-orange-400/50" : ""}`}
                    >
                      <div className="flex items-center gap-6 mb-6">
                        <img
                          src={
                            review.student_image ||
                            `https://ui-avatars.com/api/?name=${review.student_name}&background=random`
                          }
                          alt={review.student_name}
                          className="w-16 h-16 rounded-2xl object-cover border-4 border-white shadow-lg"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-1">
                            <h4 className="text-lg font-black text-slate-900 tracking-tight">
                              {review.student_name}
                            </h4>
                            {review.status === "pending" && (
                              <span className="bg-orange-100 text-orange-600 text-[9px] px-3 py-1 rounded-xl font-black uppercase tracking-widest shadow-sm border border-orange-200">
                                Pending
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            {review.batch} •{" "}
                            {new Date(review.created_at || review.date).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex text-orange-400 text-lg">
                          {Array.from({ length: review.rating }).map((_, i) => (
                            <span key={i}>★</span>
                          ))}
                        </div>
                      </div>
                      <p className="text-slate-600 text-base italic leading-relaxed mb-8 bg-slate-50/50 p-4 rounded-2xl border border-slate-100">
                        "{review.comment}"
                      </p>

                      <div className="flex justify-end gap-3">
                        {review.status === "pending" && (
                          <button
                            onClick={() => handleApproveReview(review.id)}
                            className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-5 py-2.5 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all shadow-lg shadow-green-100"
                          >
                            <CheckCircle className="h-4 w-4" /> Approve
                          </button>
                        )}
                        <button
                          onClick={() => handleDeleteReview(review.id)}
                          className="flex items-center gap-2 bg-white/50 hover:bg-red-50 text-slate-400 hover:text-red-600 px-5 py-2.5 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all border border-white/60"
                        >
                          <Trash2 className="h-4 w-4" /> Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Routines Tab */}
            {activeTab === "routines" && (
              <div className="space-y-10 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                    <Calendar className="h-8 w-8 text-orange-600" /> Class
                    Routine Management
                  </h2>
                  <button
                    onClick={() => clearForm("routine")}
                    className="text-orange-600 hover:text-orange-700 flex items-center gap-2 text-sm font-black uppercase tracking-widest transition-colors"
                  >
                    <XCircle className="h-5 w-5" /> Clear Form
                  </button>
                </div>

                <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
                  <h3 className="text-2xl font-black text-slate-800 mb-10 relative z-10 flex items-center gap-3">
                    <Plus className="h-8 w-8 text-orange-600" /> Add New Routine
                  </h3>
                  <form
                    onSubmit={handleAddRoutine}
                    className="space-y-8 relative z-10"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Program (Offline)
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newRoutine.program_id}
                          onChange={(e) =>
                            setNewRoutine({
                              ...newRoutine,
                              program_id: e.target.value,
                              batch_id: "",
                              course_id: "",
                            })
                          }
                        >
                          <option value="">Select Program</option>
                          {programs.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.title}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Batch (Offline)
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newRoutine.batch_id}
                          onChange={(e) =>
                            setNewRoutine({
                              ...newRoutine,
                              batch_id: e.target.value,
                            })
                          }
                          disabled={!newRoutine.program_id}
                        >
                          <option value="">
                            {newRoutine.program_id
                              ? "Select Batch"
                              : "Select Program First"}
                          </option>
                          <option value="all">All Batches</option>
                          {getFilteredBatches(newRoutine.program_id).map(
                            (b) => (
                              <option key={b.id} value={b.id}>
                                {b.name} ({b.class})
                              </option>
                            ),
                          )}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Course (Online)
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newRoutine.course_id || ""}
                          onChange={(e) =>
                            setNewRoutine({
                              ...newRoutine,
                              course_id: e.target.value,
                              program_id: "",
                              batch_id: "",
                            })
                          }
                        >
                          <option value="">All Courses</option>
                          {courses.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.title}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Routine Image URL
                        </label>
                        <input
                          type="text"
                          placeholder="https://..."
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newRoutine.image_url}
                          onChange={(e) =>
                            setNewRoutine({
                              ...newRoutine,
                              image_url: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                    </div>
                    {newRoutine.image_url && (
                      <div className="mt-2 relative w-full h-64 rounded-3xl overflow-hidden border-4 border-white shadow-2xl">
                        <img
                          src={newRoutine.image_url}
                          alt="Preview"
                          className="w-full h-full object-cover"
                          onError={handleImageError}
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                      </div>
                    )}
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Description (Optional)
                      </label>
                      <textarea
                        placeholder="Describe the routine..."
                        className="glass-input h-32 resize-none border-2 border-orange-100 focus:border-orange-500"
                        value={newRoutine.content}
                        onChange={(e) =>
                          setNewRoutine({
                            ...newRoutine,
                            content: e.target.value,
                          })
                        }
                      />
                    </div>
                    <button
                      type="submit"
                      className="glass-btn w-full text-xl py-5"
                    >
                      <Plus className="h-6 w-6" /> Add Routine
                    </button>
                  </form>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  {routines.map((routine) => (
                    <motion.div
                      key={routine.id}
                      whileHover={{ y: -10 }}
                      className="glass rounded-[40px] shadow-2xl border border-white/40 overflow-hidden group relative transition-all duration-500"
                    >
                      <div className="relative h-80 overflow-hidden">
                        <img
                          src={routine.image_url}
                          alt="Routine"
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                          referrerPolicy="no-referrer"
                          onError={handleImageError}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
                        <div className="absolute top-6 left-6 flex flex-col gap-2">
                          {routine.program_id && (
                            <>
                              <span className="bg-orange-600 text-white px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-lg shadow-orange-600/30 w-fit">
                                {programs.find(
                                  (p) =>
                                    String(p.id) === String(routine.program_id),
                                )?.title || "General"}
                              </span>
                              <span className="bg-slate-800 text-white px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-lg shadow-slate-900/30 w-fit">
                                {routine.batch_id === "all"
                                  ? "All Batches"
                                  : batches.find(
                                      (b) =>
                                        String(b.id) === String(routine.batch_id),
                                    )?.name || "Unknown"}
                              </span>
                            </>
                          )}
                          {routine.course_id && (
                            <span className="bg-blue-600 text-white px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-lg shadow-blue-600/30 w-fit">
                              Online: {courses.find((c) => String(c.id) === String(routine.course_id))?.title || "Unknown"}
                            </span>
                          )}
                          {!routine.program_id && !routine.course_id && (
                            <span className="bg-green-600 text-white px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-lg shadow-green-600/30 w-fit">
                              General (Visible to All)
                            </span>
                          )}
                        </div>
                        <button
                          onClick={() => handleDeleteRoutine(routine.id)}
                          className="absolute top-6 right-6 bg-white/20 backdrop-blur-md text-white p-3 rounded-2xl opacity-0 group-hover:opacity-100 transition-all hover:bg-orange-600 shadow-xl border border-white/30"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                      <div className="p-8">
                        <div className="flex justify-between items-center mb-4">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            Added On
                          </span>
                          <span className="text-sm font-bold text-slate-600">
                            {new Date(routine.created_at).toLocaleDateString(
                              "en-US",
                              {
                                month: "long",
                                day: "numeric",
                                year: "numeric",
                              },
                            )}
                          </span>
                        </div>
                        {routine.content && (
                          <p className="text-slate-600 font-medium leading-relaxed bg-slate-50/50 p-4 rounded-2xl border border-slate-100 italic">
                            "{routine.content}"
                          </p>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
                {routines.length === 0 && (
                  <div className="p-20 text-center glass rounded-[40px] border border-white/40 shadow-inner">
                    <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Calendar className="h-12 w-12 text-orange-300" />
                    </div>
                    <h4 className="text-xl font-black text-slate-800 mb-2">
                      No Routines Found
                    </h4>
                    <p className="text-slate-500 font-bold">
                      Start by adding a new class routine above.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Moderators Tab */}
            {activeTab === "moderators" && (
              <div className="space-y-10 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                    <UserCog className="h-8 w-8 text-orange-600" /> Moderator
                    Management
                  </h2>
                  <button
                    onClick={() => clearForm("moderators")}
                    className="text-orange-600 hover:text-orange-700 flex items-center gap-2 text-sm font-black uppercase tracking-widest transition-colors"
                  >
                    <XCircle className="h-5 w-5" /> Clear Form
                  </button>
                </div>

                <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
                  <h3 className="text-2xl font-black text-slate-800 mb-10 relative z-10 flex items-center gap-3">
                    <ShieldCheck className="h-8 w-8 text-orange-600" /> Add New
                    Moderator
                  </h3>
                  <form
                    onSubmit={handleAddModerator}
                    className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10"
                  >
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Full Name
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. John Doe"
                        className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                        value={newModerator.name}
                        onChange={(e) =>
                          setNewModerator({
                            ...newModerator,
                            name: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Username / Email
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. john_mod"
                        className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                        value={newModerator.email}
                        onChange={(e) =>
                          setNewModerator({
                            ...newModerator,
                            email: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-3 md:col-span-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Password
                      </label>
                      <input
                        type="password"
                        placeholder="••••••••"
                        className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                        value={newModerator.password}
                        onChange={(e) =>
                          setNewModerator({
                            ...newModerator,
                            password: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="glass-btn md:col-span-2 text-xl py-5"
                    >
                      <Plus className="h-6 w-6" /> Add Moderator
                    </button>
                  </form>
                </div>

                <div className="glass rounded-[40px] shadow-2xl border border-white/40 overflow-hidden relative">
                  <div className="p-8 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="text-xl font-black text-slate-800 uppercase tracking-widest">
                      Active Moderators
                    </h3>
                    <span className="bg-orange-50 text-orange-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-orange-100">
                      {moderators.length} Total
                    </span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left min-w-[600px]">
                      <thead>
                        <tr className="bg-slate-50/50 border-b border-slate-100">
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest w-24">
                            Serial
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Name
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest">
                            Email / Username
                          </th>
                          <th className="p-6 font-black text-slate-400 text-[10px] uppercase tracking-widest text-right">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {moderators.map((mod, index) => (
                          <tr
                            key={mod.id}
                            className="hover:bg-orange-50/50 transition-colors group"
                          >
                            <td className="p-6">
                              <span className="text-sm font-black text-slate-400">
                                #{index + 1}
                              </span>
                            </td>
                            <td className="p-6">
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center text-orange-600 font-black">
                                  {mod.name.charAt(0)}
                                </div>
                                <span className="font-black text-slate-900 group-hover:text-orange-600 transition-colors">
                                  {mod.name}
                                </span>
                              </div>
                            </td>
                            <td className="p-6">
                              <span className="text-sm font-bold text-slate-600">
                                {mod.email}
                              </span>
                            </td>
                            <td className="p-6 text-right">
                              <button
                                onClick={async () => {
                                  if (await showConfirm("Delete moderator?")) {
                                    setModerators(prev => prev.filter(m => m.id !== mod.id)); await fetch(`/api/moderators/${mod.id}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` }});
                                  }
                                }}
                                className="text-orange-400 hover:text-white p-3 rounded-xl hover:bg-orange-600 transition-all active:scale-90 shadow-sm hover:shadow-orange-200"
                              >
                                <Trash2 className="h-5 w-5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                        {moderators.length === 0 && (
                          <tr>
                            <td
                              colSpan={4}
                              className="p-20 text-center text-slate-400 italic font-bold"
                            >
                              No moderators found.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Web Recorded Classes Tab */}
            {activeTab === "web_recorded" && (
              <div className="space-y-10 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                    <PlayCircle className="h-8 w-8 text-orange-600" /> Web
                    Recorded Classes
                  </h2>
                  <button
                    onClick={() => clearForm("web_recorded")}
                    className="text-orange-600 hover:text-orange-700 flex items-center gap-2 text-sm font-black uppercase tracking-widest transition-colors"
                  >
                    <XCircle className="h-5 w-5" /> Clear Form
                  </button>
                </div>

                <div className="glass p-6 md:p-8 lg:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
                  <h3 className="text-xl md:text-2xl font-black text-slate-800 mb-2 relative z-10 flex items-center gap-3">
                    <PlayCircle className="h-8 w-8 text-orange-600" /> Add New
                    Video
                  </h3>
                  <p className="text-slate-500 font-black uppercase tracking-widest text-[10px] mb-10 bg-orange-50 px-4 py-2 rounded-xl inline-block border border-orange-100 relative z-10">
                    <PlayCircle className="h-3.5 w-3.5 inline-block mr-1 text-orange-600" />
                    These videos will be displayed in the "Recorded Classes"
                    section on the main website.
                  </p>
                  <form
                    onSubmit={handleAddWebRecordedClass}
                    className="space-y-8 relative z-10"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Video Title
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Math Chapter 1"
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newWebRecordedClass.title}
                          onChange={(e) =>
                            setNewWebRecordedClass({
                              ...newWebRecordedClass,
                              title: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          YouTube Video URL
                        </label>
                        <input
                          type="text"
                          placeholder="https://youtube.com/watch?v=..."
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newWebRecordedClass.url}
                          onChange={(e) =>
                            setNewWebRecordedClass({
                              ...newWebRecordedClass,
                              url: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Description
                      </label>
                      <textarea
                        placeholder="Brief description of the video..."
                        className="glass-input h-32 resize-none border-2 border-orange-100 focus:border-orange-500"
                        value={newWebRecordedClass.description}
                        onChange={(e) =>
                          setNewWebRecordedClass({
                            ...newWebRecordedClass,
                            description: e.target.value,
                          })
                        }
                      />
                    </div>
                    <button
                      type="submit"
                      className="glass-btn w-full text-xl py-5"
                    >
                      <Plus className="h-6 w-6" /> Add to Web Recorded
                    </button>
                  </form>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  {webRecordedClasses.map((cls) => (
                    <motion.div
                      key={cls.id}
                      whileHover={{ y: -8 }}
                      className="glass p-8 rounded-[40px] shadow-2xl border border-white/40 relative group transition-all duration-500"
                    >
                      <div className="flex justify-between items-start mb-6">
                        <div className="flex items-center gap-4">
                          <div className="w-14 h-14 rounded-2xl bg-orange-600 flex items-center justify-center text-white shadow-lg">
                            <PlayCircle className="h-6 w-6" />
                          </div>
                          <div>
                            <h3 className="text-xl font-black text-slate-900 group-hover:text-orange-600 transition-colors">
                              {cls.title}
                            </h3>
                            <div className="flex flex-wrap gap-2 mt-1">
                              <span className="text-[10px] font-black uppercase text-orange-600 tracking-widest bg-orange-50 px-2 py-0.5 rounded">
                                {courses.find((c) => c.id == cls.course_id)
                                  ?.title || "General Category"}
                              </span>
                              {cls.batch_id && (
                                <span className="text-[10px] font-black uppercase text-blue-600 tracking-widest bg-blue-50 px-2 py-0.5 rounded">
                                  {cls.batch_id === "all"
                                    ? "ALL BATCHES"
                                    : batches.find((b) => b.id == cls.batch_id)
                                        ?.name || "Batch"}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => handleDeleteWebRecordedClass(cls.id)}
                          className="bg-white/40 backdrop-blur-md text-orange-400 hover:text-white p-3 rounded-xl border border-white/60 hover:bg-orange-600 transition-all opacity-0 group-hover:opacity-100 shadow-xl active:scale-90"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                      <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100/50 mb-6">
                        <a
                          href={cls.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-orange-600 font-bold hover:underline truncate block flex items-center gap-2"
                        >
                          <ExternalLink className="h-4 w-4" /> {cls.url}
                        </a>
                      </div>
                      <p className="text-slate-600 font-medium leading-relaxed italic">
                        "{cls.description || "No description provided."}"
                      </p>
                    </motion.div>
                  ))}
                </div>
                {webRecordedClasses.length === 0 && (
                  <div className="p-20 text-center glass rounded-[40px] border border-white/40 shadow-inner">
                    <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-6">
                      <PlayCircle className="h-12 w-12 text-orange-300" />
                    </div>
                    <h4 className="text-xl font-black text-slate-800 mb-2">
                      No Videos Found
                    </h4>
                    <p className="text-slate-500 font-bold">
                      Start by adding a new video to Web Recorded above.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Student Recorded Classes Tab */}
            {activeTab === "student_recorded" && (
              <div className="space-y-10 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                    <PlayCircle className="h-8 w-8 text-orange-600" /> Student
                    Recorded Classes
                  </h2>
                  <button
                    onClick={() => clearForm("study_materials")}
                    className="text-orange-600 hover:text-orange-700 flex items-center gap-2 text-sm font-black uppercase tracking-widest transition-colors"
                  >
                    <XCircle className="h-5 w-5" /> Clear Form
                  </button>
                </div>

                <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
                  <h3 className="text-2xl font-black text-slate-800 mb-10 relative z-10 flex items-center gap-3">
                    <Video className="h-8 w-8 text-orange-600" /> Add New
                    Recorded Class
                  </h3>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const videoMaterial = {
                        ...newStudyMaterial,
                        type: "video",
                      };
                      handleAddStudyMaterial(e, videoMaterial);
                    }}
                    className="space-y-8 relative z-10"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Class Title
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Math Chapter 1 - Part 1"
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.title}
                          onChange={(e) =>
                            setNewStudyMaterial({
                              ...newStudyMaterial,
                              title: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Video URL (YouTube/Drive)
                        </label>
                        <input
                          type="text"
                          placeholder="https://..."
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.url}
                          onChange={(e) =>
                            setNewStudyMaterial({
                              ...newStudyMaterial,
                              url: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Program
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.program_id}
                          onChange={(e) =>
                            setNewStudyMaterial((prev) => ({
                              ...prev,
                              program_id: e.target.value,
                              batch_id: "",
                              course_id: "", // Exclusive selectivity
                            }))
                          }
                        >
                          <option value="">Select Program</option>
                          {programs.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.title}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Batch (Offline)
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.batch_id}
                          onChange={(e) =>
                            setNewStudyMaterial((prev) => ({
                              ...prev,
                              batch_id: e.target.value,
                            }))
                          }
                        >
                          <option value="">Select Batch (Offline)</option>
                          {newStudyMaterial.program_id && (
                            <option
                              value="all"
                              className="font-black text-orange-600"
                            >
                              ALL BATCHES
                            </option>
                          )}
                          {getFilteredBatches(newStudyMaterial.program_id).map(
                            (b) => (
                              <option key={b.id} value={b.id}>
                                {b.name}
                              </option>
                            ),
                          )}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Course (Online)
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.course_id}
                          onChange={(e) =>
                            setNewStudyMaterial((prev) => ({
                              ...prev,
                              course_id: e.target.value,
                              program_id: "", // Exclusive selectivity
                              batch_id: "",
                            }))
                          }
                        >
                          <option value="">Select Course (Online)</option>
                          {courses.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.title}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <button
                      type="submit"
                      className="glass-btn w-full text-xl py-5"
                    >
                      <Plus className="h-6 w-6" /> Add Recorded Class
                    </button>
                  </form>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {studyMaterials
                    .filter((m) => m.type === "video")
                    .map((mat) => (
                      <motion.div
                        key={mat.id}
                        whileHover={{ y: -8 }}
                        className="glass p-8 rounded-[40px] shadow-2xl border border-white/40 relative group transition-all duration-500"
                      >
                        <div className="flex items-start justify-between mb-6">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-2xl bg-orange-600 flex items-center justify-center text-white shadow-lg">
                              <Play className="h-5 w-5 fill-current" />
                            </div>
                            <div>
                              <h3 className="font-black text-slate-900 group-hover:text-orange-600 transition-colors line-clamp-1">
                                {mat.title}
                              </h3>
                              <span className="text-[10px] font-black uppercase text-orange-600 tracking-widest line-clamp-1">
                                {mat.batch_id && mat.batch_id !== "all"
                                  ? batches.find((b) => b.id == mat.batch_id)?.name
                                  : mat.program_id
                                    ? `All Batches: ${programs.find(p => p.id == mat.program_id)?.title || ""}`
                                    : courses.find((c) => c.id == mat.course_id)?.title || "General"}
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <a
                              href={mat.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="bg-white/40 backdrop-blur-md text-orange-600 hover:text-white p-3 rounded-xl border border-white/60 hover:bg-orange-600 transition-all shadow-xl active:scale-90"
                            >
                              <PlayCircle className="h-5 w-5" />
                            </a>
                            <button
                              onClick={() => handleDeleteStudyMaterial(mat.id)}
                              className="bg-white/40 backdrop-blur-md text-orange-400 hover:text-white p-3 rounded-xl border border-white/60 hover:bg-orange-600 transition-all opacity-0 group-hover:opacity-100 shadow-xl active:scale-90"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          </div>
                        </div>
                        <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100/50">
                          <p className="text-xs text-slate-500 font-bold truncate flex items-center gap-2">
                            <ExternalLink className="h-3 w-3" /> {mat.url}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                </div>
                {studyMaterials.filter((m) => m.type === "video").length ===
                  0 && (
                  <div className="p-20 text-center glass rounded-[40px] border border-white/40 shadow-inner">
                    <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Video className="h-12 w-12 text-orange-300" />
                    </div>
                    <h4 className="text-xl font-black text-slate-800 mb-2">
                      No Recorded Classes
                    </h4>
                    <p className="text-slate-500 font-bold">
                      Start by adding a new recorded class above.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Web Class Schedule Tab */}
            {activeTab === "web_schedule" && (
              <div className="space-y-10 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                    <Calendar className="h-8 w-8 text-orange-600" /> Web Class
                    Schedule
                  </h2>
                  <button
                    onClick={() => clearForm("web_schedule")}
                    className="text-orange-600 hover:text-orange-700 flex items-center gap-2 text-sm font-black uppercase tracking-widest transition-colors"
                  >
                    <XCircle className="h-5 w-5" /> Clear Form
                  </button>
                </div>

                <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
                  <h3 className="text-2xl font-black text-slate-800 mb-10 relative z-10 flex items-center gap-3">
                    <Calendar className="h-8 w-8 text-orange-600" /> Add New
                    Schedule
                  </h3>
                  <form
                    onSubmit={handleAddWebClassSchedule}
                    className="space-y-8 relative z-10"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Program
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newWebClassSchedule.program_id}
                          onChange={(e) =>
                            setNewWebClassSchedule({
                              ...newWebClassSchedule,
                              program_id: e.target.value,
                              batch_id: "",
                            })
                          }
                          required
                        >
                          <option value="">Select Program</option>
                          {programs.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.title}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Batch
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500 disabled:opacity-50 disabled:cursor-not-allowed"
                          value={newWebClassSchedule.batch_id}
                          onChange={(e) =>
                            setNewWebClassSchedule({
                              ...newWebClassSchedule,
                              batch_id: e.target.value,
                            })
                          }
                          disabled={!newWebClassSchedule.program_id}
                          required
                        >
                          <option value="">
                            {newWebClassSchedule.program_id
                              ? "Select Batch"
                              : "Select Program First"}
                          </option>
                          {newWebClassSchedule.program_id && (
                            <option
                              value="all"
                              className="font-black text-orange-600"
                            >
                              ALL BATCHES
                            </option>
                          )}
                          {getFilteredBatches(
                            newWebClassSchedule.program_id,
                          ).map((b) => (
                            <option key={b.id} value={b.id}>
                              {b.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Schedule Title
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Class 9 Schedule"
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newWebClassSchedule.title}
                          onChange={(e) =>
                            setNewWebClassSchedule({
                              ...newWebClassSchedule,
                              title: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Image URL
                      </label>
                      <input
                        type="text"
                        placeholder="https://..."
                        className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                        value={newWebClassSchedule.image_url}
                        onChange={(e) =>
                          setNewWebClassSchedule({
                            ...newWebClassSchedule,
                            image_url: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    {newWebClassSchedule.image_url && (
                      <div className="mt-2 relative w-full h-64 rounded-3xl overflow-hidden border-4 border-white shadow-2xl">
                        <img
                          src={newWebClassSchedule.image_url}
                          alt="Preview"
                          className="w-full h-full object-cover"
                          onError={handleImageError}
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                      </div>
                    )}
                    <button
                      type="submit"
                      className="glass-btn w-full text-xl py-5"
                    >
                      <Plus className="h-6 w-6" /> Add Schedule
                    </button>
                  </form>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  {webClassSchedules.map((sch) => (
                    <motion.div
                      key={sch.id}
                      whileHover={{ y: -10 }}
                      className="glass rounded-[40px] shadow-2xl border border-white/40 overflow-hidden group relative transition-all duration-500"
                    >
                      <div className="relative h-[500px] overflow-hidden">
                        <img
                          src={sch.image_url}
                          alt={sch.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                          referrerPolicy="no-referrer"
                          onError={handleImageError}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
                        <div className="absolute bottom-8 left-8 right-8">
                          <h3 className="text-2xl font-black text-white tracking-tight mb-2">
                            {sch.title}
                          </h3>
                          <span className="bg-orange-600 text-white px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-orange-600/30">
                            {programs.find((p) => p.id == sch.program_id)
                              ?.title || "General"}
                          </span>
                        </div>
                        <button
                          onClick={() => handleDeleteWebClassSchedule(sch.id)}
                          className="absolute top-6 right-6 bg-white/20 backdrop-blur-md text-white p-3 rounded-2xl opacity-0 group-hover:opacity-100 transition-all hover:bg-orange-600 shadow-xl border border-white/30"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
                {webClassSchedules.length === 0 && (
                  <div className="p-20 text-center glass rounded-[40px] border border-white/40 shadow-inner">
                    <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Calendar className="h-12 w-12 text-orange-300" />
                    </div>
                    <h4 className="text-xl font-black text-slate-800 mb-2">
                      No Schedules Found
                    </h4>
                    <p className="text-slate-500 font-bold">
                      Start by adding a new web class schedule above.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Video Classes Tab */}
            {activeTab === "video_classes" && (
              <div className="space-y-10 w-full">
                {authLoading ? (
                  <VideoSkeleton />
                ) : (
                  <>
                    <div className="flex justify-between items-center">
                      <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                        <Youtube className="h-8 w-8 text-orange-600" /> Jaber
                        Math Care Tube (YouTube Library)
                      </h2>
                      <div className="glass px-6 py-3 rounded-2xl border border-white/40 shadow-lg">
                        <span className="text-[10px] font-black text-orange-600 uppercase tracking-widest block mb-1">
                          Total Videos
                        </span>
                        <div className="text-2xl font-black text-slate-900">
                          {videoClasses.length}
                        </div>
                      </div>
                    </div>

                    <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
                      <h3 className="text-2xl font-black text-slate-800 mb-10 relative z-10 flex items-center gap-3">
                        <Youtube className="h-8 w-8 text-orange-600" /> Add New
                        Video Class
                      </h3>
                      <form
                        onSubmit={handleAddVideoClass}
                        className="space-y-8 relative z-10"
                      >
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Video Title
                            </label>
                            <input
                              type="text"
                              placeholder="e.g. Newton's Laws of Motion"
                              className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                              value={newVideoClass.title}
                              onChange={(e) =>
                                setNewVideoClass({
                                  ...newVideoClass,
                                  title: e.target.value,
                                })
                              }
                              required
                            />
                          </div>
                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              YouTube Video ID
                            </label>
                            <input
                              type="text"
                              placeholder="e.g. dQw4w9WgXcQ"
                              className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                              value={newVideoClass.youtube_id}
                              onChange={(e) =>
                                setNewVideoClass({
                                  ...newVideoClass,
                                  youtube_id: e.target.value,
                                })
                              }
                              required
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Program (Optional)
                            </label>
                            <select
                              className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                              value={newVideoClass.program_id}
                              onChange={(e) =>
                                setNewVideoClass({
                                  ...newVideoClass,
                                  program_id: e.target.value,
                                })
                              }
                            >
                              <option value="">Select Program</option>
                              {programs.map((p) => (
                                <option key={p.id} value={p.id}>
                                  {p.title}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Batch (Optional)
                            </label>
                            <select
                              className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                              value={newVideoClass.batch_id}
                              onChange={(e) =>
                                setNewVideoClass({
                                  ...newVideoClass,
                                  batch_id: e.target.value,
                                })
                              }
                            >
                              <option value="">All Batches</option>
                              {getFilteredBatches(newVideoClass.program_id).map(
                                (b) => (
                                  <option key={b.id} value={b.id}>
                                    {b.name}
                                  </option>
                                ),
                              )}
                            </select>
                          </div>
                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Course (Optional - Online)
                            </label>
                            <select
                              className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                              value={newVideoClass.course_id}
                              onChange={(e) =>
                                setNewVideoClass({
                                  ...newVideoClass,
                                  course_id: e.target.value,
                                })
                              }
                            >
                              <option value="">Select Course</option>
                              {courses.map((c) => (
                                <option key={c.id} value={c.id}>
                                  {c.title}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Description
                          </label>
                          <textarea
                            placeholder="Brief description of the video content..."
                            className="glass-input h-32 resize-none border-2 border-orange-100 focus:border-orange-500"
                            value={newVideoClass.description}
                            onChange={(e) =>
                              setNewVideoClass({
                                ...newVideoClass,
                                description: e.target.value,
                              })
                            }
                          />
                        </div>
                        <button
                          type="submit"
                          className="glass-btn w-full text-xl py-5"
                        >
                          <Plus className="h-6 w-6" /> Add Video Class
                        </button>
                      </form>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                      {videoClasses.map((video) => (
                        <motion.div
                          key={video.id}
                          whileHover={{ y: -10 }}
                          className="glass rounded-[40px] shadow-2xl border border-white/40 overflow-hidden group relative transition-all duration-500"
                        >
                          <div className="aspect-video relative overflow-hidden">
                            <img
                              src={`https://img.youtube.com/vi/${video.youtube_id}/mqdefault.jpg`}
                              alt={video.title}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 backdrop-blur-[2px]">
                              <button
                                onClick={() =>
                                  window.open(
                                    `https://www.youtube.com/watch?v=${video.youtube_id}`,
                                    "_blank",
                                  )
                                }
                                className="bg-white text-orange-600 p-5 rounded-full hover:scale-110 transition-transform shadow-2xl"
                              >
                                <Play className="h-10 w-10 fill-current" />
                              </button>
                            </div>
                            <div className="absolute top-6 right-6">
                              <button
                                onClick={() => handleDeleteVideoClass(video.id)}
                                className="bg-white/20 backdrop-blur-md text-white p-3 rounded-2xl opacity-0 group-hover:opacity-100 transition-all hover:bg-orange-600 shadow-xl border border-white/30"
                              >
                                <Trash2 className="h-5 w-5" />
                              </button>
                            </div>
                          </div>
                          <div className="p-8">
                            <div className="flex justify-between items-start mb-4">
                              <h3 className="font-black text-xl text-slate-900 group-hover:text-orange-600 transition-colors line-clamp-1 tracking-tight">
                                {video.title}
                              </h3>
                            </div>
                            <p className="text-sm text-slate-500 font-medium line-clamp-2 mb-6 leading-relaxed italic">
                              "{video.description}"
                            </p>
                            <div className="flex justify-between items-center pt-6 border-t border-slate-100">
                              <span className="bg-orange-50 text-orange-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-orange-100">
                                {programs.find((p) => p.id == video.program_id)
                                  ?.title || "General"}
                              </span>
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                YouTube Library
                              </span>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                    {videoClasses.length === 0 && (
                      <div className="p-20 text-center glass rounded-[40px] border border-white/40 shadow-inner">
                        <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-6">
                          <Youtube className="h-12 w-12 text-orange-300" />
                        </div>
                        <h4 className="text-xl font-black text-slate-800 mb-2">
                          No Videos Found
                        </h4>
                        <p className="text-slate-500 font-bold">
                          Start by adding a new video class above.
                        </p>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            {/* Class Slides Tab */}
            {activeTab === "class_slides" && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div className="relative">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-4">
                      <ImageIcon className="h-10 w-10 text-orange-600" />
                      Class <span className="text-orange-600">Slides</span>
                    </h2>
                    <div className="absolute -bottom-2 left-0 w-24 h-1 bg-gradient-to-r from-orange-600 to-orange-400 rounded-full"></div>
                  </div>
                </div>
                <div className="glass p-10 rounded-[2.5rem] border border-white shadow-2xl space-y-6">
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                    Upload New Slides
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Slide Title
                      </label>
                      <input
                        type="text"
                        placeholder="Enter Slide Title"
                        className="glass-input w-full"
                        value={newSlide.title}
                        onChange={(e) =>
                          setNewSlide((prev) => ({
                            ...prev,
                            title: e.target.value,
                          }))
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Program
                      </label>
                      <select
                        className="glass-select w-full"
                        value={newSlide.program_id}
                        onChange={(e) =>
                          setNewSlide((prev) => ({
                            ...prev,
                            program_id: e.target.value,
                            batch_id: "",
                            course_id: "",
                          }))
                        }
                      >
                        <option value="">All Programs</option>
                        {programs.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.title}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Batch
                      </label>
                      <select
                        className="glass-select w-full"
                        value={newSlide.batch_id}
                        onChange={(e) =>
                          setNewSlide((prev) => ({
                            ...prev,
                            batch_id: e.target.value,
                            course_id: "",
                          }))
                        }
                      >
                        <option value="">All Batches</option>
                        {getFilteredBatches(newSlide.program_id).map((b) => (
                          <option key={b.id} value={b.id}>
                            {b.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Course
                      </label>
                      <select
                        className="glass-select w-full"
                        value={newSlide.course_id}
                        onChange={(e) =>
                          setNewSlide((prev) => ({
                            ...prev,
                            course_id: e.target.value,
                            batch_id: "",
                          }))
                        }
                      >
                        <option value="">All Courses</option>
                        {courses
                          .filter(
                            (c) =>
                              !newSlide.program_id ||
                              String(c.program_id) ===
                                String(newSlide.program_id),
                          )
                          .map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.title}
                            </option>
                          ))}
                      </select>
                    </div>
                  </div>

                  {pendingSlides.length > 0 && (
                    <div className="flex flex-wrap gap-4 p-4 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                      {pendingSlides.map((url, idx) => (
                        <div key={idx} className="relative w-24 h-24 group">
                          <img
                            src={url}
                            className="w-full h-full object-cover rounded-xl shadow-md"
                          />
                          <button
                            onClick={() =>
                              setPendingSlides((prev) =>
                                prev.filter((_, i) => i !== idx),
                              )
                            }
                            className="absolute -top-2 -right-2 bg-rose-500 text-white p-1 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex flex-col md:flex-row items-center gap-4">
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      id="slide-upload"
                      className="hidden"
                      onChange={(e) => {
                        const files = Array.from(e.target.files || []);
                        files.forEach((file: File) =>
                          processImage(file, (dataUrl) => {
                            setPendingSlides((prev) => [...prev, dataUrl]);
                          }),
                        );
                      }}
                    />
                    <label
                      htmlFor="slide-upload"
                      className="cursor-pointer bg-slate-100 text-slate-600 px-6 py-3 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-200 transition-all border-2 border-slate-200 flex items-center gap-2 w-full md:w-auto justify-center"
                    >
                      <PlusCircle className="h-5 w-5" /> Select Files
                    </label>

                    <div className="flex-1 w-full flex gap-2">
                      <input
                        type="text"
                        placeholder="Or paste image URL here..."
                        className="glass-input flex-1"
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            let url = (e.target as HTMLInputElement).value;
                            if (url) {
                              if (url.includes('drive.google.com')) {
                                const match = url.match(/drive\.google\.com\/file\/d\/([^\/]+)/);
                                if (match && match[1]) {
                                  url = `https://drive.google.com/uc?export=view&id=${match[1]}`;
                                }
                              }
                              setPendingSlides((prev) => [...prev, url]);
                              (e.target as HTMLInputElement).value = "";
                            }
                          }
                        }}
                      />
                      <button
                        onClick={() => {
                          const input = document.querySelector(
                            'input[placeholder="Or paste image URL here..."]',
                          ) as HTMLInputElement;
                          if (input && input.value) {
                            let url = input.value;
                            if (url.includes('drive.google.com')) {
                              const match = url.match(/drive\.google\.com\/file\/d\/([^\/]+)/);
                              if (match && match[1]) {
                                url = `https://drive.google.com/uc?export=view&id=${match[1]}`;
                              }
                            }
                            setPendingSlides((prev) => [...prev, url]);
                            input.value = "";
                          }
                        }}
                        className="bg-slate-200 text-slate-600 px-4 rounded-xl hover:bg-slate-300 transition-colors font-bold"
                      >
                        Add
                      </button>
                    </div>

                    {pendingSlides.length > 0 && (
                      <button
                        onClick={() => {
                          if (!newSlide.title) {
                            showAlert("Please enter a slide title first");
                            return;
                          }
                          setLoading(true);
                          Promise.all(
                            pendingSlides.map((dataUrl) =>
                              fetch("/api/class-slides", {
                                method: "POST",
                                headers: {
                                  "Content-Type": "application/json",
                                  Authorization: `Bearer ${token}`,
                                },
                                body: JSON.stringify({
                                  title: newSlide.title,
                                  image_url: dataUrl,
                                  batch_id: newSlide.batch_id || "all",
                                  course_id: newSlide.course_id || "all",
                                  program_id: newSlide.program_id || "all",
                                  author: "Jaber",
                                }),
                              }),
                            ),
                          )
                            .then(() => {
                              fetchSlides();
                              setPendingSlides([]);
                              setNewSlide({
                                title: "",
                                image_url: "",
                                batch_id: "",
                                course_id: "",
                                program_id: "",
                              });
                              showAlert(
                                "All slides uploaded successfully!",
                                "success",
                              );
                            })
                            .finally(() => setLoading(false));
                        }}
                        disabled={loading}
                        className="bg-orange-600 text-white px-8 py-3 rounded-2xl font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-lg shadow-orange-200 flex items-center gap-2 disabled:opacity-50"
                      >
                        {loading ? (
                          <RefreshCw className="h-5 w-5 animate-spin" />
                        ) : (
                          <Upload className="h-5 w-5" />
                        )}
                        Send {pendingSlides.length} Slides
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {classSlides.map((slide) => (
                    <div
                      key={slide.id}
                      className="glass p-4 rounded-2xl relative group"
                    >
                      <img
                        src={slide.image_url}
                        alt="Slide"
                        className="w-full h-48 object-cover rounded-xl"
                      />
                      <div className="mt-3 flex justify-between items-start">
                        <div>
                          <h4 className="text-sm font-black text-slate-800 tracking-tight">
                            {slide.title || "Untitled Slide"}
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">
                              {batches.find((b) => b.id == slide.batch_id)
                                ?.name || "All Batches"}
                            </p>
                            {slide.author === "Jaber" && (
                              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded text-[8px] font-black uppercase tracking-tighter">
                                By Jaber
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={async () => {
                          if (
                            await showConfirm(
                              "Are you sure you want to delete this slide?",
                            )
                          ) {
                            await deleteDoc(doc(db, "class_slides", slide.id));
                          }
                        }}
                        className="absolute top-6 right-6 p-2 bg-rose-500 text-white rounded-lg opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Study Materials Tab */}
            {activeTab === "study_materials" && (
              <div className="space-y-10 w-full">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                    <BookOpen className="h-8 w-8 text-orange-600" /> Study
                    Materials
                  </h2>
                  <button
                    onClick={() => clearForm("study_materials")}
                    className="text-orange-600 hover:text-orange-700 flex items-center gap-2 text-sm font-black uppercase tracking-widest transition-colors"
                  >
                    <XCircle className="h-5 w-5" /> Clear Form
                  </button>
                </div>

                <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
                  <h3 className="text-2xl font-black text-slate-800 mb-10 relative z-10 flex items-center gap-3">
                    <BookOpen className="h-8 w-8 text-orange-600" /> Add New
                    Material
                  </h3>
                  <form
                    onSubmit={handleAddStudyMaterial}
                    className="space-y-8 relative z-10"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Material Title
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Math Chapter 1 Notes"
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.title}
                          onChange={(e) =>
                            setNewStudyMaterial({
                              ...newStudyMaterial,
                              title: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          URL (PDF/Drive Link)
                        </label>
                        <input
                          type="text"
                          placeholder="https://..."
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.url}
                          onChange={(e) =>
                            setNewStudyMaterial({
                              ...newStudyMaterial,
                              url: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Type
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.type}
                          onChange={(e) =>
                            setNewStudyMaterial((prev) => ({
                              ...prev,
                              type: e.target.value,
                            }))
                          }
                        >
                          <option value="pdf">PDF</option>
                          <option value="link">Link</option>
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Program
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.program_id}
                          onChange={(e) =>
                            setNewStudyMaterial((prev) => ({
                              ...prev,
                              program_id: e.target.value,
                              batch_id: "",
                              course_id: "", // Exclusive
                            }))
                          }
                        >
                          <option value="">Select Program</option>
                          {programs.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.title}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Batch (Offline)
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.batch_id}
                          onChange={(e) =>
                            setNewStudyMaterial((prev) => ({
                              ...prev,
                              batch_id: e.target.value,
                            }))
                          }
                          disabled={!newStudyMaterial.program_id}
                        >
                          <option value="">
                            {newStudyMaterial.program_id
                              ? "Select Batch (Offline)"
                              : "Select Program First"}
                          </option>
                          {newStudyMaterial.program_id && (
                            <option
                              value="all"
                              className="font-bold text-orange-600"
                            >
                              All Batches in Program
                            </option>
                          )}
                          {getFilteredBatches(newStudyMaterial.program_id).map(
                            (b) => (
                              <option key={b.id} value={b.id}>
                                {b.name}
                              </option>
                            ),
                          )}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Course (Online)
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newStudyMaterial.course_id}
                          onChange={(e) =>
                            setNewStudyMaterial((prev) => ({
                              ...prev,
                              course_id: e.target.value,
                              program_id: "", // Exclusive
                              batch_id: "",
                            }))
                          }
                        >
                          <option value="">Select Course (Online)</option>
                          {courses.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.title}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <button
                      type="submit"
                      className="glass-btn w-full text-xl py-5"
                    >
                      <Plus className="h-6 w-6" /> Add Material
                    </button>
                  </form>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {studyMaterials
                    .filter((m) => m.type !== "video")
                    .map((mat) => (
                      <motion.div
                        key={mat.id}
                        whileHover={{ y: -8 }}
                        className="glass p-8 rounded-[40px] shadow-2xl border border-white/40 relative group transition-all duration-500"
                      >
                        <div className="flex items-start justify-between mb-6">
                          <div className="flex items-center gap-4">
                            <div
                              className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg ${mat.type === "pdf" ? "bg-red-500" : "bg-blue-500"}`}
                            >
                              {mat.type === "pdf" ? (
                                <FileText className="h-6 w-6" />
                              ) : (
                                <ExternalLink className="h-6 w-6" />
                              )}
                            </div>
                            <div>
                              <h3 className="font-black text-slate-900 group-hover:text-orange-600 transition-colors line-clamp-1">
                                {mat.title}
                              </h3>
                              <span className="text-[10px] font-black uppercase text-orange-600 tracking-widest line-clamp-1">
                                {mat.batch_id && mat.batch_id !== "all"
                                  ? batches.find((b) => b.id == mat.batch_id)?.name
                                  : mat.program_id
                                    ? `All Batches: ${programs.find(p => p.id == mat.program_id)?.title || ""}`
                                    : courses.find((c) => c.id == mat.course_id)?.title || "General"}
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <a
                              href={mat.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="bg-white/40 backdrop-blur-md text-orange-600 hover:text-white p-3 rounded-xl border border-white/60 hover:bg-orange-600 transition-all shadow-xl active:scale-90"
                            >
                              <Download className="h-5 w-5" />
                            </a>
                            <button
                              onClick={() => handleDeleteStudyMaterial(mat.id)}
                              className="bg-white/40 backdrop-blur-md text-orange-400 hover:text-white p-3 rounded-xl border border-white/60 hover:bg-orange-600 transition-all opacity-0 group-hover:opacity-100 shadow-xl active:scale-90"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          </div>
                        </div>
                        <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100/50">
                          <p className="text-xs text-slate-500 font-bold truncate flex items-center gap-2">
                            <ExternalLink className="h-3 w-3" /> {mat.url}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                </div>
                {studyMaterials.filter((m) => m.type !== "video").length ===
                  0 && (
                  <div className="p-20 text-center glass rounded-[40px] border border-white/40 shadow-inner">
                    <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-6">
                      <BookOpen className="h-12 w-12 text-orange-300" />
                    </div>
                    <h4 className="text-xl font-black text-slate-800 mb-2">
                      No Materials Found
                    </h4>
                    <p className="text-slate-500 font-bold">
                      Start by adding a new study material above.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Settings Tab */}
            {/* Profile Settings Tab */}
            {activeTab === "profile" && (
              <div className="space-y-10 max-w-4xl w-full">
                <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                  <User className="h-8 w-8 text-orange-600" /> Profile Settings
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-[80px] -mr-32 -mt-32"></div>
                    <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                      <User className="h-6 w-6 text-orange-600" /> Account
                      Information
                    </h3>
                    <form
                      onSubmit={handleUpdateProfile}
                      className="space-y-6 relative z-10"
                    >
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Full Name
                        </label>
                        <input
                          type="text"
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={profileForm.name}
                          onChange={(e) =>
                            setProfileForm({
                              ...profileForm,
                              name: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Email Address
                        </label>
                        <input
                          type="email"
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={profileForm.email}
                          onChange={(e) =>
                            setProfileForm({
                              ...profileForm,
                              email: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                      <button
                        type="submit"
                        className="glass-btn w-full py-4 text-lg"
                      >
                        Update Profile
                      </button>
                    </form>
                  </div>

                  <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                    <div className="absolute bottom-0 left-0 w-64 h-64 bg-orange-500/5 rounded-full blur-[80px] -ml-32 -mb-32"></div>
                    <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                      <Lock className="h-6 w-6 text-orange-600" /> Change
                      Password
                    </h3>
                    <form
                      onSubmit={handleUpdatePassword}
                      className="space-y-4 relative z-10"
                    >
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Old Password
                        </label>
                        <input
                          type="password"
                          placeholder="••••••••"
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={passwordForm.oldPassword}
                          onChange={(e) =>
                            setPasswordForm({
                              ...passwordForm,
                              oldPassword: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          New Password
                        </label>
                        <input
                          type="password"
                          placeholder="••••••••"
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={passwordForm.newPassword}
                          onChange={(e) =>
                            setPasswordForm({
                              ...passwordForm,
                              newPassword: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Confirm New Password
                        </label>
                        <input
                          type="password"
                          placeholder="••••••••"
                          className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                          value={passwordForm.confirmPassword}
                          onChange={(e) =>
                            setPasswordForm({
                              ...passwordForm,
                              confirmPassword: e.target.value,
                            })
                          }
                          required
                        />
                      </div>
                      <button
                        type="submit"
                        className="glass-btn w-full py-4 text-lg"
                      >
                        Update Password
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            )}

            {/* SMS Center Tab */}
            {activeTab === "sms_center" && (
              <div className="space-y-10 w-full animate-fade-in">
                <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                  <MessageSquare className="h-8 w-8 text-orange-600" /> Broadcast SMS
                </h2>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                  {/* Broadcast In-App Notification */}
                  <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40">
                    <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                      <Bell className="h-6 w-6 text-orange-600" /> Send In-App Notification
                    </h3>
                    <p className="text-xs text-slate-500 mb-6 font-medium">This will send a real-time notification to the student's dashboard (via Firebase).</p>
                    <form 
                      onSubmit={async (e) => {
                        e.preventDefault();
                        const data = new FormData(e.currentTarget);
                        const targetAudience = data.get("target_audience")?.toString();
                        const targetBatch = data.get("batch_id")?.toString();
                        const title = data.get("title")?.toString();
                        const messageText = data.get("message")?.toString();
                        
                        if (!title || !messageText) return showAlert("Title and message are required.");

                        setIsLoading(true);
                        try {
                          const targetUserIds: string[] = [];

                          students.forEach(s => {
                            if (s.status !== "approved") return;
                            if (targetAudience === "offline" && (s.student_type === "online" || !!s.course_id)) return;
                            if (targetAudience === "online" && (s.student_type !== "online" && !s.course_id)) return;
                            
                            if (targetBatch && targetBatch !== "all") {
                              if (s.batch_id != targetBatch && s.batch_id_2 != targetBatch) return;
                            }
                            
                            targetUserIds.push(s.id);
                          });

                          if (targetUserIds.length === 0) {
                            setIsLoading(false);
                            return showAlert("No students found for this audience.");
                          }

                          if (!confirm(`Send this notification to ${targetUserIds.length} students?`)) {
                            setIsLoading(false);
                            return;
                          }

                          // In a real production app, we'd use a batch write or a cloud function
                          // For now, let's send them. Limit to first 100 to avoid blocking
                          const limitedTargets = targetUserIds.slice(0, 500);
                          
                          // We'll use a backend endpoint for batch notification to be efficient
                          const res = await fetch("/api/notifications/broadcast", {
                            method: "POST",
                            headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                            body: JSON.stringify({ 
                              user_ids: limitedTargets, 
                              title, 
                              message: messageText,
                              type: 'announcement'
                            })
                          });

                          if (res.ok) {
                            showAlert(`Notification sent to ${limitedTargets.length} students via Firebase.`);
                            (e.target as HTMLFormElement).reset();
                          } else {
                            throw new Error("Failed to send notifications");
                          }

                        } catch (err: any) {
                          console.error(err);
                          showAlert("Failed to send notifications.");
                        } finally {
                          setIsLoading(false);
                        }
                      }}
                      className="space-y-6"
                    >
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Audience</label>
                          <select name="target_audience" className="w-full p-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 shadow-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all cursor-pointer">
                            <option value="all">All Students</option>
                            <option value="offline">Offline Only</option>
                            <option value="online">Online Only</option>
                          </select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Batch (Optional)</label>
                          <select name="batch_id" className="w-full p-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 shadow-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all cursor-pointer">
                            <option value="all">Every Batch</option>
                            {batches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                          </select>
                        </div>
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Notification Title</label>
                         <input name="title" type="text" placeholder="e.g. Class Postponed" className="glass-input w-full font-bold" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Message Body</label>
                        <textarea 
                          name="message" 
                          placeholder="Type your message here..." 
                          className="glass-input w-full min-h-[150px] py-4"
                        />
                      </div>
                      <button 
                        type="submit"
                        disabled={isLoading}
                        className="w-full py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2 shadow-xl shadow-orange-600/20"
                      >
                        {isLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <><Send className="h-4 w-4" /> Broadcast Notification</>}
                      </button>
                    </form>
                  </div>

                  <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40">
                    <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                      <Send className="h-6 w-6 text-orange-600" /> Send SMS Message
                    </h3>
                    <form 
                      onSubmit={async (e) => {
                        e.preventDefault();
                        const data = new FormData(e.currentTarget);
                        const targetAudience = data.get("target_audience")?.toString();
                        const targetBatch = data.get("batch_id")?.toString();
                        const manualNumber = data.get("manual_number")?.toString();
                        const messageText = data.get("message")?.toString();
                        
                        if (!messageText) return showAlert("Message is required.");

                        setIsLoading(true);
                        try {
                          let numbers = new Set<string>();

                          // Add from manual number
                          if (manualNumber) {
                            manualNumber.split(',').forEach(n => {
                              const num = n.trim();
                              if (num && num.length >= 11) numbers.add(num);
                            });
                          }

                          // Get from students
                          if (targetAudience !== "none") {
                            students.forEach(s => {
                              if (s.status !== "approved") return;
                              if (targetAudience === "offline" && s.student_type === "online") return;
                              if (targetAudience === "online" && s.student_type !== "online") return;
                              
                              if (targetBatch && targetBatch !== "all") {
                                if (s.batch_id != targetBatch && s.batch_id_2 != targetBatch) return;
                              }
                              
                              const phone = s.guardian_phone || s.phone_number;
                              if (phone && phone.length >= 11) numbers.add(phone.trim());
                            });
                          }

                          const finalNumbers = Array.from(numbers);
                          if (finalNumbers.length === 0) {
                            setIsLoading(false);
                            return showAlert("No valid phone numbers found to send SMS.");
                          }

                          if (!confirm(`Are you sure you want to send this SMS to ${finalNumbers.length} recipients?\n\n"${messageText}"`)) {
                            setIsLoading(false);
                            return;
                          }

                          // Send SMS to each individually via backend loop to avoid timeout
                          // Actually, for a simple implementation, let's just send a batch request
                          let successCount = 0;
                          for (const num of finalNumbers) {
                            const res = await fetch("/api/send-sms", {
                              method: "POST",
                              headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                              body: JSON.stringify({ phone: num, message: messageText })
                            });
                            if (res.ok) successCount++;
                          }

                          showAlert(`Successfully sent SMS to ${successCount} out of ${finalNumbers.length} recipients.`);
                          (e.target as HTMLFormElement).reset();

                        } catch (err: any) {
                          console.error(err);
                          showAlert("An error occurred while sending SMS.");
                        } finally {
                          setIsLoading(false);
                        }
                      }}
                      className="space-y-6"
                    >
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Target Audience</label>
                        <select name="target_audience" className="w-full p-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 shadow-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all cursor-pointer">
                          <option value="none">Manual Numbers Only</option>
                          <option value="all">All Students</option>
                          <option value="offline">Offline Students Only</option>
                          <option value="online">Online Students Only</option>
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Select Batch (Optional filter)</label>
                        <select name="batch_id" className="w-full p-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 shadow-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all cursor-pointer">
                          <option value="all">All Batches</option>
                          {batches.map(b => (
                            <option key={b.id} value={b.id}>{b.name} ({b.class})</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Manual Numbers (Comma separated)</label>
                        <input type="text" name="manual_number" placeholder="017XXXXX, 018XXXXX" className="glass-input w-full" />
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">SMS Message</label>
                        <textarea name="message" rows={5} placeholder="Write your message here..." className="glass-input w-full resize-none font-medium" required />
                      </div>

                      <button type="submit" disabled={isLoading} className="bg-orange-600 text-white w-full py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-orange-700 transition active:scale-95 disabled:opacity-50 flex justify-center items-center gap-2">
                        {isLoading ? "Sending..." : "Send SMS Broadcast"} <Send className="h-5 w-5" />
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            )}

            {/* Email Center Tab */}
            {activeTab === "email_center" && (
              <div className="space-y-10 w-full animate-fade-in">
                <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                  <Mail className="h-8 w-8 text-orange-600" /> Broadcast Email
                </h2>
                
                <div className="grid grid-cols-1 gap-10">
                  <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 max-w-4xl mx-auto w-full">
                    <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                      <Send className="h-6 w-6 text-orange-600" /> Compose Email
                    </h3>
                    <form 
                      onSubmit={async (e) => {
                        e.preventDefault();
                        const data = new FormData(e.currentTarget);
                        const targetAudience = data.get("target_audience")?.toString();
                        const targetBatch = data.get("batch_id")?.toString();
                        const manualEmails = data.get("manual_email")?.toString();
                        const subject = data.get("subject")?.toString();
                        const messageText = data.get("message")?.toString();
                        
                        if (!subject || !messageText) return showAlert("Subject and message are required.");

                        setIsLoading(true);
                        try {
                          let emailsSet = new Set<string>();

                          // Add from manual emails
                          if (manualEmails) {
                            manualEmails.split(',').forEach(em => {
                              const email = em.trim();
                              if (email && email.includes('@')) emailsSet.add(email);
                            });
                          }

                          // Get from students
                          if (targetAudience !== "none") {
                            students.forEach(s => {
                              if (s.status !== "approved") return;
                              if (targetAudience === "offline" && (s.student_type === "online" || !!s.course_id)) return;
                              if (targetAudience === "online" && (s.student_type !== "online" && !s.course_id)) return;
                              
                              if (targetBatch && targetBatch !== "all") {
                                if (s.batch_id != targetBatch && s.batch_id_2 != targetBatch) return;
                              }
                              
                              const email = s.email || s.gmail;
                              if (email && email.includes('@')) emailsSet.add(email.trim());
                            });
                          }

                          const finalEmails = Array.from(emailsSet);
                          if (finalEmails.length === 0) {
                            setIsLoading(false);
                            return showAlert("No valid email addresses found.");
                          }

                          if (!confirm(`Are you sure you want to send this email to ${finalEmails.length} recipients?\n\nSubject: ${subject}`)) {
                            setIsLoading(false);
                            return;
                          }

                          let successCount = 0;
                          for (const email of finalEmails) {
                            const res = await fetch("/api/send-email", {
                              method: "POST",
                              headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                              body: JSON.stringify({ email: email, subject: subject, message: messageText })
                            });
                            if (res.ok) successCount++;
                          }

                          showAlert(`Successfully sent emails to ${successCount} out of ${finalEmails.length} recipients.`);
                          (e.target as HTMLFormElement).reset();

                        } catch (err: any) {
                          console.error(err);
                          showAlert("An error occurred while sending emails.");
                        } finally {
                          setIsLoading(false);
                        }
                      }}
                      className="space-y-6"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Target Audience</label>
                          <select name="target_audience" className="w-full p-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 shadow-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all cursor-pointer">
                            <option value="none">Manual Emails Only</option>
                            <option value="all">All Students</option>
                            <option value="offline">Offline Students Only</option>
                            <option value="online">Online Students Only</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Select Batch (Optional filter)</label>
                          <select name="batch_id" className="w-full p-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 shadow-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all cursor-pointer">
                            <option value="all">All Batches</option>
                            {batches.map(b => (
                              <option key={b.id} value={b.id}>{b.name} ({b.class})</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Manual Emails (Comma separated)</label>
                        <input type="text" name="manual_email" placeholder="example@gmail.com, text@example.com" className="glass-input w-full" />
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Subject</label>
                        <input type="text" name="subject" placeholder="Email Subject" className="glass-input w-full font-bold text-slate-800" required />
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Email Body</label>
                        <textarea name="message" rows={8} placeholder="Write your email content here (HTML supported)..." className="glass-input w-full resize-y font-medium" required />
                      </div>

                      <button type="submit" disabled={isLoading} className="bg-orange-600 text-white w-full py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-orange-700 transition active:scale-95 disabled:opacity-50 flex justify-center items-center gap-2">
                        {isLoading ? "Sending..." : "Send Email Broadcast"} <Send className="h-5 w-5" />
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            )}



            {/* Website Settings Tab */}
            {activeTab === "website_settings" && (
              <div className="space-y-10 w-full">
                <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                  <Settings className="h-8 w-8 text-orange-600" /> Website
                  Content
                </h2>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                  {/* Social Media & Branding */}
                  <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-[80px] -mr-32 -mt-32"></div>
                    <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                      <Share2 className="h-6 w-6 text-orange-600" /> Social
                      Media & Branding
                    </h3>
                    <div className="space-y-6 relative z-10">
                      {[
                        {
                          key: "site_name",
                          label: "Site Name",
                          placeholder: "Jaber Math Care",
                        },
                        {
                          key: "hero_subtitle",
                          label: "Hero Subtitle",
                          placeholder: "Where mathematical excellence meets engineering dreams...",
                        },
                        {
                          key: "mentor_name",
                          label: "Mentor Name",
                          placeholder: "Wasi Uddin",
                        },
                        {
                          key: "facebook_url",
                          label: "Facebook URL",
                          placeholder: "https://facebook.com/...",
                        },
                        {
                          key: "youtube_url",
                          label: "YouTube URL",
                          placeholder: "https://youtube.com/...",
                        },
                        {
                          key: "instagram_url",
                          label: "Instagram URL",
                          placeholder: "https://instagram.com/...",
                        },
                        {
                          key: "website_url",
                          label: "Website URL",
                          placeholder: "https://jabermathcare.com",
                        },
                      ].map((item) => (
                        <div key={item.key} className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            {item.label}
                          </label>
                          <div className="flex gap-3">
                            <input
                              type="text"
                              className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                              placeholder={item.placeholder}
                              value={settings[item.key] || ""}
                              onChange={(e) =>
                                setStagedSettings((prev: any) => ({
                                  ...prev,
                                  [item.key]: e.target.value,
                                }))
                              }
                            />
                            <button
                              onClick={() =>
                                handleUpdateSetting(
                                  item.key,
                                  settings[item.key],
                                )
                              }
                              className="glass-btn px-6 py-3"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Hero Section Content */}
                  <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-[80px] -mr-32 -mt-32"></div>
                    <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                      <BookOpen className="h-6 w-6 text-orange-600" /> Hero &
                      Stats Content
                    </h3>
                    <div className="space-y-6 relative z-10">
                      {[
                        {
                          key: "hero_badge_text",
                          label: "Hero Badge Text",
                          placeholder: "The Future of Math Education",
                        },
                        {
                          key: "stat_1_label",
                          label: "Stat 1 Label",
                          placeholder: "Success Rate",
                        },
                        {
                          key: "stat_1_value",
                          label: "Stat 1 Value",
                          placeholder: "95%",
                        },
                        {
                          key: "stat_2_label",
                          label: "Stat 2 Label",
                          placeholder: "Expert Mentors",
                        },
                        {
                          key: "stat_2_value",
                          label: "Stat 2 Value",
                          placeholder: "10+",
                        },
                        {
                          key: "stat_3_label",
                          label: "Stat 3 Label",
                          placeholder: "Study Materials",
                        },
                        {
                          key: "stat_3_value",
                          label: "Stat 3 Value",
                          placeholder: "500+",
                        },
                        {
                          key: "stat_4_label",
                          label: "Stat 4 Label",
                          placeholder: "Math Labs",
                        },
                        {
                          key: "stat_4_value",
                          label: "Stat 4 Value",
                          placeholder: "Online",
                        },
                        {
                          key: "copyright_text",
                          label: "Footer Copyright Text",
                          placeholder:
                            "© 2026 Jaber Math Care. All rights reserved.",
                        },
                      ].map((item) => (
                        <div key={item.key} className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            {item.label}
                          </label>
                          <div className="flex gap-3">
                            <input
                              type="text"
                              className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                              placeholder={item.placeholder}
                              value={settings[item.key] || ""}
                              onChange={(e) =>
                                setStagedSettings((prev: any) => ({
                                  ...prev,
                                  [item.key]: e.target.value,
                                }))
                              }
                            />
                            <button
                              onClick={() =>
                                handleUpdateSetting(
                                  item.key,
                                  settings[item.key],
                                )
                              }
                              className="glass-btn px-6 py-3"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Website Assets (Logo & Images) */}
                  <div className="space-y-10">
                    <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                      <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                        <User className="h-6 w-6 text-orange-600" /> Developer
                        Settings
                      </h3>
                      <div className="space-y-6 relative z-10">
                        {[
                          {
                            key: "developer_name",
                            label: "Developer Name",
                            placeholder: "Mohammad Jaber Bin Razzak",
                          },
                          {
                            key: "developer_photo_url",
                            label: "Developer Photo URL",
                            placeholder: "https://...",
                          },
                          {
                            key: "developer_bio",
                            label: "Developer Bio",
                            placeholder: "...",
                          },
                          {
                            key: "developer_email",
                            label: "Developer Email",
                            placeholder: "...",
                          },
                          {
                            key: "super_admin_emails",
                            label: "Super Admin Emails (Comma separated)",
                            placeholder: "email1@gmail.com, email2@gmail.com",
                          },
                          {
                            key: "developer_phone",
                            label: "Developer Phone",
                            placeholder: "...",
                          },
                          {
                            key: "developer_location",
                            label: "Developer Location",
                            placeholder: "...",
                          },
                        ].map((item) => (
                          <div key={item.key} className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              {item.label}
                            </label>
                            <div className="flex gap-3">
                              <input
                                type="text"
                                className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                                placeholder={item.placeholder}
                                value={settings[item.key] || ""}
                                onChange={(e) =>
                                  setStagedSettings((prev: any) => ({
                                    ...prev,
                                    [item.key]: e.target.value,
                                  }))
                                }
                              />
                              <button
                                onClick={() =>
                                  handleUpdateSetting(
                                    item.key,
                                    settings[item.key],
                                  )
                                }
                                className="glass-btn px-6 py-3"
                              >
                                Save
                              </button>
                            </div>
                            {item.key === "developer_photo_url" && (
                              <div className="flex items-center gap-2 mt-2">
                                <input
                                  type="file"
                                  id="dev-photo-upload"
                                  accept="image/*"
                                  className="hidden"
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      processImage(file, (dataUrl) =>
                                        handleUpdateSetting(item.key, dataUrl),
                                      );
                                    }
                                  }}
                                />
                                <label
                                  htmlFor="dev-photo-upload"
                                  className="cursor-pointer bg-orange-50 text-orange-600 px-4 py-2 rounded-xl font-bold text-xs hover:bg-orange-100 transition-all border border-orange-200 flex items-center gap-2"
                                >
                                  <Upload className="h-4 w-4" /> Choose File
                                </label>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                      <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                        <ImageIcon className="h-6 w-6 text-orange-600" />{" "}
                        Website Logo
                      </h3>
                      <div className="space-y-6 relative z-10">
                        <div className="flex gap-3">
                          <input
                            type="text"
                            className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                            placeholder="Logo URL"
                            value={
                              settings.logo_url ||
                              "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
                            }
                            onChange={(e) =>
                              setStagedSettings((prev: any) => ({
                                ...prev,
                                logo_url: e.target.value,
                              }))
                            }
                          />
                          <button
                            onClick={() =>
                              handleUpdateSetting("logo_url", settings.logo_url)
                            }
                            className="glass-btn px-6 py-3"
                          >
                            Save
                          </button>
                          <label className="bg-white/40 backdrop-blur-md text-orange-600 hover:text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest cursor-pointer transition-all flex items-center gap-2 border border-white/60 hover:bg-orange-600 shadow-xl">
                            <Upload className="h-4 w-4" /> Upload
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => handleImageUpload(e, "logo_url")}
                            />
                          </label>
                        </div>
                        {(settings.logo_url ||
                          "https://cdn-icons-png.flaticon.com/512/3135/3135715.png") && (
                          <div className="mt-4 p-4 glass rounded-3xl border border-white/40 bg-white/20 flex items-center justify-center">
                            <img
                              src={
                                settings.logo_url ||
                                "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
                              }
                              alt="Logo Preview"
                              className="max-h-20 object-contain"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                      <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                        <ImageIcon className="h-6 w-6 text-orange-600" />{" "}
                        Login Page Illustration Image
                      </h3>
                      <div className="space-y-6 relative z-10">
                        <p className="text-xs text-slate-500 font-bold -mt-4">
                          Customize the illustrated scene or image shown on the left panel of the Student Login page on larger screens.
                        </p>
                        <div className="flex gap-3">
                          <input
                            type="text"
                            className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                            placeholder="Login Page Image URL"
                            value={
                              settings.login_page_image ||
                              ""
                            }
                            onChange={(e) =>
                              setStagedSettings((prev: any) => ({
                                ...prev,
                                login_page_image: e.target.value,
                              }))
                            }
                          />
                          <button
                            onClick={() =>
                              handleUpdateSetting("login_page_image", settings.login_page_image)
                            }
                            className="glass-btn px-6 py-3"
                          >
                            Save
                          </button>
                          <label className="bg-white/40 backdrop-blur-md text-orange-600 hover:text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest cursor-pointer transition-all flex items-center gap-2 border border-white/60 hover:bg-orange-600 shadow-xl">
                            <Upload className="h-4 w-4" /> Upload
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => handleImageUpload(e, "login_page_image")}
                            />
                          </label>
                        </div>
                        <div className="mt-4 p-4 glass rounded-[32px] border border-white/40 bg-white/20 flex flex-col items-center justify-center">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Live Preview</span>
                          <img
                            src={
                              settings.login_page_image ||
                              "https://img.magnific.com/free-vector/isaac-newton-sitting-apple-tree_1308-91323.jpg?semt=ais_hybrid&w=740&q=80"
                            }
                            alt="Login Preview"
                            className="max-h-40 rounded-2xl object-cover shadow-md border border-slate-200"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = "https://img.magnific.com/free-vector/isaac-newton-sitting-apple-tree_1308-91323.jpg?semt=ais_hybrid&w=740&q=80";
                            }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* SEO & Search Engine Optimization */}
                    <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-[80px] -mr-32 -mt-32"></div>
                      <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                        <Search className="h-6 w-6 text-orange-600" /> SEO & Search Engine Optimization
                      </h3>
                      <div className="space-y-6 relative z-10">
                        <p className="text-xs text-slate-500 font-bold -mt-4">
                          Configure how your website appears in Google search results and manage tracking tags.
                        </p>
                        {[
                          {
                            key: "seo_title",
                            label: "SEO Page Title",
                            placeholder: "Jaber Math Care - Best Math & Physics Education in Bangladesh",
                          },
                          {
                            key: "seo_description",
                            label: "SEO Website Description",
                            placeholder: "Unlock conceptual physics and mathematical excellence with expert mentors...",
                          },
                          {
                            key: "seo_keywords",
                            label: "SEO Keywords (Comma separated)",
                            placeholder: "math, physics, admission, hsc, engineering",
                          },
                        ].map((item) => (
                          <div key={item.key} className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              {item.label}
                            </label>
                            <div className="flex gap-3">
                              <input
                                type="text"
                                className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                                placeholder={item.placeholder}
                                value={settings[item.key] || ""}
                                onChange={(e) =>
                                  setStagedSettings((prev: any) => ({
                                    ...prev,
                                    [item.key]: e.target.value,
                                  }))
                                }
                              />
                              <button
                                onClick={() =>
                                  handleUpdateSetting(
                                    item.key,
                                    settings[item.key],
                                  )
                                }
                                className="glass-btn px-6 py-3"
                              >
                                Save
                              </button>
                            </div>
                          </div>
                        ))}
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Custom Meta Tags / Google SEO Scripts
                          </label>
                          <textarea
                            className="glass-input w-full min-h-[120px] border-2 border-orange-100 focus:border-orange-500 p-4 font-mono text-xs"
                            placeholder="Paste your <meta> tags or search console verification scripts here..."
                            value={settings.custom_seo_tags || ""}
                            onChange={(e) =>
                              setStagedSettings((prev: any) => ({
                                ...prev,
                                custom_seo_tags: e.target.value,
                              }))
                            }
                          />
                          <button
                            onClick={() =>
                                handleUpdateSetting(
                                    "custom_seo_tags",
                                    settings.custom_seo_tags,
                                )
                            }
                            className="glass-btn w-full py-4 mt-2"
                          >
                            Save SEO Scripts
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* SMTP Configuration */}
                    <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden xl:col-span-2">
                      <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-[80px] -mr-32 -mt-32"></div>
                      <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                        <Send className="h-6 w-6 text-orange-600" /> SMTP Email Configuration
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
                        <div className="space-y-6 md:col-span-2">
                          <p className="text-xs text-slate-500 font-bold -mt-4">
                            Configure SMTP settings to enable genuine automated email broadcasts. Best used with a Gmail App Password.
                          </p>
                        </div>
                        {[
                          {
                            key: "smtp_email",
                            label: "SMTP Email Address",
                            placeholder: "your.app.address@gmail.com",
                            type: "email"
                          },
                          {
                            key: "smtp_password",
                            label: "SMTP App Password",
                            placeholder: "16-digit App Password",
                            type: "password"
                          },
                        ].map((item) => (
                          <div key={item.key} className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              {item.label}
                            </label>
                            <div className="flex gap-3">
                              <input
                                type={item.type || "text"}
                                className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                                placeholder={item.placeholder}
                                value={settings[item.key] || ""}
                                onChange={(e) =>
                                  setStagedSettings((prev: any) => ({
                                    ...prev,
                                    [item.key]: e.target.value,
                                  }))
                                }
                              />
                              <button
                                onClick={() =>
                                  handleUpdateSetting(
                                    item.key,
                                    settings[item.key],
                                  )
                                }
                                className="glass-btn px-6 py-3"
                              >
                                Save
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                      <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                        <ImageIcon className="h-6 w-6 text-orange-600" /> Hero &
                        About Images
                      </h3>
                      <div className="space-y-6 relative z-10">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Jaber Tube Button Text
                            </label>
                            <div className="flex gap-3">
                              <input
                                type="text"
                                className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                                placeholder="e.g. Jaber Tube"
                                value={settings.jaber_tube_text || ""}
                                onChange={(e) =>
                                  setStagedSettings((prev: any) => ({
                                    ...prev,
                                    jaber_tube_text: e.target.value,
                                  }))
                                }
                              />
                              <button
                                onClick={() =>
                                  handleUpdateSetting(
                                    "jaber_tube_text",
                                    settings.jaber_tube_text,
                                  )
                                }
                                className="glass-btn px-6 py-3"
                              >
                                Save
                              </button>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              Jaber Tube Link
                            </label>
                            <div className="flex gap-3">
                              <input
                                type="text"
                                className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                                placeholder="e.g. /video-library"
                                value={settings.jaber_tube_link || ""}
                                onChange={(e) =>
                                  setStagedSettings((prev: any) => ({
                                    ...prev,
                                    jaber_tube_link: e.target.value,
                                  }))
                                }
                              />
                              <button
                                onClick={() =>
                                  handleUpdateSetting(
                                    "jaber_tube_link",
                                    settings.jaber_tube_link,
                                  )
                                }
                                className="glass-btn px-6 py-3"
                              >
                                Save
                              </button>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                              App Download Link
                            </label>
                            <div className="flex gap-3">
                              <input
                                type="text"
                                className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                                placeholder="Download Link URL"
                                value={settings.app_download_link || ""}
                                onChange={(e) =>
                                  setStagedSettings((prev: any) => ({
                                    ...prev,
                                    app_download_link: e.target.value,
                                  }))
                                }
                              />
                              <button
                                onClick={() =>
                                  handleUpdateSetting(
                                    "app_download_link",
                                    settings.app_download_link,
                                  )
                                }
                                className="glass-btn px-6 py-3"
                              >
                                Save
                              </button>
                            </div>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            Hero Image
                          </label>
                          <div className="flex gap-3">
                            <input
                              type="text"
                              className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                              placeholder="Hero Image URL"
                              value={settings.hero_image || ""}
                              onChange={(e) =>
                                setStagedSettings((prev: any) => ({
                                  ...prev,
                                  hero_image: e.target.value,
                                }))
                              }
                            />
                            <button
                              onClick={() =>
                                handleUpdateSetting(
                                  "hero_image",
                                  settings.hero_image,
                                )
                              }
                              className="glass-btn px-6 py-3"
                            >
                              Save
                            </button>
                            <label className="bg-white/40 backdrop-blur-md text-orange-600 hover:text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest cursor-pointer transition-all flex items-center gap-2 border border-white/60 hover:bg-orange-600 shadow-xl">
                              <Upload className="h-4 w-4" /> Upload
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) =>
                                  handleImageUpload(e, "hero_image")
                                }
                              />
                            </label>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            About Text
                          </label>
                          <div className="flex gap-3">
                            <textarea
                              className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500 min-h-[150px] py-4"
                              placeholder="About Us description..."
                              value={settings.about_text || ""}
                              onChange={(e) =>
                                setStagedSettings((prev: any) => ({
                                  ...prev,
                                  about_text: e.target.value,
                                }))
                              }
                            />
                            <button
                              onClick={() =>
                                handleUpdateSetting(
                                  "about_text",
                                  settings.about_text,
                                )
                              }
                              className="glass-btn px-6 py-3 self-start"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            About Image
                          </label>
                          <div className="flex gap-3">
                            <input
                              type="text"
                              className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                              placeholder="About Image URL"
                              value={settings.about_image || ""}
                              onChange={(e) =>
                                setStagedSettings((prev: any) => ({
                                  ...prev,
                                  about_image: e.target.value,
                                }))
                              }
                            />
                            <button
                              onClick={() =>
                                handleUpdateSetting(
                                  "about_image",
                                  settings.about_image,
                                )
                              }
                              className="glass-btn px-6 py-3"
                            >
                              Save
                            </button>
                            <label className="bg-white/40 backdrop-blur-md text-orange-600 hover:text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest cursor-pointer transition-all flex items-center gap-2 border border-white/60 hover:bg-orange-600 shadow-xl">
                              <Upload className="h-4 w-4" /> Upload
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) =>
                                  handleImageUpload(e, "about_image")
                                }
                              />
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Settings */}
                <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                  <h3 className="text-2xl font-black text-slate-800 mb-10 relative z-10 flex items-center gap-3">
                    <FileText className="h-8 w-8 text-orange-600" /> Footer
                    Settings
                  </h3>
                  <div className="space-y-6 relative z-10">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                        Footer Description
                      </label>
                      <div className="flex gap-3">
                        <textarea
                          className="glass-input flex-1 min-h-[100px] border-2 border-orange-100 focus:border-orange-500 resize-none"
                          placeholder="Enter footer description text"
                          value={settings.footer_description || ""}
                          onChange={(e) =>
                            setStagedSettings((prev: any) => ({
                              ...prev,
                              footer_description: e.target.value,
                            }))
                          }
                        />
                        <button
                          onClick={() =>
                            handleUpdateSetting(
                              "footer_description",
                              settings.footer_description,
                            )
                          }
                          className="glass-btn px-6"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Contact & Location */}
                <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -ml-48 -mt-48"></div>
                  <h3 className="text-2xl font-black text-slate-800 mb-10 relative z-10 flex items-center gap-3">
                    <MapPin className="h-8 w-8 text-orange-600" /> Contact &
                    Location
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10 relative z-10">
                    <div className="space-y-6">
                      {[
                        {
                          key: "contact_phone",
                          label: "Contact Phone",
                          placeholder: "e.g. +880 1XXX XXXXXX",
                        },
                        {
                          key: "contact_email",
                          label: "Contact Email",
                          placeholder: "e.g. contact@jabermathcare.com",
                        },
                      ].map((item) => (
                        <div key={item.key} className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            {item.label}
                          </label>
                          <div className="flex gap-3">
                            <input
                              type="text"
                              className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                              placeholder={item.placeholder}
                              value={settings[item.key] || ""}
                              onChange={(e) =>
                                setStagedSettings((prev: any) => ({
                                  ...prev,
                                  [item.key]: e.target.value,
                                }))
                              }
                            />
                            <button
                              onClick={() =>
                                handleUpdateSetting(
                                  item.key,
                                  settings[item.key],
                                )
                              }
                              className="glass-btn px-6 py-3"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      ))}
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Google Maps Embed Code 1
                        </label>
                        <div className="flex gap-3">
                          <textarea
                            className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500 min-h-[100px] py-4 font-mono text-xs"
                            placeholder='<iframe src="https://www.google.com/maps/embed?pb=..." ...></iframe>'
                            value={settings.map_embed_code || ""}
                            onChange={(e) =>
                              setStagedSettings((prev: any) => ({
                                ...prev,
                                map_embed_code: e.target.value,
                              }))
                            }
                          />
                          <button
                            onClick={() =>
                              handleUpdateSetting(
                                "map_embed_code",
                                settings.map_embed_code,
                              )
                            }
                            className="glass-btn px-6 py-3 self-start"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Google Maps Embed Code 2
                        </label>
                        <div className="flex gap-3">
                          <textarea
                            className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500 min-h-[100px] py-4 font-mono text-xs"
                            placeholder='<iframe src="https://www.google.com/maps/embed?pb=..." ...></iframe>'
                            value={settings.map_embed_code_2 || ""}
                            onChange={(e) =>
                              setStagedSettings((prev: any) => ({
                                ...prev,
                                map_embed_code_2: e.target.value,
                              }))
                            }
                          />
                          <button
                            onClick={() =>
                              handleUpdateSetting(
                                "map_embed_code_2",
                                settings.map_embed_code_2,
                              )
                            }
                            className="glass-btn px-6 py-3 self-start"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Campus 1 Address
                        </label>
                        <div className="flex gap-3">
                          <textarea
                            className="glass-input flex-1 min-h-[100px] border-2 border-orange-100 focus:border-orange-500 resize-none"
                            placeholder="Enter Campus 1 address"
                            value={settings.office_address || ""}
                            onChange={(e) =>
                              setStagedSettings((prev: any) => ({
                                ...prev,
                                office_address: e.target.value,
                              }))
                            }
                          />
                          <button
                            onClick={() =>
                              handleUpdateSetting(
                                "office_address",
                                settings.office_address,
                              )
                            }
                            className="glass-btn px-6"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Campus 2 Address
                        </label>
                        <div className="flex gap-3">
                          <textarea
                            className="glass-input flex-1 min-h-[100px] border-2 border-orange-100 focus:border-orange-500 resize-none"
                            placeholder="Enter Campus 2 address"
                            value={settings.office_address_2 || ""}
                            onChange={(e) =>
                              setStagedSettings((prev: any) => ({
                                ...prev,
                                office_address_2: e.target.value,
                              }))
                            }
                          />
                          <button
                            onClick={() =>
                              handleUpdateSetting(
                                "office_address_2",
                                settings.office_address_2,
                              )
                            }
                            className="glass-btn px-6"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Payment & Admission */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                  <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                    <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                      <CreditCard className="h-6 w-6 text-orange-600" /> Payment
                      Numbers
                    </h3>
                    <div className="space-y-6 relative z-10">
                      {[
                        { key: "bkash_number", label: "bKash Number" },
                        { key: "nagad_number", label: "Nagad Number" },
                        { key: "rocket_number", label: "Rocket Number" },
                      ].map((item) => (
                        <div key={item.key} className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                            {item.label}
                          </label>
                          <div className="flex gap-3">
                            <input
                              type="text"
                              className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                              placeholder="e.g. 017XXXXXXXX"
                              value={settings[item.key] || ""}
                              onChange={(e) =>
                                setStagedSettings((prev: any) => ({
                                  ...prev,
                                  [item.key]: e.target.value,
                                }))
                              }
                            />
                            <button
                              onClick={() =>
                                handleUpdateSetting(
                                  item.key,
                                  settings[item.key],
                                )
                              }
                              className="glass-btn px-6 py-3"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                        <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                          <Settings className="h-6 w-6 text-orange-600" /> API Configurations
                        </h3>
                        <div className="space-y-6 relative z-10">
                          {[
                            { key: "sms_api_url", label: "SMS Gateway URL", placeholder: "https://api.sms-gateway.com/send" },
                            { key: "sms_api_key", label: "SMS API Key", placeholder: "your-api-key" },
                            { key: "sms_sender_id", label: "SMS Sender ID", placeholder: "SENDER" },
                            { key: "smtp_email", label: "SMTP Gmail Address", placeholder: "your-email@gmail.com" },
                            { key: "smtp_password", label: "SMTP App Password", placeholder: "Gmail App Password (16 chars)" }
                          ].map((item) => (
                            <div key={item.key} className="space-y-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{item.label}</label>
                              <div className="flex gap-3">
                                <input
                                  type={item.key === "smtp_password" ? "password" : "text"}
                                  className="glass-input flex-1 border-2 border-orange-100 focus:border-orange-500"
                                  placeholder={item.placeholder}
                                  value={settings[item.key] || ""}
                                  onChange={(e) => setStagedSettings((prev: any) => ({ ...prev, [item.key]: e.target.value }))}
                                />
                                <button
                                  onClick={() => handleUpdateSetting(item.key, settings[item.key])}
                                  className="glass-btn px-6 py-3"
                                >
                                  Save
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="glass p-10 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden">
                        <h3 className="text-xl font-black text-slate-800 mb-8 relative z-10 flex items-center gap-3">
                          <Settings className="h-6 w-6 text-orange-600" /> Admission
                      Settings
                    </h3>
                    <div className="space-y-8 relative z-10">
                      <div className="flex items-center justify-between p-8 glass rounded-3xl border border-white/40 shadow-xl">
                        <div>
                          <h4 className="font-black text-slate-800 text-lg">
                            Admission Open
                          </h4>
                          <p className="text-xs text-slate-500 font-bold">
                            Toggle online admission visibility
                          </p>
                        </div>
                        <button
                          onClick={() =>
                            handleUpdateSetting(
                              "admission_open",
                              settings.admission_open === "true"
                                ? "false"
                                : "true",
                            )
                          }
                          className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors focus:outline-none ${settings.admission_open === "true" ? "bg-orange-600" : "bg-slate-300"}`}
                        >
                          <span
                            className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${settings.admission_open === "true" ? "translate-x-9" : "translate-x-1"}`}
                          />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Danger Zone */}
                <div className="glass p-10 md:p-12 rounded-[40px] shadow-2xl border border-white/40 relative overflow-hidden bg-red-50/30 mt-10">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-red-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
                  <h3 className="text-2xl font-black text-red-600 mb-8 relative z-10 flex items-center gap-3">
                    <Trash2 className="h-8 w-8" /> Danger Zone
                  </h3>
                  <div className="space-y-6 relative z-10">
                    <p className="text-slate-500 font-medium">
                      Resetting the database will permanently delete all
                      students, batches, payments, and other records. This
                      action cannot be undone.
                    </p>
                    <button
                      onClick={async () => {
                        if (
                          await showConfirm(
                            "Are you sure you want to RESET the entire database? This will delete all students, batches, programs, chapters, etc. This cannot be undone.",
                          )
                        ) {
                          setLoading(true);
                          try {
                            const res = await fetch(
                              "/api/admin/clear-all-data",
                              {
                                method: "POST",
                                headers: { Authorization: `Bearer ${token}` },
                              },
                            );
                            if (res.ok) {
                              showAlert(
                                "Database reset successfully. You can now start fresh.",
                              );
                            }
                          } catch (e) {
                            console.error(e);
                          } finally {
                            setLoading(false);
                          }
                        }
                      }}
                      className="bg-red-600 text-white px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-700 transition-all shadow-xl shadow-red-200 flex items-center justify-center gap-3 active:scale-95"
                    >
                      <Trash2 className="h-5 w-5" />
                      Reset Entire Database
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <datalist id="batch-times">
        <option value="4:00 PM" />
        <option value="5:00 PM" />
        <option value="6:00 PM" />
        <option value="7:00 PM" />
        <option value="8:00 PM" />
      </datalist>
    </>
  );
};

export default AdminDashboard;
