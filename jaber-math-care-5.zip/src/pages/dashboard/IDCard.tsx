import React, { useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';
import { QRCodeCanvas } from 'qrcode.react';
import { Download, User, MapPin, Phone, Calendar, Users, Clock, CreditCard, CheckCircle } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { motion } from 'motion/react';

const IDCard = () => {
  const { user } = useAuth();
  const { settings } = useSettings();
  const cardRef = useRef<HTMLDivElement>(null);

  const handleDownload = async () => {
    if (cardRef.current) {
      const canvas = await html2canvas(cardRef.current, {
        useCORS: true,
        scale: 3,
        backgroundColor: '#ffffff'
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'px',
        format: [canvas.width / 3, canvas.height / 3]
      });
      
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width / 3, canvas.height / 3);
      pdf.save(`Jaber_Math_Care_ID_${user?.roll_number || 'Student'}.pdf`);
    }
  };

  if (!user) return null;

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <CreditCard className="h-8 w-8 text-orange-600" />
            Digital ID Card
          </h1>
          <p className="text-slate-500 mt-1 font-medium">Your official student identification for {settings.site_name || "Jaber Math Care"}.</p>
        </div>
        <button
          onClick={handleDownload}
          className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black shadow-xl shadow-slate-900/20 hover:bg-slate-800 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
        >
          <Download className="h-5 w-5" />
          Download ID Card
        </button>
      </div>

      <div className="flex justify-center py-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          ref={cardRef}
          className="relative w-[400px] h-[640px] bg-white rounded-[3.5rem] shadow-[0_40px_80px_-15px_rgba(0,0,0,0.3)] overflow-hidden border border-slate-100 flex flex-col group"
        >
          {/* Decorative Background Elements */}
          <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-br from-orange-600 via-orange-500 to-rose-600" />
          <div className="absolute top-0 left-0 w-full h-64 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 mix-blend-overlay" />
          
          {/* Holographic Overlay Effect */}
          <motion.div 
            className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/20 to-white/0 z-10 pointer-events-none"
            animate={{
              x: ['-100%', '200%'],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "linear"
            }}
          />

          {/* Header Content */}
          <div className="relative pt-4 md:pt-8 px-10 text-center z-20">
            <div className="flex flex-col items-center gap-3">
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-2xl overflow-hidden border-2 border-white/50">
                {settings.logo_url ? (
                  <img src={settings.logo_url} alt="Logo" className="w-full h-full object-cover" crossOrigin="anonymous" referrerPolicy="no-referrer" />
                ) : (
                  <span className="text-orange-600 font-black text-2xl">{(settings.site_name || "W")[0]}</span>
                )}
              </div>
              <div className="space-y-1">
                <h2 className="text-white text-2xl font-black tracking-tighter leading-none">{(settings.site_name || "JABER MATH CARE").toUpperCase()}</h2>
                <div className="flex items-center justify-center gap-2">
                  <span className="h-px w-4 bg-white/30" />
                  <p className="text-orange-100 text-[9px] font-black uppercase tracking-[0.4em]">Excellence in Education</p>
                  <span className="h-px w-4 bg-white/30" />
                </div>
              </div>
            </div>
          </div>

          {/* Student Photo Section */}
          <div className="relative mt-12 flex justify-center z-20">
            <div className="relative">
              <div className="w-44 h-44 bg-white rounded-[3rem] p-1.5 shadow-[0_20px_50px_rgba(0,0,0,0.2)] overflow-hidden border-4 border-white">
                {user.profile_pic ? (
                  <img src={user.profile_pic} alt={user.name} className="w-full h-full rounded-[2.6rem] object-cover" crossOrigin="anonymous" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-full h-full bg-slate-50 rounded-[2.6rem] flex items-center justify-center text-6xl font-black text-slate-200">
                    {user.name.charAt(0)}
                  </div>
                )}
              </div>
              {/* Verified Badge */}
              <div className="absolute -bottom-2 -right-2 bg-orange-600 text-white p-2 rounded-2xl shadow-xl border-4 border-white">
                <CheckCircle className="h-6 w-6" />
              </div>
            </div>
          </div>

          {/* Student Identity */}
          <div className="px-10 mt-10 text-center flex-1 z-20">
            <div className="mb-8">
              <h3 className="text-3xl font-black text-slate-900 tracking-tight leading-tight mb-1">{user.name}</h3>
              <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-orange-50 rounded-full border border-orange-100">
                <span className="w-2 h-2 bg-orange-500 rounded-full animate-pulse" />
                <p className="text-orange-600 font-black text-[10px] uppercase tracking-widest">{user.student_type} Student</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-y-8 gap-x-4 text-left">
              <div className="space-y-1">
                <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.1em]">Student ID</p>
                <p className="text-base font-black text-slate-800">{user.roll_number || 'N/A'}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.1em]">Batch</p>
                <p className="text-base font-black text-slate-800">{user.batch_name || (String(user.batch_id).length > 10 ? 'Assigned' : user.batch_id) || 'N/A'}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.1em]">Program</p>
                <p className="text-base font-black text-slate-800 truncate">{user.program_title || 'N/A'}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.1em]">Blood Group</p>
                <p className="text-base font-black text-red-600">{user.blood_group || 'N/A'}</p>
              </div>
            </div>
          </div>

          {/* QR Code & Footer */}
          <div className="bg-slate-50/80 backdrop-blur-sm p-8 border-t border-slate-100 flex flex-col items-center gap-6 z-20">
            <div className="relative group/qr">
              <div className="absolute -inset-4 bg-orange-600/10 rounded-[2.5rem] blur-2xl opacity-0 group-hover/qr:opacity-100 transition-opacity" />
              <div className="relative bg-white p-5 rounded-[2rem] shadow-[0_20px_40px_rgba(0,0,0,0.1)] border border-slate-100 transform group-hover/qr:scale-105 transition-transform duration-500">
                <QRCodeCanvas 
                  value={`JABER-MATH-${user.roll_number || user.id}`}
                  size={140}
                  level="H"
                  includeMargin={true}
                />
              </div>
            </div>
            
            <div className="flex items-center justify-between w-full px-4">
              <div className="text-left">
                <p className="text-[8px] text-slate-400 font-black uppercase tracking-[0.2em] mb-0.5">Valid Until</p>
                <p className="text-sm font-black text-slate-800">DECEMBER 2026</p>
              </div>
              <div className="text-right">
                <p className="text-[8px] text-slate-400 font-black uppercase tracking-[0.2em] mb-0.5">Authorized By</p>
                <p className="text-sm font-black text-orange-600 tracking-tighter">ADMINISTRATION</p>
              </div>
            </div>
          </div>
          
          {/* Bottom Bar */}
          <div className="h-3 bg-gradient-to-r from-orange-600 via-rose-600 to-orange-600 w-full" />
        </motion.div>
      </div>

      <div className="glass p-8 rounded-[2.5rem] border border-white/60 shadow-xl max-w-2xl mx-auto">
        <div className="flex items-start gap-4">
          <div className="bg-orange-100 p-3 rounded-2xl">
            <Clock className="h-6 w-6 text-orange-600" />
          </div>
          <div>
            <h4 className="text-lg font-black text-slate-900 mb-2">Important Instructions</h4>
            <ul className="space-y-2 text-sm text-slate-600 font-medium list-disc ml-4">
              <li>This digital ID card is valid for all institutional purposes.</li>
              <li>Please keep your profile picture updated for a clear identification.</li>
              <li>In case of any discrepancies, please contact the administration.</li>
              <li>You can download and print this card for physical use.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IDCard;
