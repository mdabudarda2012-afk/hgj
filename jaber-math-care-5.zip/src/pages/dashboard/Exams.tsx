import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Calendar, Trash2, FileText, Download } from 'lucide-react';
import { showConfirm } from '../../utils/alert';
import SmallLoadingSpinner from '../../components/SmallLoadingSpinner';
import { db } from '../../firebase';
import { collection, onSnapshot, query, where, deleteDoc, doc } from 'firebase/firestore';

const Exams = () => {
  const { token, user } = useAuth();
  const [exams, setExams] = useState<any[]>([]);
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    if (!token || !user) return;

    const unsubscribes: (() => void)[] = [];

    // Listen to exams
    const unsubExams = onSnapshot(collection(db, 'exams'), (snapshot) => {
      const data: any[] = snapshot.docs.map(d => ({ ...d.data(), id: d.id } as any));
      let filteredExams = Array.isArray(data) ? data : [];
      
      if (user?.role === 'student') {
        filteredExams = filteredExams.filter((e: any) => {
          const userBatchIds = [String(user.batch_id), String(user.batch_id_2)].filter(Boolean);
          const examBatchId = String(e.batch_id);
          
          const batchMatch = examBatchId === 'all' || userBatchIds.includes(examBatchId);
          const programMatch = String(e.program_id) === String(user.program_id);
          
          return batchMatch && programMatch;
        });
        
        const uniqueExams = Array.from(new Map(filteredExams.map((e: any) => [e.id, e])).values());
        filteredExams = uniqueExams;
      }
      
      setExams(filteredExams);
      setLoading(false);
    });
    unsubscribes.push(unsubExams);

    // Listen to results
    const qResults = query(collection(db, 'results'), where('student_id', 'in', [user.id, user.roll_number || '']));
    const unsubResults = onSnapshot(qResults, (snapshot) => {
      setResults(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
    });
    unsubscribes.push(unsubResults);

    return () => unsubscribes.forEach(unsub => unsub());
  }, [token, user]);

  const handleDelete = async (id: string) => {
    if (await showConfirm('Are you sure you want to delete this exam?')) {
      try {
        await deleteDoc(doc(db, 'exams', id));
      } catch (error) {
        console.error('Error deleting exam:', error);
      }
    }
  };

  if (loading) return <SmallLoadingSpinner />;

  const resultExamIds = new Set(results.map(r => r.exam_id));
  let upcomingExams = exams.filter(e => !resultExamIds.has(e.id));
  const passingExams = exams.filter(e => resultExamIds.has(e.id));

  // Extract unique categories from upcoming exams correctly
  const categories = Array.from(new Set(upcomingExams.map(e => e.category).filter(Boolean))).sort();

  if (selectedCategory !== 'all') {
    upcomingExams = upcomingExams.filter(e => e.category === selectedCategory);
  }

  return (
    <div className="space-y-12">
      <section>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
          <div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-xl">
                <Calendar className="h-6 w-6 text-orange-600" />
              </div>
              Upcoming Exams
            </h2>
            <p className="text-slate-500 mt-1 text-sm font-medium">Prepare for your scheduled assessments.</p>
          </div>

          <div className="w-full">
            <div className="flex flex-wrap gap-2 mb-4">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  selectedCategory === 'all'
                    ? 'bg-slate-900 text-white shadow-lg'
                    : 'bg-white/40 text-slate-600 hover:bg-white/60 border border-white/60'
                }`}
              >
                All
              </button>
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                    selectedCategory === cat
                      ? 'bg-orange-500 text-white shadow-lg'
                      : 'bg-white/40 text-slate-600 hover:bg-white/60 border border-white/60'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="glass p-2 rounded-2xl border border-white/60 flex items-center gap-2 max-w-xs">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4 mr-2">Filter Category:</span>
              <select 
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-transparent border-none text-slate-900 font-bold text-sm focus:ring-0 cursor-pointer min-w-[150px] outline-none"
              >
                <option value="all">All Categories</option>
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {upcomingExams.map((exam) => (
            <div key={exam.id} className="glass p-8 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 hover:bg-white/60 transition-all relative group overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/5 rounded-full -mr-12 -mt-12 blur-2xl group-hover:bg-orange-500/10 transition-colors"></div>
              
              <h3 className="font-black text-xl text-slate-900 tracking-tight mb-2">{exam.exam_name}</h3>
              {exam.category && (
                <div className="mb-4">
                  <span className="text-[10px] font-black uppercase tracking-widest px-2 py-1 bg-slate-100 text-slate-600 rounded-lg">
                    {exam.category}
                  </span>
                </div>
              )}

              <div className="flex items-center gap-3 mb-8">
                <div className="p-2 rounded-xl bg-orange-50 text-orange-600">
                  <Calendar className="h-4 w-4" />
                </div>
                <p className="text-slate-600 font-bold text-sm">
                  {new Date(exam.exam_date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </p>
              </div>

              <div className="flex justify-between items-center mb-6">
                <div className="flex flex-col">
                  <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Total Marks</span>
                  <span className="text-xl font-black text-slate-900 tracking-tighter">{exam.highest_marks || '-'}</span>
                </div>
                <span className="bg-orange-500 text-white px-5 py-2 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-orange-100">Upcoming</span>
              </div>

              {exam.question_pdf && (
                <a 
                  href={exam.question_pdf} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-3 bg-slate-900 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
                >
                  <Download className="h-4 w-4" />
                  Download Question
                </a>
              )}

              {user?.role === 'admin' && (
                <button 
                  onClick={() => handleDelete(exam.id)}
                  className="absolute top-4 right-4 p-2 bg-red-50 text-red-500 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:scale-110"
                  title="Delete Exam"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              )}
            </div>
          ))}
          {upcomingExams.length === 0 && (
            <div className="col-span-full glass p-16 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 text-center">
              <div className="max-w-xs mx-auto">
                <div className="p-6 bg-slate-50 rounded-full inline-block mb-4">
                  <Calendar className="h-12 w-12 text-slate-200" />
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-2">No Upcoming Exams</h3>
                <p className="text-slate-500 font-medium">You're all caught up! No exams are currently scheduled.</p>
              </div>
            </div>
          )}
        </div>
      </section>

      <section>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
          <div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-xl">
                <Calendar className="h-6 w-6 text-green-600" />
              </div>
              Exam History
            </h2>
            <p className="text-slate-500 mt-1 text-sm font-medium">Review your past performances and results.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {results.map((result) => {
            const exam = exams.find(e => e.id === result.exam_id) || {};
            return (
              <div key={result.id} className="glass p-8 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 hover:bg-white/60 transition-all relative group overflow-hidden opacity-90 hover:opacity-100">
                <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/5 rounded-full -mr-12 -mt-12 blur-2xl group-hover:bg-green-500/10 transition-colors"></div>
                
                <h3 className="font-black text-xl text-slate-900 tracking-tight mb-2">{result.exam_name || exam.exam_name || 'Unnamed Exam'}</h3>
                
                {(exam.category || result.category) && (
                  <div className="mb-4">
                    <span className="text-[10px] font-black uppercase tracking-widest px-2 py-1 bg-green-50 text-green-600 rounded-lg">
                      {exam.category || result.category}
                    </span>
                  </div>
                )}
                
                <div className="flex items-center gap-3 mb-8">
                  <div className="p-2 rounded-xl bg-green-50 text-green-600">
                    <Calendar className="h-4 w-4" />
                  </div>
                  <p className="text-slate-600 font-bold text-sm">
                    {new Date(result.created_at || exam.exam_date || Date.now()).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                  </p>
                </div>

                <div className="flex justify-between items-center mb-6">
                  <div className="flex flex-col">
                    <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Your Score</span>
                    <div className="flex items-baseline gap-1">
                      <span className="text-2xl font-black text-green-600 tracking-tighter">{result?.marks || 0}</span>
                      <span className="text-xs text-slate-300 font-black">/ {exam.highest_marks || result.total_marks || result.e_total || '-'}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest block mb-1">Merit</span>
                    <span className="text-lg font-black text-slate-800 tracking-tighter">#{result?.merit_position || '-'}</span>
                  </div>
                </div>

                {exam.answer_pdf && (
                  <a 
                    href={exam.answer_pdf} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-2 py-3 bg-green-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-green-700 transition-all shadow-lg shadow-green-100"
                  >
                    <FileText className="h-4 w-4" />
                    View Answer Sheet
                  </a>
                )}
              </div>
            );
          })}
          {results.length === 0 && (
            <div className="col-span-full glass p-16 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 text-center">
              <div className="max-w-xs mx-auto">
                <div className="p-6 bg-slate-50 rounded-full inline-block mb-4">
                  <Calendar className="h-12 w-12 text-slate-200" />
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-2">No History</h3>
                <p className="text-slate-500 font-medium">Your completed exams will appear here.</p>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Exams;
