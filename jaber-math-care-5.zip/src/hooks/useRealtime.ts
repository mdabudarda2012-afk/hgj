import { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, query, QueryConstraint, orderBy, where, doc, onSnapshot as onDocSnapshot } from 'firebase/firestore';

export function useRealtimeCollection<T = any>(collectionName: string, constraints: QueryConstraint[] = []) {
  const cacheKey = `cache_${collectionName}_${JSON.stringify(constraints.map(c => c.type))}`;
  const [data, setData] = useState<T[]>(() => {
    const saved = localStorage.getItem(cacheKey);
    return saved ? JSON.parse(saved) : [];
  });
  const [loading, setLoading] = useState(data.length === 0);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let q;
    try {
      q = query(collection(db, collectionName), ...constraints);
    } catch (e) {
      console.error(`Error creating query for ${collectionName}:`, e);
      q = collection(db, collectionName);
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setData(docs);
      localStorage.setItem(cacheKey, JSON.stringify(docs));
      setLoading(false);
    }, (err) => {
      console.error(`Error in onSnapshot for ${collectionName}:`, err);
      setError(err as Error);
      setLoading(false);
      
      // Fallback: try without constraints if it failed (likely index issue)
      if (constraints.length > 0) {
        console.log(`Retrying ${collectionName} without constraints...`);
        const fallbackQ = collection(db, collectionName);
        onSnapshot(fallbackQ, (s) => {
          const fallbackDocs = s.docs.map(d => ({ id: d.id, ...d.data() }));
          setData(fallbackDocs as any);
          localStorage.setItem(cacheKey, JSON.stringify(fallbackDocs));
        });
      }
    });

    return unsubscribe;
  }, [collectionName, cacheKey]);

  return { data, loading, error };
}

export function useRealtimeDocument(collectionName: string, docId: string) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!docId) return;
    const unsubscribe = onDocSnapshot(doc(db, collectionName, docId), (snapshot) => {
      if (snapshot.exists()) {
        setData({ id: snapshot.id, ...snapshot.data() });
      } else {
        setData(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, [collectionName, docId]);

  return { data, loading };
}
