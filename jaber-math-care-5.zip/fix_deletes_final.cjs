const fs = require('fs');

let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

const emptyImpls = [
  { func: 'handleDeleteDegree', coll: 'degrees', label: 'degree' },
  { func: 'handleDeleteLiveClass', coll: 'live_classes', label: 'live class' },
  { func: 'handleDeleteBatch', coll: 'batches', label: 'batch' },
  { func: 'handleDeleteReview', coll: 'reviews', label: 'review' },
  { func: 'handleDeleteWebRecordedClass', coll: 'web_recorded_classes', label: 'recorded class' },
  { func: 'handleDeleteWebClassSchedule', coll: 'web_class_schedules', label: 'class schedule' },
  { func: 'handleDeleteVideoClass', coll: 'video_classes', label: 'video class' }
];

for (const e of emptyImpls) {
  const funcRegex = new RegExp(`const ${e.func} = async \\(id: string\\) => \\{\\s*(?:if \\(await showConfirm\\(".*?"\\)\\) \\{\\s*)?// Implementation(?:\\s*\\})?\\s*\\};\\n`, 'g');
  
  const replacement = `const ${e.func} = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete ${e.label}s", "error");
      return;
    }
    if (await showConfirm("Are you sure you want to delete this ${e.label}?")) {
      try {
        await deleteDoc(doc(db, "${e.coll}", id));
        showAlert("${e.label.charAt(0).toUpperCase() + e.label.slice(1)} deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete ${e.label}", "error");
      }
    }
  };
`;
  code = code.replace(funcRegex, replacement);
}

// Student delete (Optimistic update)
code = code.replace(/const handleDeleteStudent = async \(id: string\) => \{[\s\S]*?\n  \};\n/, `const handleDeleteStudent = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete students", "error");
      return;
    }
    if (await showConfirm("Are you sure you want to delete this student?")) {
      try {
        setStudents(prev => prev.filter(s => s.id !== id));
        const res = await fetch(\`/api/students/\${id}\`, {
          method: "DELETE",
          headers: { Authorization: \`Bearer \${token}\` },
        });
        if (!res.ok) throw new Error("Failed to delete student");
        showAlert("Student deleted successfully", "success");
      } catch (e) {
        console.error(e);
        showAlert(e.message || "Error deleting student", "error");
      }
    }
  };
`);

// Result History delete
code = code.replace(/const handleDeleteResultHistory = async \(id: string\) => \{[\s\S]*?\n  \};\n/, `const handleDeleteResultHistory = async (id: string) => {
    if (await showConfirm("Are you sure you want to delete this exam history?")) {
      try {
        await deleteDoc(doc(db, "result_histories", id));
        showAlert("Result history deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete result history", "error");
      }
    }
  };
`);

// Study Material delete
code = code.replace(/const handleDeleteStudyMaterial = async \(id: string\) => \{[\s\S]*?\n  \};\n/, `const handleDeleteStudyMaterial = async (id: string) => {
    if (await showConfirm("Are you sure you want to delete this material?")) {
      try {
        await deleteDoc(doc(db, "study_materials", id));
        showAlert("Material deleted successfully", "success");
      } catch (error) {
        console.error(error);
        showAlert("Failed to delete material", "error");
      }
    }
  };
`);

// messages delete
code = code.replace(new RegExp('await fetch\\(\\s*`/api/messages/\\$\\{msg\\.id\\}`[\\s\\S]*?\\s*\\);', 'g'), `await deleteDoc(doc(db, "messages", msg.id));`);

// moderators delete
code = code.replace(new RegExp('await fetch\\(`/api/moderators/\\$\\{mod\\.id\\}`[\\s\\S]*?\\s*\\);', 'g'), `setModerators(prev => prev.filter(m => m.id !== mod.id)); await fetch(\`/api/moderators/\${mod.id}\`, { method: "DELETE", headers: { Authorization: \`Bearer \${token}\` }});`);

// class-slides delete
code = code.replace(new RegExp('await fetch\\(`/api/class-slides/\\$\\{slide\\.id\\}`[\\s\\S]*?\\s*\\);\\s*fetchSlides\\(\\);', 'g'), `await deleteDoc(doc(db, "class_slides", slide.id));`);

fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
console.log('Script completed.');
