import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import admin from 'firebase-admin';
import { getFirestore } from 'firebase-admin/firestore';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase Admin
const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

if (!admin.apps.length) {
  try {
    // Attempt default initialization first (works on Cloud Run/Compute Engine)
    admin.initializeApp();
    console.log('Firebase Admin initialized with default credentials.');
  } catch (error) {
    console.log('Default initialization failed (common in local dev), using config projectId.');
    admin.initializeApp({
      projectId: firebaseConfig.projectId
    });
  }
}

let db: admin.firestore.Firestore;
try {
  const dbId = firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
    ? firebaseConfig.firestoreDatabaseId
    : undefined;

  if (dbId) {
    console.log('Using named database:', dbId);
    db = getFirestore(admin.app(), dbId);
  } else {
    console.log('Using default database');
    db = getFirestore(admin.app());
  }

  
  // Test connection immediately with a write attempt
  const testDoc = db.collection('test').doc('connection');
  testDoc.set({ 
    last_verified: new Date().toISOString(),
    service: 'backend'
  }, { merge: true })
    .then(() => console.log('Firestore connection verified with WRITE via test/connection.'))
    .catch(err => {
      // If write fails, try read
      console.warn('Firestore WRITE test failed, attempting READ:', err.message);
      testDoc.get()
        .then(() => console.log('Firestore connection verified with READ via test/connection.'))
        .catch(readErr => {
          console.error('CRITICAL: Firestore connection test failed (READ & WRITE):', readErr.message);
          if (readErr.message.includes('PERMISSION_DENIED') || readErr.message.includes('permission')) {
             console.warn('Check if Service Account has "Cloud Datastore User" role and if the database ID is correct.');
          }
        });
    });

} catch (error) {
  console.error('Critical error initializing Firestore SDK:', error);
  db = admin.firestore();
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // Disable caching globally for all routes
  app.use((req, res, next) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    res.set('Surrogate-Control', 'no-store');
    next();
  });

  // Middleware to verify Firebase ID Token
  const authenticate = async (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.log(`[AUTH] Missing or invalid Authorization header from ${req.method} ${req.url}`);
      return res.status(401).json({ error: 'Unauthorized', details: 'Missing Authorization header' });
    }
    const idToken = authHeader.split('Bearer ')[1];
    try {
      const decodedToken = await admin.auth().verifyIdToken(idToken);
      const email = (decodedToken.email || '').toLowerCase();
      console.log(`[AUTH] Authenticating: ${email} (UID: ${decodedToken.uid}) for ${req.method} ${req.url}`);
      req.user = decodedToken;
      
      const userDoc = await db.collection('users').doc(decodedToken.uid).get();
      const adminEmails = [
        'jabermathcare@gmail.com', 
        'contact.jabermathcare@gmail.com'
      ].map(e => e.toLowerCase());

      if (adminEmails.includes(email)) {
        req.user.role = 'admin';
        if (!userDoc.exists || userDoc.data()?.role !== 'admin') {
          await db.collection('users').doc(decodedToken.uid).set({
            email: decodedToken.email,
            name: decodedToken.name || 'Admin',
            role: 'admin',
            updated_at: new Date().toISOString()
          }, { merge: true });
        }
      } else if (email === 'mdabudarda2012@gmail.com') {
        req.user.role = 'student';
        if (userDoc.exists && userDoc.data()?.role === 'admin') {
          await db.collection('users').doc(decodedToken.uid).update({ role: 'student' });
        }
      } else if (userDoc.exists) {
        req.user.role = userDoc.data()?.role;
      }
 else {
        req.user.role = 'student';
      }
      next();
    } catch (error: any) {
      console.error(`[AUTH] Error verifying token for ${req.method} ${req.url}:`, error.message);
      res.status(401).json({ error: 'Unauthorized', details: error.message });
    }
  };

  // API Routes
  
  // Diagnostic
  app.get('/api/admin/debug-auth', authenticate, (req: any, res) => {
    res.json({
      user: req.user,
      firebaseProjectId: admin.app().options.projectId,
      configProjectId: firebaseConfig.projectId
    });
  });

  // Migration Route
  app.get('/migrate-results', async (req: any, res) => {
    try {
      const snapshot = await db.collection('results').get();
      let migrated = 0;
      for (const resultDoc of snapshot.docs) {
        const data = resultDoc.data();
        if (!data.roll_number || !data.student_name) {
           if (data.student_id) {
             const studentDoc = await db.collection('users').doc(data.student_id).get();
             if (studentDoc.exists) {
               await resultDoc.ref.update({
                  roll_number: studentDoc.data()?.roll_number || '',
                  student_name: studentDoc.data()?.name || ''
               });
               migrated++;
             }
           }
        }
      }
      res.json({ success: true, migrated });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/my-enrollments', authenticate, async (req: any, res) => {
    try {
      const email = (req.user.email || '').toLowerCase();
      const phone = req.user.phone_number || '';
      
      // Get approved enrollments for this user
      const snapshot = await db.collection('enrollments')
        .where('user_id', '==', req.user.uid)
        .get();
      
      let enrollments = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      // Also search by email/phone if user_id is missing (legacy/virtual enrollments)
      if (email || phone) {
        let q: any = db.collection('enrollments');
        const legacySnapshot = await q.get();
        const extra = legacySnapshot.docs
          .map((doc: any) => ({ id: doc.id, ...doc.data() }))
          .filter((e: any) => 
            !enrollments.find(existing => existing.id === e.id) &&
            ((email && e.email?.toLowerCase() === email) || (phone && e.phone === phone))
          );
        enrollments = [...enrollments, ...extra];
      }

      res.json(enrollments);
    } catch (error) {
      console.error('Error fetching my-enrollments:', error);
      res.status(500).json({ error: 'Failed to fetch enrollments' });
    }
  });

  // Auth Profile
  app.get('/api/auth/profile', authenticate, async (req: any, res) => {
    try {
      const userDoc = await db.collection('users').doc(req.user.uid).get();
      if (!userDoc.exists) return res.status(404).json({ error: 'User not found' });
      const data = userDoc.data();
      if (req.user.email === 'mdabudarda2012@gmail.com' && data.role !== 'student') {
        await db.collection('users').doc(req.user.uid).update({ role: 'student' });
        data.role = 'student';
      }
      res.json({ id: userDoc.id, ...data });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch profile' });
    }
  });

  // Messages
  app.get('/api/messages', authenticate, async (req, res) => {
    try {
      const snapshot = await db.collection('messages').orderBy('created_at', 'desc').get();
      const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  // Settings
  app.get('/api/settings', async (req, res) => {
    try {
      const snapshot = await db.collection('settings').get();
      const settings: any = {};
      snapshot.forEach(doc => {
        settings[doc.id] = doc.data().value;
      });
      res.json(settings);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: String(error) });
    }
  });

  app.get('/api/public/settings', async (req, res) => {
    try {
      const snapshot = await db.collection('settings').get();
      const settings: any = {};
      snapshot.forEach(doc => {
        settings[doc.id] = doc.data().value;
      });
      res.json(settings);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: String(error) });
    }
  });

  app.post('/api/settings', authenticate, async (req, res) => {
    try {
      const { key, value } = req.body;
      if (!key) return res.status(400).json({ error: 'Key is required' });
      await db.collection('settings').doc(key).set({ value }, { merge: true });
      res.json({ success: true });
    } catch (error) {
      console.error('Error saving settings:', error);
      res.status(500).json({ error: 'Failed to save settings' });
    }
  });

  // Special handling for enrollments (public for guests)
  app.post('/api/enrollments', async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ['image_url', 'profile_pic', 'student_image']) {
          if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
            const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
            if (match && match[1]) {
              parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };

      req.body = sanitizeUrls(req.body);
      const { email, gmail, password, phone, name, profile_pic, ...rest } = req.body;
      const userEmail = email || gmail;
      let uid = null;

      if (userEmail && password) {
        try {
          const userRecord = await admin.auth().createUser({
            email: userEmail.trim(),
            password: password,
            displayName: name
          });
          uid = userRecord.uid;
          
          await db.collection('users').doc(uid).set({
            ...rest,
            name,
            email: userEmail.trim(),
            phone,
            role: 'student',
            status: 'pending',
            student_type: req.body.student_type || (req.body.course_title ? 'online' : 'offline'),
            profile_pic: profile_pic || '',
            created_at: new Date().toISOString()
          });
        } catch (authError: any) {
          if (authError.code === 'auth/email-already-in-use') {
            try {
              const userRecord = await admin.auth().getUserByEmail(userEmail.trim());
              uid = userRecord.uid;
            } catch (e) {
              // ignore
            }
          } else {
            console.error('Auth error during enrollment:', authError);
          }
        }
      }

      const enrollmentData = {
        ...req.body,
        user_id: uid,
        status: 'pending',
        created_at: new Date().toISOString()
      };
      
      const docRef = await db.collection('enrollments').add(enrollmentData);
      res.json({ id: docRef.id, ...enrollmentData });
    } catch (error) {
      console.error('Enrollment error:', error);
      res.status(500).json({ error: 'Failed to process enrollment' });
    }
  });

  // Special handling for messages (public for guests)
  app.post('/api/messages', async (req, res) => {
    try {
      const data = { ...req.body, created_at: new Date().toISOString() };
      await db.collection('messages').add(data);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to send message' });
    }
  });
  app.get('/api/students', authenticate, async (req, res) => {
    try {
      let query: any = db.collection('users').where('role', '==', 'student');
      Object.keys(req.query).forEach(key => {
        if (key !== 't') query = query.where(key, '==', req.query[key]);
      });
      const snapshot = await query.get();
      res.json(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch students' });
    }
  });

  app.get('/api/students/:id', authenticate, async (req, res) => {
    try {
      const doc = await db.collection('users').doc(req.params.id).get();
      if (!doc.exists) return res.status(404).json({ error: 'Not found' });
      let data: any = { id: doc.id, ...doc.data() };

      const [attendance, payments, results, enrollments] = await Promise.all([
        db.collection('attendance').where('student_id', '==', doc.id).get(),
        db.collection('payments').where('student_id', '==', doc.id).get(),
        db.collection('results').where('student_id', '==', doc.id).get(),
        db.collection('enrollments').where('user_id', '==', doc.id).get()
      ]);

      data = {
        ...data,
        attendance: attendance.docs.map(d => ({ id: d.id, ...d.data() })),
        payments: payments.docs.map(d => ({ id: d.id, ...d.data() })),
        results: results.docs.map(d => ({ id: d.id, ...d.data() })),
        enrolled_courses: enrollments.docs.map(d => ({ id: d.id, ...d.data() }))
      };
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch student details' });
    }
  });

  app.post('/api/students', authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ['image_url', 'profile_pic', 'student_image']) {
          if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
            const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
            if (match && match[1]) {
              parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };
      req.body = sanitizeUrls(req.body);
      const { email, password, name, enrollment_id, ...rest } = req.body;
      if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
      
      let uid = '';
      try {
        const userRecord = await admin.auth().createUser({
          email: email.trim(),
          password,
          displayName: name
        });
        uid = userRecord.uid;
      } catch (err: any) {
        if (err.code === 'auth/email-already-exists' || err.code === 'auth/email-already-in-use') {
          const userRecord = await admin.auth().getUserByEmail(email.trim());
          uid = userRecord.uid;
          await admin.auth().updateUser(uid, { password, displayName: name });
        } else {
          throw err;
        }
      }
      
      const userData = {
        ...rest,
        name,
        email: email.trim(),
        role: 'student',
        status: 'approved',
        created_at: rest.created_at || rest.admission_date || rest.date_of_admission || new Date().toISOString()
      };
      await db.collection('users').doc(uid).set(userData, { merge: true });
      
      if (enrollment_id) {
        try {
          await db.collection('enrollments').doc(enrollment_id).update({
            status: 'approved',
            user_id: uid
          });
        } catch (e) {
          console.warn('Failed to update enrollment:', e);
        }
      }
      
      res.json({ id: uid, ...userData });
    } catch (error: any) {
      console.error('Error creating student:', error);
      res.status(500).json({ error: error.message || 'Failed to create student' });
    }
  });

  app.put('/api/students/:id', authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ['image_url', 'profile_pic', 'student_image']) {
          if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
            const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
            if (match && match[1]) {
              parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };

      await db.collection('users').doc(req.params.id).update(sanitizeUrls(req.body));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update student' });
    }
  });

  app.delete('/api/students/:id', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    try {
      // Also delete from Auth if possible (optional but good)
      try {
        await admin.auth().deleteUser(req.params.id);
      } catch (e) {
        console.log('User not in Auth or delete failed, proceeding with Firestore delete');
      }
      await db.collection('users').doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete student' });
    }
  });

  app.delete('/api/cancel-enrollment/:id', authenticate, async (req: any, res) => {
    try {
      const enrollmentRef = db.collection('enrollments').doc(req.params.id);
      const enrollmentDoc = await enrollmentRef.get();
      if (!enrollmentDoc.exists) return res.status(404).json({ error: 'Enrollment not found' });
      
      const enrollmentData = enrollmentDoc.data() as any;
      
      const userRef = await db.collection('users').doc(req.user.uid).get();
      const userData = userRef.exists ? userRef.data() : null;

      const isOwner = req.user.role === 'admin' || 
                      enrollmentData.user_id === req.user.uid || 
                      (userData && userData.email && enrollmentData.email === userData.email) ||
                      (userData && userData.email && enrollmentData.gmail === userData.email) ||
                      (userData && userData.phone && enrollmentData.phone === userData.phone) ||
                      (userData && userData.phone && enrollmentData.phone && userData.phone.replace(/\\D/g, "").slice(-10) === enrollmentData.phone.replace(/\\D/g, "").slice(-10));

      if (!isOwner) {
        return res.status(403).json({ error: 'Forbidden' });
      }
      if (enrollmentData.status !== 'pending' && req.user.role !== 'admin') {
        return res.status(400).json({ error: 'Only pending enrollments can be cancelled' });
      }
      
      await enrollmentRef.delete();
      res.json({ success: true });
    } catch (error) {
      console.error('Error cancelling enrollment:', error);
      res.status(500).json({ error: 'Failed to cancel application' });
    }
  });

  app.delete('/api/moderators/:id', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    try {
      await db.collection('users').doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete moderator' });
    }
  });

  // Moderator CRUD
  app.get('/api/moderators', authenticate, async (req, res) => {
    try {
      const snapshot = await db.collection('users').where('role', '==', 'moderator').get();
      res.json(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch moderators' });
    }
  });

  app.post('/api/moderators', authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ['image_url', 'profile_pic', 'student_image']) {
          if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
            const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
            if (match && match[1]) {
              parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };
      req.body = sanitizeUrls(req.body);
      const { email, password, name, ...rest } = req.body;
      const userRecord = await admin.auth().createUser({
        email: email.trim(),
        password,
        displayName: name
      });
      const userData = { ...rest, name, email: email.trim(), role: 'moderator', created_at: new Date().toISOString() };
      await db.collection('users').doc(userRecord.uid).set(userData);
      res.json({ id: userRecord.uid, ...userData });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Enrollment Status & Approval
  app.put('/api/enrollments/:id/status', authenticate, async (req, res) => {
    try {
      const { status, roll_number, monthly_fee, admission_fee, batch_id } = req.body;
      const enrollmentDoc = await db.collection('enrollments').doc(req.params.id).get();
      if (!enrollmentDoc.exists) return res.status(404).json({ error: 'Enrollment not found' });
      
      const enrollmentData = enrollmentDoc.data();
      await db.collection('enrollments').doc(req.params.id).update({ 
        status,
        ...(roll_number && { roll_number }),
        ...(monthly_fee && { monthly_fee }),
        ...(admission_fee && { admission_fee }),
        ...(batch_id && { batch_id })
      });

      if (status === 'approved') {
        let updatePayload: any = {
          status: 'approved',
          role: 'student',
          ...(roll_number && { roll_number }),
          ...(monthly_fee && { monthly_fee: String(monthly_fee) }),
          ...(admission_fee && { admission_fee: String(admission_fee) }),
        };

        const isOnline = !!(enrollmentData?.course_id || enrollmentData?.course_title || enrollmentData?.student_type === 'online' || enrollmentData?.student_type === 'online');
        updatePayload.student_type = isOnline ? 'online' : 'offline';

        const finalBatchId = batch_id || enrollmentData?.batch_id;
        if (finalBatchId) {
           updatePayload.batch_id = String(finalBatchId);
        }

        if (enrollmentData?.course_id) {
           updatePayload.enrolled_courses = [enrollmentData.course_id];
           updatePayload.course_id = enrollmentData.course_id;
           updatePayload.course_title = enrollmentData.course_title;
        } else if (enrollmentData?.program_id) {
           updatePayload.program_id = enrollmentData.program_id;
           updatePayload.program_title = enrollmentData.program_title;
           if (enrollmentData.current_class) updatePayload.current_class = enrollmentData.current_class;
        }

        let targetUserId = enrollmentData?.user_id;

        if (targetUserId) {
          const userRef = db.collection('users').doc(targetUserId);
          const userDoc = await userRef.get();
          if (userDoc.exists) {
            const currentData = userDoc.data();
            if (enrollmentData.course_id) {
               const enrolledCourses = currentData?.enrolled_courses || [];
               if (!enrolledCourses.includes(enrollmentData.course_id)) {
                 enrolledCourses.push(enrollmentData.course_id);
               }
               updatePayload.enrolled_courses = enrolledCourses;
            }
            // Update auth password if available and they were pending
            if (currentData?.status === 'pending' && enrollmentData.password) {
               try {
                 await admin.auth().updateUser(targetUserId, { password: enrollmentData.password });
               } catch(e) {}
            }
            await userRef.update(updatePayload);
          } else {
            // Document missing, recreate
            await userRef.set({
              ...enrollmentData,
              ...updatePayload,
              role: 'student',
              created_at: new Date().toISOString()
            });
          }
        } else {
          // No user_id attached to enrollment, create entirely new user
          const userEmail = enrollmentData.email || enrollmentData.gmail || '';
          let uid = '';
          
          if (userEmail && enrollmentData.password) {
            try {
              const userRecord = await admin.auth().createUser({
                email: userEmail.trim(),
                password: enrollmentData.password,
                displayName: enrollmentData.name || 'Student'
              });
              uid = userRecord.uid;
            } catch (err: any) {
              if (err.code === 'auth/email-already-exists' || err.code === 'auth/email-already-in-use') {
                try {
                  const userRecord = await admin.auth().getUserByEmail(userEmail.trim());
                  uid = userRecord.uid;
                  await admin.auth().updateUser(uid, { password: enrollmentData.password });
                } catch(e) {
                  uid = db.collection('users').doc().id; // fallback
                }
              } else {
                uid = db.collection('users').doc().id;
              }
            }
          } else {
            uid = db.collection('users').doc().id;
          }

          const newUserRef = db.collection('users').doc(uid);
          await newUserRef.set({
             ...enrollmentData,
             ...updatePayload,
             role: 'student',
             created_at: new Date().toISOString()
          });
          // Update enrollment with new user_id
          await db.collection('enrollments').doc(req.params.id).update({ user_id: uid });
          targetUserId = uid;
        }

        // Send Approval Notification
        if (targetUserId) {
          await db.collection('notifications').add({
            user_id: targetUserId,
            title: 'Enrollment Approved',
            message: `Congratulations! Your enrollment for ${enrollmentData?.program_title || enrollmentData?.course_title || 'a program'} has been approved.`,
            type: 'enrollment',
            is_read: false,
            created_at: new Date().toISOString()
          });

          // Send Email over SMTP if configured
          const studentEmail = enrollmentData?.email || enrollmentData?.gmail || "";
          if (studentEmail && isOnline) {
            const settingsSnapshot = await db.collection('settings').get();
            const settings: any = {};
            settingsSnapshot.docs.forEach(doc => { settings[doc.id] = doc.data().value; });

            if (settings.smtp_email && settings.smtp_password) {
               import('nodemailer').then(nodemailer => {
                 const transporter = nodemailer.createTransport({
                   service: 'gmail',
                   auth: { user: settings.smtp_email, pass: settings.smtp_password }
                 });
                 const mailOptions = {
                   from: `"JaberMath Care" <${settings.smtp_email}>`,
                   to: studentEmail,
                   subject: `Enrollment Approved`,
                   html: `
                      <div style="font-family: sans-serif; padding: 20px; color: #333;">
                        <h2>Enrollment Approved</h2>
                        <p>Dear ${enrollmentData?.name || 'Student'},</p>
                        <p>Your enrollment for <strong>${enrollmentData?.program_title || enrollmentData?.course_title || 'our program'}</strong> has been verified and fully approved.</p>
                        <p>You can now log in to the portal to access your classes and materials.</p>
                        <p>Thank you for choosing JaberMath Care!</p>
                      </div>
                   `
                 };
                 transporter.sendMail(mailOptions).catch(e => console.error("Auto Email failed:", e));
               }).catch(() => {});
            }
          }
        }
      }
      res.json({ success: true });
    } catch (error) {
      console.error('Status update error:', error);
      res.status(500).json({ error: 'Failed to update status' });
    }
  });

  // Student Search for Attendance
  app.get('/api/student-search', authenticate, async (req, res) => {
    try {
      const { batch_id, roll_number } = req.query;
      let q: any = db.collection('users').where('role', '==', 'student');
      if (batch_id) q = q.where('batch_id', '==', String(batch_id));
      if (roll_number) q = q.where('roll_number', '==', String(roll_number));
      
      const snapshot = await q.get();
      if (snapshot.empty) return res.status(404).json({ error: 'Student not found' });
      
      const student = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
      res.json(student);
    } catch (error) {
      res.status(500).json({ error: 'Search failed' });
    }
  });

  app.get('/api/attendance/report', authenticate, async (req: any, res) => {
    try {
      const { batch_id, program_id, startDate, endDate, type, status, roll_number } = req.query;
      let query: any = db.collection('attendance');

      if (batch_id && batch_id !== 'all') query = query.where('batch_id', '==', String(batch_id));
      if (program_id) query = query.where('program_id', '==', String(program_id));
      if (type) query = query.where('type', '==', String(type));
      if (status) query = query.where('status', '==', String(status));
      if (roll_number) query = query.where('roll_number', '==', String(roll_number));

      // Program ID filter would require joining which Firestore doesn't do natively well,
      // but we can filter by student's program if we had it in attendance doc.
      // For now, let's just filter by what's available.

      const snapshot = await query.get();
      let records = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      // Apply date filters in memory if needed
      if (startDate || endDate) {
        records = records.filter((r: any) => {
          const d = r.date;
          if (startDate && d < startDate) return false;
          if (endDate && d > endDate) return false;
          return true;
        });
      }

      res.json(records);
    } catch (error) {
      console.error('Error fetching attendance report:', error);
      res.status(500).json({ error: 'Failed to fetch attendance report' });
    }
  });

  // Standardize collection names (map URL paths to Firestore collection names)

  const collectionMap: Record<string, string> = {
    'batches': 'batches',
    'programs': 'programs',
    'courses': 'courses',
    'notices': 'notices',
    'resources': 'resources',
    'routines': 'routines',
    'gallery': 'gallery',
    'exams': 'exams',
    'chapters': 'chapters',
    'class-slides': 'class_slides',
    'payments': 'payments',
    'results': 'results',
    'reviews': 'reviews',
    'video-classes': 'video_classes',
    'degrees': 'degrees',
    'study-materials': 'study_materials',
    'web-recorded-classes': 'web_recorded_classes',
    'web-class-schedules': 'web_class_schedules',
    'enrollments': 'enrollments',
    'live-classes': 'live_classes',
    'attendance': 'attendance',
    'live-chat-messages': 'live_chat_messages',
    'live-polls': 'live_polls',
    'live-reactions': 'live_reactions',
    'live-participants': 'live_participants'
  };

  const genericCollections = Object.keys(collectionMap);

  genericCollections.forEach(pathName => {
    const collectionName = collectionMap[pathName];
    
    // GET all
    app.get(`/api/${pathName}`, authenticate, async (req, res) => {
      try {
        let query: any = db.collection(collectionName);
        Object.keys(req.query).forEach(key => {
          if (key !== 't') query = query.where(key, '==', req.query[key]);
        });
        const snapshot = await query.get();
        res.json(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error(`Error fetching ${pathName}:`, error);
        res.status(500).json({ error: `Failed to fetch ${pathName}` });
      }
    });

    // GET one
    app.get(`/api/${pathName}/:id`, authenticate, async (req, res) => {
      try {
        const doc = await db.collection(collectionName).doc(req.params.id).get();
        if (!doc.exists) return res.status(404).json({ error: 'Not found' });
        res.json({ id: doc.id, ...doc.data() });
      } catch (error) {
        res.status(500).json({ error: 'Failed to fetch document' });
      }
    });

    const sanitizeUrls = (obj: any) => {
      const parsed = { ...obj };
      for (const key of ['image_url', 'profile_pic', 'student_image']) {
        if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
          const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
          if (match && match[1]) {
            parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
          }
        }
      }
      return parsed;
    };

    // POST
    if (pathName !== 'enrollments' && pathName !== 'messages') {
      app.post(`/api/${pathName}`, authenticate, async (req, res) => {
        try {
          const sanitizedBody = sanitizeUrls(req.body);
          const data = { ...sanitizedBody, created_at: new Date().toISOString() };
          const docRef = await db.collection(collectionName).add(data);
          
          // Send automatic SMS and Email if it's a payment
          if (pathName === 'payments') {
            try {
              // Get student phone and email
              const studentId = data.student_id;
              let phone = "";
              let studentEmail = "";
              let studentName = "";
              if (studentId) {
                const studentDoc = await db.collection('users').doc(studentId).get();
                if (studentDoc.exists) {
                  const sData = studentDoc.data();
                  phone = sData?.guardian_phone || "";
                  studentEmail = sData?.email || sData?.gmail || "";
                  studentName = sData?.name || "Student";
                }

                // Create In-App Notification
                await db.collection('notifications').add({
                  user_id: studentId,
                  title: 'Payment Received',
                  message: `Your payment of ৳${data.amount} for ${data.month || 'this month'} has been received.`,
                  type: 'payment',
                  is_read: false,
                  created_at: new Date().toISOString()
                });
              }
              
              const settingsSnapshot = await db.collection('settings').get();
              const settings: any = {};
              settingsSnapshot.docs.forEach(doc => { settings[doc.id] = doc.data().value; });
                
              const currentMonth = data.month ? data.month + ' ' : '';
              const amountTk = data.amount;

              if (phone) {
                if (settings.sms_api_url) {
                  const url = new URL(settings.sms_api_url);
                  if (settings.sms_api_key) url.searchParams.append("api_key", settings.sms_api_key);
                  if (settings.sms_sender_id) url.searchParams.append("senderid", settings.sms_sender_id);
                  url.searchParams.append("number", phone);
                  url.searchParams.append("message", `Dear Guardian, Payment of TK ${amountTk} for ${currentMonth}fee has been received successfully. - JaberMath Care`);
                  
                  fetch(url.toString()).catch(e => console.error("Auto SMS failed:", e));
                }
              }

              if (studentEmail && settings.smtp_email && settings.smtp_password) {
                 import('nodemailer').then(nodemailer => {
                   const transporter = nodemailer.createTransport({
                     service: 'gmail',
                     auth: {
                       user: settings.smtp_email,
                       pass: settings.smtp_password
                     }
                   });
                   
                   const mailOptions = {
                     from: `"JaberMath Care" <${settings.smtp_email}>`,
                     to: studentEmail,
                     subject: `Payment Receipt: ${currentMonth}Fee`,
                     html: `
                        <div style="font-family: sans-serif; padding: 20px; color: #333;">
                          <h2>Payment Successful</h2>
                          <p>Dear ${studentName},</p>
                          <p>We have successfully received your payment of <strong>TK ${amountTk}</strong> for <strong>${currentMonth}fee</strong>.</p>
                          <p>Thank you for being with JaberMath Care!</p>
                        </div>
                     `
                   };
                   
                   transporter.sendMail(mailOptions).catch(e => console.error("Auto Email failed:", e));
                 });
              }

            } catch (e) {
              console.error("Failed to send auto SMS/Email for payment:", e);
            }
          }

          res.json({ id: docRef.id, ...data });
        } catch (error) {
          res.status(500).json({ error: 'Failed to create document' });
        }
      });
    }

    // PUT
    app.put(`/api/${pathName}/:id`, authenticate, async (req, res) => {
      try {
        const sanitizedBody = sanitizeUrls(req.body);
        await db.collection(collectionName).doc(req.params.id).update(sanitizedBody);
        res.json({ success: true });
      } catch (error) {
        res.status(500).json({ error: 'Failed to update document' });
      }
    });

    // DELETE
    app.delete(`/api/${pathName}/:id`, authenticate, async (req, res) => {
      try {
        await db.collection(collectionName).doc(req.params.id).delete();
        res.json({ success: true });
      } catch (error) {
        res.status(500).json({ error: 'Failed to delete document' });
      }
    });
  });

  // Special handling for attendance (Admin/Moderator only)
  app.post('/api/attendance/mark-present', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'moderator') return res.status(403).json({ error: 'Forbidden' });
    try {
      const { student_id, batch_id, date, status, roll_number } = req.body;
      const data = {
        student_id,
        batch_id,
        date: date || new Date().toISOString().split('T')[0],
        status: status || 'present',
        roll_number,
        created_at: new Date().toISOString()
      };
      const docRef = await db.collection('attendance').add(data);
      res.json({ id: docRef.id, ...data });
    } catch (error) {
      res.status(500).json({ error: 'Failed to mark attendance' });
    }
  });

  app.post('/api/attendance/auto-absent', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'moderator') return res.status(403).json({ error: 'Forbidden' });
    try {
      const { batch_id, date } = req.body;
      if (!batch_id || !date) return res.status(400).json({ error: 'batch_id and date required' });
      
      // Get all students in this batch (primary or secondary)
      const studentsSnapshot1 = await db.collection('users')
        .where('role', '==', 'student')
        .where('batch_id', '==', String(batch_id))
        .get();
        
      const studentsSnapshot2 = await db.collection('users')
        .where('role', '==', 'student')
        .where('batch_id_2', '==', String(batch_id))
        .get();
        
      const studentDocsMap = new Map();
      studentsSnapshot1.docs.forEach(doc => studentDocsMap.set(doc.id, doc));
      studentsSnapshot2.docs.forEach(doc => studentDocsMap.set(doc.id, doc));
      
      const allStudentDocs = Array.from(studentDocsMap.values());
      
      const studentIds = allStudentDocs.map(doc => doc.id);
      
      // Get existing attendance for this date and batch
      const attendanceSnapshot = await db.collection('attendance')
        .where('batch_id', '==', String(batch_id))
        .where('date', '==', date)
        .get();
      
      const alreadyMarkedIds = new Set(attendanceSnapshot.docs.map(doc => doc.data().student_id));
      
      const batch = db.batch();
      let count = 0;
      
      for (const studentDoc of allStudentDocs) {
        if (!alreadyMarkedIds.has(studentDoc.id)) {
          const studentData = studentDoc.data();
          const attendanceRef = db.collection('attendance').doc();
          batch.set(attendanceRef, {
            student_id: studentDoc.id,
            batch_id: String(batch_id),
            date,
            status: 'absent',
            type: 'class',
            roll_number: studentData.roll_number,
            isAuto: true,
            created_at: new Date().toISOString()
          });
          count++;
        }
      }
      
      if (count > 0) await batch.commit();
      res.json({ success: true, count });
    } catch (error) {
      console.error('Auto-absent error:', error);
      res.status(500).json({ error: 'Failed to trigger auto-absent' });
    }
  });

  app.post('/api/admin/clear-all-data', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { collection: collectionName } = req.body;
    try {
      const snapshot = await db.collection(collectionName).get();
      const batch = db.batch();
      snapshot.docs.forEach(doc => batch.delete(doc.ref));
      await batch.commit();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to clear data' });
    }
  });

  // Student Status Update
  app.patch('/api/students/:id/status', authenticate, async (req, res) => {
    try {
      const { status } = req.body;
      
      const userDoc = await db.collection('users').doc(req.params.id).get();
      if (!userDoc.exists) return res.status(404).json({ error: 'User not found' });
      
      const updateData: any = { status };
      
      // If approved and current type is online, change to offline
      if (status === 'approved' && userDoc.data()?.student_type === 'online') {
        updateData.student_type = 'offline';
      }
      
      await db.collection('users').doc(req.params.id).update(updateData);
      res.json({ success: true });
    } catch (error) {
      console.error('Failed to update student status:', error);
      res.status(500).json({ error: 'Failed to update student status' });
    }
  });

  // Reset Data Route
  app.post('/api/reset-data', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { type } = req.body;
    try {
      const collections: Record<string, string> = {
        'students': 'users',
        'online_students': 'users',
        'offline_students': 'users',
        'batches': 'batches',
        'payments': 'payments',
        'enrollments': 'enrollments',
        'attendance': 'attendance',
        'exams': 'exams',
        'results': 'results',
        'notices': 'notices',
        'live_classes': 'live_classes',
        'study_materials': 'study_materials',
        'gallery': 'gallery',
        'video_classes': 'video_classes',
        'class_slides': 'class_slides',
        'routines': 'routines',
        'programs': 'programs',
        'courses': 'courses',
        'chapters': 'chapters',
        'messages': 'messages',
        'web_recorded_classes': 'web_recorded_classes',
        'web_class_schedules': 'web_class_schedules'
      };

      const collectionName = collections[type];
      if (!collectionName) return res.status(400).json({ error: 'Invalid type' });

      let query: any = db.collection(collectionName);
      if (type === 'online_students') query = query.where('student_type', '==', 'online');
      if (type === 'offline_students') query = query.where('student_type', '==', 'offline');
      if (type === 'students') query = query.where('role', '==', 'student');

      const snapshot = await query.get();
      const batch = db.batch();
      snapshot.docs.forEach((doc: any) => {
        // Don't delete the admin user if resetting students
        if (collectionName === 'users' && doc.data().role === 'admin') return;
        batch.delete(doc.ref);
      });
      await batch.commit();
      res.json({ success: true });
    } catch (error) {
      console.error('Reset error:', error);
      res.status(500).json({ error: 'Failed to reset data' });
    }
  });

  // Public routes (no auth needed for some GETs)
  app.get('/api/public/notices', async (req, res) => {
    try {
      const snapshot = await db.collection('notices').where('is_verified', '==', true).get();
      const notices = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(notices);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch notices' });
    }
  });

  app.get('/api/public/results', async (req, res) => {
    try {
      const [resultsSnap, usersSnap] = await Promise.all([
        db.collection('results').get(),
        db.collection('users').get()
      ]);
      const usersMap = new Map();
      usersSnap.docs.forEach(doc => {
        usersMap.set(doc.id, doc.data());
      });
      const results = resultsSnap.docs.map(doc => {
        const data = doc.data();
        let roll_number = data.roll_number;
        let student_name = data.student_name;
        if ((!roll_number || !student_name) && data.student_id) {
           const studentData = usersMap.get(data.student_id);
           if (studentData) {
             roll_number = studentData.roll_number || '';
             student_name = studentData.name || '';
           }
        }
        return { 
          id: doc.id, 
          ...data,
          roll_number,
          student_name
        };
      });
      res.json(results);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to fetch results' });
    }
  });

  app.get('/api/public/exams', async (req, res) => {
    try {
      const snapshot = await db.collection('exams').get();
      const exams = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(exams);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch exams' });
    }
  });

  app.get('/api/public/programs', async (req, res) => {
    try {
      const snapshot = await db.collection('programs').get();
      const programs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(programs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch programs' });
    }
  });

  app.get('/api/public/batches', async (req, res) => {
    try {
      const snapshot = await db.collection('batches').get();
      const batches = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(batches);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch batches' });
    }
  });

  // SMS Integration
  app.post('/api/notifications/broadcast', authenticate, async (req: any, res) => {
    try {
      const { user_ids, title, message, type } = req.body;
      if (!Array.isArray(user_ids)) return res.status(400).json({ error: 'user_ids must be an array' });

      const batch = db.batch();
      user_ids.forEach(uid => {
        const ref = db.collection('notifications').doc();
        batch.set(ref, {
          user_id: uid,
          title,
          message,
          type: type || 'announcement',
          is_read: false,
          created_at: new Date().toISOString()
        });
      });

      await batch.commit();
      res.json({ success: true, count: user_ids.length });
    } catch (error) {
      console.error('Broadcast error:', error);
      res.status(500).json({ error: 'Failed to broadcast notifications' });
    }
  });

  app.post('/api/send-sms', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'moderator') return res.status(403).json({ error: 'Forbidden' });
    try {
      const { phone, message } = req.body;
      if (!phone || !message) {
        return res.status(400).json({ error: 'Phone and message are required' });
      }

      const settingsSnapshot = await db.collection('settings').get();
      const settings: any = {};
      settingsSnapshot.docs.forEach(doc => {
        settings[doc.id] = doc.data().value;
      });

      if (!settings.sms_api_url) {
        return res.status(400).json({ error: 'SMS Gateway URL not configured in Settings' });
      }

      const url = new URL(settings.sms_api_url);
      if (settings.sms_api_key) url.searchParams.append("api_key", settings.sms_api_key);
      if (settings.sms_sender_id) url.searchParams.append("senderid", settings.sms_sender_id);
      url.searchParams.append("number", phone);
      url.searchParams.append("message", message);
      
      const response = await fetch(url.toString());
      const responseText = await response.text();
      
      console.log(`SMS dispatched to ${phone}. Response: ${responseText}`);
      res.json({ success: true, response: responseText });
    } catch (error: any) {
      console.error('Error sending SMS:', error);
      res.status(500).json({ error: 'Failed to send SMS', details: error.message });
    }
  });

  app.post('/api/send-email', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'moderator') return res.status(403).json({ error: 'Forbidden' });
    try {
      const { email, subject, message } = req.body;
      if (!email || !subject || !message) {
        return res.status(400).json({ error: 'Email, subject and message are required' });
      }

      const settingsSnapshot = await db.collection('settings').get();
      const settings: any = {};
      settingsSnapshot.docs.forEach(doc => { settings[doc.id] = doc.data().value; });

      if (!settings.smtp_email || !settings.smtp_password) {
          console.log(`\n=== EMAIL DISPATCHED (MOCK - NO SMTP SETTINGS) ===\nTo: ${email}\nSubject: ${subject}\n========================\n`);
          return res.json({ success: true, message: 'SMTP not configured, mock success.' });
      }

      const nodemailer = await import('nodemailer');
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: { user: settings.smtp_email, pass: settings.smtp_password }
      });
      const mailOptions = {
        from: `"${settings.site_name || 'JaberMath Care'}" <${settings.smtp_email}>`,
        to: email,
        subject: subject,
        html: message
      };
      
      await transporter.sendMail(mailOptions);
      
      res.json({ success: true, message: 'Email dispatched successfully' });
    } catch (error: any) {
      console.error('Error sending Email:', error);
      res.status(500).json({ error: 'Failed to send Email', details: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, {
      setHeaders: (res, path) => {
        if (path.endsWith('.html')) {
          res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
          res.set('Pragma', 'no-cache');
          res.set('Expires', '0');
        }
      }
    }));
    app.get('*', (req, res) => {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
export { db, admin };
